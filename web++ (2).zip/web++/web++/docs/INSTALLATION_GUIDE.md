# AgriE-Commerce Installation & Testing Guide

## 🚀 Quick Setup Instructions

### 1. XAMPP Setup
1. **Install XAMPP** from https://www.apachefriends.org/
2. **Start Services**: Apache and MySQL
3. **Access phpMyAdmin**: http://localhost/phpmyadmin

### 2. Database Setup

#### Method 1: Import Database (Recommended)
1. **Open phpMyAdmin**: http://localhost/phpmyadmin
2. **Import Database**:
   - Click "Import" tab (top menu)
   - Click "Choose File" and select `database_setup.sql`
   - Click "Go" to import
   - ✅ This will automatically create the `agri_ecommerce` database with all tables and sample data

#### Method 2: Manual Creation (Alternative)
1. **Create Database**: 
   - Open phpMyAdmin
   - Click "New" to create database
   - Name it `agri_ecommerce`
   - Click "Create"
2. **Import Schema**:
   - Select the `agri_ecommerce` database
   - Go to "Import" tab
   - Choose `database_setup.sql` file
   - Click "Go" to import

#### Method 3: Command Line (Advanced)
```bash
# Navigate to XAMPP MySQL bin directory
cd C:\xampp\mysql\bin

# Import database
mysql -u root -p < "path\to\web++\database_setup.sql"
```

**Note**: The `database_setup.sql` file contains:
- Database creation statement
- All table structures
- Sample data including admin/customer accounts
- Product catalog with images

### 3. File Deployment
1. **Copy Project**: Copy the entire `web++` folder to `C:\xampp\htdocs\`
2. **Access Website**: http://localhost/web++/public/

### 4. Verify Installation
1. **Check Database**: 
   - In phpMyAdmin, you should see `agri_ecommerce` database
   - It should contain 6 tables: users, categories, products, orders, order_items, messages
   - Sample data should be present (8 products, 2 users, 5 categories)
2. **Test Website**: 
   - Homepage should load with featured products
   - Login with demo accounts should work
   - Product images should display correctly

## 🧪 Testing the System

### Demo Accounts
- **Admin**: admin@agriecommerce.com / admin123
- **Customer**: customer@example.com / customer123

### Test Scenarios

#### 1. Customer Flow
1. **Browse Products**: http://localhost/web++/public/products.php
2. **Add to Cart**: Click "Add to Cart" on any product
3. **View Cart**: Check cart page and update quantities
4. **Checkout**: Complete order placement
5. **View Orders**: Check order history in profile

#### 2. Admin Flow
1. **Login as Admin**: Use admin credentials
2. **Dashboard**: View statistics and recent activity
3. **Manage Products**: Add, edit, delete products
4. **Manage Orders**: Update order status
5. **View Messages**: Handle customer inquiries

#### 3. Key Features to Test
- [x] User registration and login
- [x] Product catalog with search/filter
- [x] Shopping cart (add/remove/update)
- [x] Order placement and tracking
- [x] User profile management
- [x] Admin product management
- [x] Admin order management
- [x] Contact form functionality

## 📁 Project Structure

```
web++/
├── 📂 public/              # Customer-facing pages
│   ├── index.php          # Homepage
│   ├── products.php       # Product catalog
│   ├── cart.php           # Shopping cart
│   ├── checkout.php       # Order placement
│   ├── profile.php        # User profile
│   ├── orders.php         # Order history
│   └── ajax/              # AJAX endpoints
│
├── 📂 admin/              # Admin dashboard
│   ├── dashboard.php      # Admin overview
│   ├── products.php       # Product management
│   ├── orders.php         # Order management
│   └── messages.php       # Message management
│
├── 📂 includes/           # Shared PHP files
│   ├── db.php            # Database connection
│   ├── session.php       # Session management
│   ├── header.php        # Common header
│   └── footer.php        # Common footer
│
├── 📂 assets/            # Static assets
│   ├── css/styles.css    # Custom styles
│   ├── js/main.js        # JavaScript
│   └── images/           # Product images
│
└── database_setup.sql    # Database schema
```

## 🔧 Configuration

### Database Settings (includes/db.php)
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'agri_ecommerce');
```

### Default XAMPP Settings
- **Host**: localhost
- **Username**: root
- **Password**: (empty)
- **Port**: 3306

## 🎯 Academic Features Demonstrated

### 1. Database Design
- Normalized table structure
- Primary and foreign keys
- Proper data types and constraints

### 2. PHP Programming
- Procedural PHP with MySQLi
- Prepared statements for security
- Session management
- File organization and includes

### 3. Security Implementation
- Password hashing with `password_hash()`
- SQL injection prevention
- XSS protection with `htmlspecialchars()`
- Input sanitization

### 4. User Interface
- Bootstrap 5 responsive design
- AJAX for dynamic interactions
- Form validation
- User-friendly navigation

### 5. E-commerce Functionality
- Product catalog management
- Shopping cart system
- Order processing workflow
- User account management
- Admin dashboard

## 🐛 Troubleshooting

### Database Import Issues
1. **"Database doesn't exist" error**: 
   - The SQL file creates the database automatically
   - Just import directly without creating database first
2. **Import timeout**: 
   - Increase `max_execution_time` in php.ini
   - Or use command line method
3. **Permission denied**: 
   - Ensure XAMPP MySQL service is running
   - Check file permissions on SQL file
4. **Demo login not working**:
   - If you imported an old version, run `fix_demo_passwords.sql`
   - Or delete database and re-import `database_setup.sql`
   - Passwords: admin123 / customer123

### Common Issues
1. **Database Connection Error**: Check XAMPP MySQL service is running
2. **Page Not Found**: Ensure files are in correct htdocs directory
3. **Images Not Loading**: Check image paths in database match actual files
4. **Session Issues**: Clear browser cookies and restart

### File Permissions
- Ensure web server has read access to all files
- Check that XAMPP is running with proper permissions

## 📊 System Requirements

### Server Requirements
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Apache web server
- Bootstrap 5.3.2 (CDN)

### Browser Compatibility
- Chrome, Firefox, Safari, Edge (latest versions)
- Mobile responsive design

---

**Ready for University Evaluation** ✅
- Complete e-commerce functionality
- Clean, documented code
- Academic-level implementation
- Professional UI/UX design