# AgriE-Commerce - University Project

## 🎓 **Project Overview**
A fully functional agricultural e-commerce website built with PHP, MySQL, and JavaScript for university-level demonstration. This project showcases modern web development practices including database design, user authentication, session management, and AJAX interactions.

## 🛠️ **Technology Stack**
- **Backend**: PHP (Procedural) with MySQLi
- **Database**: MySQL via phpMyAdmin
- **Frontend**: Bootstrap 5.3.2, HTML5, CSS3
- **JavaScript**: Vanilla JS with Fetch API for AJAX
- **Server**: XAMPP (Apache + PHP + MySQL)

## 📁 **Project Structure**
```
web++/
├── 📂 public/                  # User-facing pages
│   ├── index.php              # Homepage with featured products
│   ├── products.php           # Product catalog with search/filter
│   ├── product.php            # Single product view
│   ├── cart.php               # Shopping cart management
│   ├── checkout.php           # Order placement
│   ├── login.php              # User authentication
│   ├── register.php           # User registration
│   ├── logout.php             # Logout functionality
│   ├── about.php              # About page
│   ├── contact.php            # Contact form
│   └── ajax/                  # AJAX endpoints
│       ├── cart_operations.php
│       └── get_cart_count.php
│
├── 📂 admin/                   # Admin dashboard
│   ├── dashboard.php          # Admin overview
│   ├── products.php           # Product management
│   ├── orders.php             # Order management
│   └── users.php              # User management
│
├── 📂 includes/                # Shared PHP files
│   ├── db.php                 # Database connection & utilities
│   ├── session.php            # Session management
│   ├── header.php             # Common header
│   └── footer.php             # Common footer
│
├── 📂 assets/                  # Static assets
│   ├── css/styles.css         # Custom styles
│   ├── js/main.js             # JavaScript functionality
│   └── images/                # Product images
│
└── database_setup.sql         # Database schema & sample data
```

## 🗄️ **Database Design**

### **Tables Structure**
1. **users** - User accounts (customers & admin)
2. **categories** - Product categories
3. **products** - Product catalog
4. **orders** - Customer orders
5. **order_items** - Order line items
6. **messages** - Contact form submissions

### **Key Relationships**
- Products → Categories (Many-to-One)
- Orders → Users (Many-to-One)
- Order Items → Orders & Products (Many-to-One each)

## 🚀 **Installation Instructions**

### **Step 1: Setup XAMPP**
1. Download and install XAMPP
2. Start Apache and MySQL services
3. Open phpMyAdmin (http://localhost/phpmyadmin)

### **Step 2: Create Database**
1. Create new database named `agri_ecommerce`
2. Import `database_setup.sql` file
3. Verify tables and sample data are created

### **Step 3: Deploy Files**
1. Copy project folder to `C:\xampp\htdocs\`
2. Access website at `http://localhost/web++/public/`

### **Step 4: Test Functionality**
- **Admin Login**: admin@agriecommerce.com / admin123
- **Customer Login**: customer@example.com / customer123

## 🔧 **Key Features Implemented**

### **1. User Authentication & Sessions**
- Secure password hashing with `password_hash()`
- Session-based login system
- Role-based access control (Admin/Customer)
- Automatic logout and session management

### **2. Product Management**
- Dynamic product catalog from database
- Category-based filtering
- Search functionality
- Stock quantity tracking
- Image management

### **3. Shopping Cart System**
- Session-based cart storage
- AJAX add/remove/update operations
- Real-time cart badge updates
- Persistent cart across pages

### **4. Order Processing**
- Complete checkout workflow
- Order history tracking
- Multiple delivery options
- Order status management

### **5. Admin Dashboard**
- Product CRUD operations
- Order management
- User management
- Sales analytics

### **6. Security Features**
- SQL injection prevention with prepared statements
- XSS protection with `htmlspecialchars()`
- Input sanitization
- Session security

## 💻 **PHP Code Examples**

### **Database Connection (db.php)**
```php
// Secure database connection with error handling
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepared statement utility function
function executeQuery($conn, $sql, $params = [], $types = '') {
    $stmt = $conn->prepare($sql);
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    return $stmt;
}
```

### **User Authentication**
```php
// Secure login with password verification
$user = getSingleRow($conn, "SELECT * FROM users WHERE email = ?", [$email], 's');
if ($user && password_verify($password, $user['password'])) {
    loginUser($user);
    header('Location: dashboard.php');
}
```

### **Cart Management**
```php
// Session-based cart operations
function addToCart($product_id, $quantity = 1) {
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    $_SESSION['cart'][$product_id] = 
        ($_SESSION['cart'][$product_id] ?? 0) + $quantity;
}
```

## 🎯 **JavaScript Functionality**

### **AJAX Cart Operations**
```javascript
function addToCartAjax(productId, quantity, productName) {
    fetch('ajax/cart_operations.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: `action=add&product_id=${productId}&quantity=${quantity}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification(`${productName} added to cart!`);
            updateCartBadge();
        }
    });
}
```

### **Form Validation**
```javascript
function validateLoginForm(e) {
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();
    
    if (!email || !isValidEmail(email)) {
        showFieldError('email', 'Please enter a valid email');
        e.preventDefault();
    }
}
```

## 📊 **Academic Learning Outcomes**

### **Database Concepts**
- ✅ Relational database design
- ✅ Primary and foreign keys
- ✅ Data normalization
- ✅ SQL queries and joins

### **PHP Programming**
- ✅ Server-side scripting
- ✅ Session management
- ✅ File inclusion and organization
- ✅ Security best practices

### **Web Development**
- ✅ MVC-like architecture
- ✅ Responsive design with Bootstrap
- ✅ AJAX and asynchronous programming
- ✅ Form handling and validation

### **Security Implementation**
- ✅ SQL injection prevention
- ✅ XSS protection
- ✅ Password hashing
- ✅ Input sanitization

## 🧪 **Testing Scenarios**

### **User Registration & Login**
1. Register new account with validation
2. Login with correct/incorrect credentials
3. Session persistence across pages
4. Role-based access control

### **Product Management**
1. Browse products with filtering
2. Search functionality
3. Product detail views
4. Stock quantity handling

### **Shopping Cart**
1. Add products to cart
2. Update quantities
3. Remove items
4. Cart persistence

### **Order Processing**
1. Checkout workflow
2. Order confirmation
3. Admin order management
4. Order history

## 📝 **Documentation for Evaluation**

### **Code Quality**
- Clean, readable PHP code with comments
- Consistent naming conventions
- Proper error handling
- Modular file organization

### **Database Design**
- Normalized table structure
- Appropriate data types
- Referential integrity
- Sample data for testing

### **User Experience**
- Intuitive navigation
- Responsive design
- Form validation feedback
- Success/error notifications

## 🎯 **Future Enhancements**
- Payment gateway integration
- Email notifications
- Advanced reporting
- Mobile app API
- Multi-language support

## 📞 **Support & Documentation**
- Complete inline code comments
- Database schema documentation
- User manual included
- Installation guide provided

---

**Developed for University Academic Evaluation**  
**Demonstrates: PHP-MySQL Integration, Web Security, Modern UI/UX, and E-commerce Functionality**