-- Fix Demo Account Passwords
-- Run this if you already imported the database and login isn't working

USE agri_ecommerce;

-- Update admin password (admin123)
UPDATE users SET password = '$2y$12$9zqMC6a22slhxQmCnZdDsOuKF7cyf2kseQ6PeQyFcFaMn7Lchfc1G' WHERE email = 'admin@agriecommerce.com';

-- Update customer password (customer123)
UPDATE users SET password = '$2y$12$WRX1mFrS1tbSgYqFvxRwa.CLTUvNIISg5U00ycWIvkh5wJwTslo3i' WHERE email = 'customer@example.com';

-- Verify the updates
SELECT id, name, email, role FROM users WHERE email IN ('admin@agriecommerce.com', 'customer@example.com');