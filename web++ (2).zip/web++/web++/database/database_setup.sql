-- AgriE-Commerce Database Setup
-- Run this in phpMyAdmin to create the database and tables

CREATE DATABASE IF NOT EXISTS agri_ecommerce;
USE agri_ecommerce;

-- Users table
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('customer', 'admin') DEFAULT 'customer',
    phone VARCHAR(20),
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Categories table
CREATE TABLE categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Products table
CREATE TABLE products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    description TEXT,
    image VARCHAR(255),
    category_id INT,
    farmer_name VARCHAR(100),
    stock_quantity INT DEFAULT 0,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
);

-- Orders table
CREATE TABLE orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    total_price DECIMAL(10,2) NOT NULL,
    status ENUM('pending', 'processing', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
    shipping_address TEXT NOT NULL,
    phone VARCHAR(20),
    delivery_type ENUM('standard', 'express', 'same-day') DEFAULT 'standard',
    payment_method ENUM('cash', 'mobile', 'bank') DEFAULT 'cash',
    payment_status ENUM('unpaid', 'paid', 'failed') DEFAULT 'unpaid',
    payment_date TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Order items table
CREATE TABLE order_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- Messages table (for contact form)
CREATE TABLE messages (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    subject VARCHAR(200),
    message TEXT NOT NULL,
    status ENUM('unread', 'read', 'replied') DEFAULT 'unread',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert sample categories
INSERT INTO categories (name, description) VALUES
('Vegetables', 'Fresh organic vegetables'),
('Fruits', 'Seasonal fresh fruits'),
('Grains', 'Organic grains and cereals'),
('Tools', 'Farming and gardening tools'),
('Fertilizers', 'Organic fertilizers and soil enhancers');

-- Insert sample products
INSERT INTO products (name, price, description, image, category_id, farmer_name, stock_quantity) VALUES
('Organic Tomatoes', 350.00, 'Fresh red tomatoes grown without chemicals', 'assets/images/imges/tom.jpg', 1, 'Dagim Tola', 50),
('Fresh Carrots', 288.00, 'Sweet and crunchy organic carrots', 'assets/images/imges/car.jpg', 1, 'Sumeya Tofiq', 75),
('Organic Apples', 502.00, 'Fresh apples from mountain orchards', 'assets/images/imges/apple.jpg', 2, 'Apple Valley', 30),
('Whole Wheat', 700.00, 'Organic whole wheat grains', 'assets/images/imges/wheat.jpg', 3, 'Wheat Fields', 100),
('Organic Vegetable Seeds', 200.00, 'Premium quality organic seeds for healthy cultivation', 'assets/images/imges/ov.jpg', 1, 'SeedCorp', 200),
('Organic Fertilizer', 400.00, 'Natural fertilizer for enhanced soil nutrition', 'assets/images/imges/DIY_organic_fertilizer_.jpg', 5, 'EcoFarm', 80),
('Garden Tool Set', 2000.00, 'Complete set of essential gardening tools', 'assets/images/imges/tool.jpg', 4, 'ToolMaster', 25),
('Organic Pesticide', 180.00, 'Eco-friendly pest control solution', 'assets/images/imges/OIP.webp', 5, 'EcoGuard', 60);

-- Insert admin user (password: admin123)
INSERT INTO users (name, email, password, role) VALUES
('Admin User', 'admin@agriecommerce.com', '$2y$12$9zqMC6a22slhxQmCnZdDsOuKF7cyf2kseQ6PeQyFcFaMn7Lchfc1G', 'admin');

-- Insert sample customer (password: customer123)
INSERT INTO users (name, email, password, role, phone, address) VALUES
('John Doe', 'customer@example.com', '$2y$12$WRX1mFrS1tbSgYqFvxRwa.CLTUvNIISg5U00ycWIvkh5wJwTslo3i', 'customer', '+251911223344', 'Addis Ababa, Ethiopia');