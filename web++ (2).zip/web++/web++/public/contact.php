<?php
require_once '../includes/db.php';
require_once '../includes/session.php';

$page_title = 'Contact Us';
$css_path = '../assets/css/styles.css';
$js_path = '../assets/js/main.js';
$base_url = '';

$success = '';
$error = '';

// Process contact form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitizeInput($_POST['name']);
    $email = sanitizeInput($_POST['email']);
    $subject = sanitizeInput($_POST['subject']);
    $message = sanitizeInput($_POST['message']);
    
    // Enhanced Validation
    $errors = [];
    
    // Name validation
    if (empty($name)) {
        $errors[] = 'Your name is required';
    } elseif (strlen($name) < 2) {
        $errors[] = 'Name must be at least 2 characters';
    } elseif (!preg_match('/^[a-zA-Z\s]+$/', $name)) {
        $errors[] = 'Name can only contain letters and spaces';
    }
    
    // Email validation
    if (empty($email)) {
        $errors[] = 'Email address is required';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address';
    }
    
    // Subject validation (optional but if provided must be reasonable)
    if (!empty($subject) && strlen($subject) < 3) {
        $errors[] = 'Subject must be at least 3 characters';
    }
    
    // Message validation
    if (empty($message)) {
        $errors[] = 'Message is required';
    } elseif (strlen($message) < 10) {
        $errors[] = 'Message must be at least 10 characters';
    }
    
    if (empty($errors)) {
        // Save message to database
        $sql = "INSERT INTO messages (name, email, subject, message) VALUES (?, ?, ?, ?)";
        $stmt = executeQuery($conn, $sql, [$name, $email, $subject, $message], 'ssss');
        
        if ($stmt) {
            $success = 'Thank you for your message! We will get back to you soon.';
            // Clear form data
            $_POST = [];
        } else {
            $errors[] = 'Error sending message. Please try again.';
        }
    }
    
    // Set error message for display
    if (!empty($errors)) {
        $error = implode('<br>', $errors);
    }
}

include '../includes/header.php';
?>

<!-- Page Header -->
<section class="bg-success text-white py-5 mt-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <h1 class="display-4 fw-bold mb-3">Contact Us</h1>
                <p class="lead mb-0">Get in touch with our team - we're here to help</p>
            </div>
            <div class="col-lg-4 text-lg-end">
                <i class="bi bi-envelope-heart display-1"></i>
            </div>
        </div>
    </div>
</section>

<!-- Contact Content -->
<section class="py-5">
    <div class="container">
        <div class="row g-5">
            <!-- Contact Information -->
            <div class="col-lg-4">
                <h3 class="text-success mb-4">Get in Touch</h3>
                <p class="text-muted mb-4">
                    Have questions about our products or services? We'd love to hear from you.
                </p>

                <div class="d-flex flex-column gap-4">
                    <div class="d-flex align-items-start">
                        <div class="bg-success text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 50px; height: 50px; min-width: 50px;">
                            <i class="bi bi-envelope"></i>
                        </div>
                        <div>
                            <h6 class="text-success mb-1">Email</h6>
                            <p class="mb-0 text-muted">contact@agriecommerce.com</p>
                            <small class="text-muted">We'll respond within 24 hours</small>
                        </div>
                    </div>

                    <div class="d-flex align-items-start">
                        <div class="bg-success text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 50px; height: 50px; min-width: 50px;">
                            <i class="bi bi-telephone"></i>
                        </div>
                        <div>
                            <h6 class="text-success mb-1">Phone</h6>
                            <p class="mb-0 text-muted">+251 955667788</p>
                            <small class="text-muted">Mon-Fri 8AM-6PM</small>
                        </div>
                    </div>

                    <div class="d-flex align-items-start">
                        <div class="bg-success text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 50px; height: 50px; min-width: 50px;">
                            <i class="bi bi-geo-alt"></i>
                        </div>
                        <div>
                            <h6 class="text-success mb-1">Address</h6>
                            <p class="mb-0 text-muted">Haramaya University</p>
                            <small class="text-muted">Haramaya, Ethiopia</small>
                        </div>
                    </div>

                    <div class="d-flex align-items-start">
                        <div class="bg-success text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 50px; height: 50px; min-width: 50px;">
                            <i class="bi bi-clock"></i>
                        </div>
                        <div>
                            <h6 class="text-success mb-1">Business Hours</h6>
                            <p class="mb-0 text-muted">Monday - Friday: 8:00 AM - 6:00 PM</p>
                            <small class="text-muted">Saturday: 9:00 AM - 4:00 PM</small>
                        </div>
                    </div>
                </div>

                <!-- Social Media -->
                <div class="mt-5">
                    <h6 class="text-success mb-3">Follow Us</h6>
                    <div class="d-flex gap-3">
                        <a href="#" class="btn btn-outline-success btn-sm">
                            <i class="bi bi-facebook"></i>
                        </a>
                        <a href="#" class="btn btn-outline-success btn-sm">
                            <i class="bi bi-twitter"></i>
                        </a>
                        <a href="#" class="btn btn-outline-success btn-sm">
                            <i class="bi bi-instagram"></i>
                        </a>
                        <a href="#" class="btn btn-outline-success btn-sm">
                            <i class="bi bi-linkedin"></i>
                        </a>
                    </div>
                </div>
            </div>

            <!-- Contact Form -->
            <div class="col-lg-8">
                <div class="card border-0 shadow-sm">
                    <div class="card-body p-5">
                        <h3 class="text-success mb-4">Send us a Message</h3>
                        
                        <?php if (!empty($error)): ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo htmlspecialchars($error); ?>
                        </div>
                        <?php endif; ?>

                        <?php if (!empty($success)): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo htmlspecialchars($success); ?>
                        </div>
                        <?php endif; ?>
                        
                        <form method="POST" id="contactForm">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label for="name" class="form-label">Full Name *</label>
                                    <input type="text" class="form-control" id="name" name="name" 
                                           value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="email" class="form-label">Email Address *</label>
                                    <input type="email" class="form-control" id="email" name="email" 
                                           value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" required>
                                </div>
                            </div>

                            <div class="mb-3 mt-3">
                                <label for="subject" class="form-label">Subject</label>
                                <select class="form-select" id="subject" name="subject">
                                    <option value="">Choose a subject</option>
                                    <option value="general" <?php echo (isset($_POST['subject']) && $_POST['subject'] == 'general') ? 'selected' : ''; ?>>General Inquiry</option>
                                    <option value="product" <?php echo (isset($_POST['subject']) && $_POST['subject'] == 'product') ? 'selected' : ''; ?>>Product Question</option>
                                    <option value="order" <?php echo (isset($_POST['subject']) && $_POST['subject'] == 'order') ? 'selected' : ''; ?>>Order Support</option>
                                    <option value="farmer" <?php echo (isset($_POST['subject']) && $_POST['subject'] == 'farmer') ? 'selected' : ''; ?>>Farmer Partnership</option>
                                    <option value="technical" <?php echo (isset($_POST['subject']) && $_POST['subject'] == 'technical') ? 'selected' : ''; ?>>Technical Issue</option>
                                    <option value="feedback" <?php echo (isset($_POST['subject']) && $_POST['subject'] == 'feedback') ? 'selected' : ''; ?>>Feedback</option>
                                </select>
                            </div>

                            <div class="mb-4">
                                <label for="message" class="form-label">Message *</label>
                                <textarea class="form-control" id="message" name="message" rows="6" 
                                          placeholder="Tell us how we can help you..." required><?php echo isset($_POST['message']) ? htmlspecialchars($_POST['message']) : ''; ?></textarea>
                            </div>

                            <div class="mb-4">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="newsletter" name="newsletter">
                                    <label class="form-check-label" for="newsletter">
                                        Subscribe to our newsletter for updates and special offers
                                    </label>
                                </div>
                            </div>

                            <div class="d-grid">
                                <button type="submit" class="btn btn-success btn-lg">
                                    <i class="bi bi-send"></i> Send Message
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- FAQ Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <h3 class="text-center text-success mb-5">Frequently Asked Questions</h3>
                
                <div class="accordion" id="faqAccordion">
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq1">
                                How fresh are your products?
                            </button>
                        </h2>
                        <div id="faq1" class="accordion-collapse collapse show" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Our products are harvested fresh and delivered within 24 hours. We work directly with local farmers to ensure maximum freshness and quality.
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2">
                                What are your delivery areas?
                            </button>
                        </h2>
                        <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                We currently deliver to major cities in Ethiopia including Addis Ababa, Dire Dawa, Mekelle, and surrounding areas. Check our delivery page for specific areas and schedules.
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq3">
                                How can I become a partner farmer?
                            </button>
                        </h2>
                        <div id="faq3" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Contact us through this form or call our farmer partnership line. We'll guide you through our simple onboarding process and help you start selling your products on our platform.
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq4">
                                What payment methods do you accept?
                            </button>
                        </h2>
                        <div id="faq4" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                We accept cash on delivery, mobile money (M-Birr, HelloCash), and bank transfers. Payment is secure and processed safely.
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq5">
                                Do you offer organic certification?
                            </button>
                        </h2>
                        <div id="faq5" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Yes, all our organic products are certified by recognized organic certification bodies. We ensure that our farmers follow strict organic farming practices.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include '../includes/footer.php'; ?>