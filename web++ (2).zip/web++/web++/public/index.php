<?php
require_once '../includes/db.php';
require_once '../includes/session.php';

$page_title = 'Home';
$css_path = '../assets/css/styles.css';
$js_path = '../assets/js/main.js';
$base_url = '';

// Get featured products
$featured_products = getMultipleRows($conn, "SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.status = 'active' ORDER BY p.created_at DESC LIMIT 4");

include '../includes/header.php';
?>

<!-- Hero Section -->
<section class="hero-section bg-success text-white">
    <div class="container">
        <div class="row align-items-center min-vh-100 pt-5">
            <div class="col-lg-6">
                <h2 class="text-success-emphasis mb-3">Fresh Organic Produce</h2>
                <h1 class="display-4 fw-bold mb-4">Direct from Local Farmers</h1>
                <p class="lead mb-4">
                    Buy fresh vegetables, fruits, grains, and dairy products directly from trusted farmers.
                    Supporting local agriculture has never been easier.
                </p>
                <div class="d-flex gap-3 flex-wrap">
                    <a href="products.php" class="btn btn-warning btn-lg px-4">
                        <i class="bi bi-shop"></i> Shop Now
                    </a>
                    <a href="#farmers" class="btn btn-outline-light btn-lg px-4">
                        <i class="bi bi-people"></i> Meet Our Farmers
                    </a>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="row g-3">
                    <div class="col-6">
                        <div class="card bg-transparent border-0">
                            <img src="../assets/images/imges/fresh.avif" class="card-img rounded-3 shadow" alt="Fresh Vegetables">
                            <div class="card-img-overlay d-flex align-items-end">
                                <h5 class="card-title text-white bg-dark bg-opacity-75 px-3 py-2 rounded">Fresh Vegetables</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="card bg-transparent border-0">
                            <img src="../assets/images/imges/grain.jpg" class="card-img rounded-3 shadow" alt="Quality Grains">
                            <div class="card-img-overlay d-flex align-items-end">
                                <h5 class="card-title text-white bg-dark bg-opacity-75 px-3 py-2 rounded">Quality Grains</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="card bg-transparent border-0">
                            <img src="../assets/images/imges/orginc.jpg" class="card-img rounded-3 shadow" alt="Organic Fruits" style="height: 200px; object-fit: cover;">
                            <div class="card-img-overlay d-flex align-items-end">
                                <h5 class="card-title text-white bg-dark bg-opacity-75 px-3 py-2 rounded">Organic Fruits</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Featured Products Section -->
<section id="products" class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="display-5 fw-bold text-success">Featured Products</h2>
            <p class="lead text-muted">Fresh from the farm, delivered to you</p>
        </div>

        <div class="row g-4">
            <?php foreach ($featured_products as $product): ?>
            <div class="col-lg-3 col-md-6">
                <div class="card h-100 shadow-sm border-0">
                    <img src="../<?php echo htmlspecialchars($product['image']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($product['name']); ?>" style="height: 200px; object-fit: cover;">
                    <div class="card-body d-flex flex-column">
                        <h5 class="card-title text-success"><?php echo htmlspecialchars($product['name']); ?></h5>
                        <p class="card-text text-muted"><?php echo htmlspecialchars(substr($product['description'], 0, 60)) . '...'; ?></p>
                        <div class="mt-auto">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <span class="h5 text-success mb-0"><?php echo number_format($product['price'], 2); ?> Birr</span>
                                <small class="text-muted">By: <?php echo htmlspecialchars($product['farmer_name']); ?></small>
                            </div>
                            <div class="d-grid gap-2">
                                <button class="btn btn-success add-to-cart-btn" 
                                        data-product-id="<?php echo $product['id']; ?>"
                                        data-product-name="<?php echo htmlspecialchars($product['name']); ?>">
                                    <i class="bi bi-cart-plus"></i> Add to Cart
                                </button>
                                <a href="product.php?id=<?php echo $product['id']; ?>" class="btn btn-outline-warning">
                                    <i class="bi bi-eye"></i> View Details
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <div class="text-center mt-5">
            <a href="products.php" class="btn btn-outline-success btn-lg">
                <i class="bi bi-arrow-right"></i> View All Products
            </a>
        </div>
    </div>
</section>

<!-- Farmers Section -->
<section id="farmers" class="py-5 bg-light">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="display-5 fw-bold text-success">Our Trusted Farmers</h2>
            <p class="lead text-muted">Meet the people who grow your food</p>
        </div>

        <div class="row g-4">
            <div class="col-lg-4 col-md-6">
                <div class="card h-100 shadow-sm border-0">
                    <img src="../assets/images/imges/dagi.jpg" class="card-img-top" alt="Dagim Tola" style="height: 250px; object-fit: cover;">
                    <div class="card-body text-center">
                        <h5 class="card-title text-success">Dagim Tola</h5>
                        <p class="text-muted mb-2">Green Valley Farm</p>
                        <p class="card-text">Specializes in vegetables and herbs</p>
                        <div class="text-warning mb-3">
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <span class="text-muted ms-2">(4.8)</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6">
                <div class="card h-100 shadow-sm border-0">
                    <img src="../assets/images/imges/Sumeya.jpg" class="card-img-top" alt="Sumeya Tofiq" style="height: 250px; object-fit: cover;">
                    <div class="card-body text-center">
                        <h5 class="card-title text-success">Sumeya Tofiq</h5>
                        <p class="text-muted mb-2">Organic Orchard</p>
                        <p class="card-text">Fruit specialist - apples, oranges</p>
                        <div class="text-warning mb-3">
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <span class="text-muted ms-2">(4.9)</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6">
                <div class="card h-100 shadow-sm border-0">
                    <img src="../assets/images/imges/nejib.jpg" class="card-img-top" alt="Nejib" style="height: 250px; object-fit: cover;">
                    <div class="card-body text-center">
                        <h5 class="card-title text-success">Nejib</h5>
                        <p class="text-muted mb-2">Rice Fields Co.</p>
                        <p class="card-text">Grains and rice production</p>
                        <div class="text-warning mb-3">
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star"></i>
                            <span class="text-muted ms-2">(4.6)</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- About Section -->
<section id="about" class="py-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8 mx-auto text-center">
                <h2 class="display-5 fw-bold text-success mb-4">About AgriE-Commerce</h2>
                <p class="lead mb-5">
                    We connect local farmers directly with consumers, eliminating middlemen and ensuring fair prices
                    for both farmers and customers. Our platform makes it easy to buy fresh, organic produce while
                    supporting sustainable agriculture.
                </p>

                <div class="row g-4">
                    <div class="col-md-4">
                        <div class="text-center">
                            <div class="bg-success text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px;">
                                <i class="bi bi-truck fs-2"></i>
                            </div>
                            <h5 class="text-success">Fast Delivery</h5>
                            <p class="text-muted">Harvested fresh and delivered within 24 hours</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="text-center">
                            <div class="bg-success text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px;">
                                <i class="bi bi-heart fs-2"></i>
                            </div>
                            <h5 class="text-success">Support Local</h5>
                            <p class="text-muted">100% of profit goes directly to farmers</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="text-center">
                            <div class="bg-success text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px;">
                                <i class="bi bi-shield-check fs-2"></i>
                            </div>
                            <h5 class="text-success">Quality Guaranteed</h5>
                            <p class="text-muted">All products are quality checked and certified</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include '../includes/footer.php'; ?>