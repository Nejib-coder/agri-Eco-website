<?php
require_once '../includes/db.php';
require_once '../includes/session.php';

// Require login to view orders
requireLogin('login.php?redirect=orders.php');

$page_title = 'My Orders';
$css_path = '../assets/css/styles.css';
$js_path = '../assets/js/main.js';
$base_url = '';

$current_user = getCurrentUser();

// Get filter parameter
$status_filter = isset($_GET['status']) ? sanitizeInput($_GET['status']) : '';

// Build query with filters
$where_conditions = ["o.user_id = ?"];
$params = [$current_user['id']];
$types = 'i';

if (!empty($status_filter)) {
    $where_conditions[] = "o.status = ?";
    $params[] = $status_filter;
    $types .= 's';
}

$where_clause = 'WHERE ' . implode(' AND ', $where_conditions);

// Get user's orders
$orders = getMultipleRows($conn, "
    SELECT o.* 
    FROM orders o 
    $where_clause
    ORDER BY o.created_at DESC
", $params, $types);

// Get order statistics for this user
$total_orders = getSingleRow($conn, "SELECT COUNT(*) as count FROM orders WHERE user_id = ?", [$current_user['id']], 'i')['count'];
$pending_orders = getSingleRow($conn, "SELECT COUNT(*) as count FROM orders WHERE user_id = ? AND status = 'pending'", [$current_user['id']], 'i')['count'];
$delivered_orders = getSingleRow($conn, "SELECT COUNT(*) as count FROM orders WHERE user_id = ? AND status = 'delivered'", [$current_user['id']], 'i')['count'];

include '../includes/header.php';
?>

<!-- Page Header -->
<section class="bg-success text-white py-4 mt-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <h1 class="h2 fw-bold mb-2">My Orders</h1>
                <p class="mb-0">Track and manage your orders</p>
            </div>
            <div class="col-lg-4 text-lg-end">
                <a href="products.php" class="btn btn-outline-light">
                    <i class="bi bi-cart-plus"></i> Continue Shopping
                </a>
            </div>
        </div>
    </div>
</section>

<!-- Order Statistics -->
<section class="py-4">
    <div class="container">
        <div class="row g-3">
            <div class="col-lg-4 col-md-6">
                <div class="card border-0 shadow-sm">
                    <div class="card-body text-center">
                        <h3 class="text-primary mb-1"><?php echo $total_orders; ?></h3>
                        <p class="text-muted mb-0">Total Orders</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="card border-0 shadow-sm">
                    <div class="card-body text-center">
                        <h3 class="text-warning mb-1"><?php echo $pending_orders; ?></h3>
                        <p class="text-muted mb-0">Pending Orders</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="card border-0 shadow-sm">
                    <div class="card-body text-center">
                        <h3 class="text-success mb-1"><?php echo $delivered_orders; ?></h3>
                        <p class="text-muted mb-0">Delivered Orders</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Filter Section -->
<section class="py-3">
    <div class="container">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <form method="GET" class="row g-3 align-items-end">
                    <div class="col-md-10">
                        <label class="form-label">Filter by Status</label>
                        <select name="status" class="form-select">
                            <option value="">All Orders</option>
                            <option value="pending" <?php echo $status_filter == 'pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="processing" <?php echo $status_filter == 'processing' ? 'selected' : ''; ?>>Processing</option>
                            <option value="shipped" <?php echo $status_filter == 'shipped' ? 'selected' : ''; ?>>Shipped</option>
                            <option value="delivered" <?php echo $status_filter == 'delivered' ? 'selected' : ''; ?>>Delivered</option>
                            <option value="cancelled" <?php echo $status_filter == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-success w-100">
                            <i class="bi bi-funnel"></i> Filter
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- Orders List -->
<section class="pb-5">
    <div class="container">
        <?php if (empty($orders)): ?>
        <div class="card border-0 shadow-sm">
            <div class="card-body p-5 text-center">
                <i class="bi bi-inbox display-1 text-muted mb-3"></i>
                <h4>No Orders Found</h4>
                <p class="text-muted mb-4">You haven't placed any orders yet</p>
                <a href="products.php" class="btn btn-success">
                    <i class="bi bi-cart-plus"></i> Start Shopping
                </a>
            </div>
        </div>
        <?php else: ?>
        <div class="row g-4">
            <?php foreach ($orders as $order): ?>
            <div class="col-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-lg-2 col-md-3">
                                <h6 class="text-muted mb-1">Order ID</h6>
                                <h5 class="mb-0">#<?php echo str_pad($order['id'], 6, '0', STR_PAD_LEFT); ?></h5>
                            </div>
                            <div class="col-lg-2 col-md-3">
                                <h6 class="text-muted mb-1">Date</h6>
                                <p class="mb-0"><?php echo date('M d, Y', strtotime($order['created_at'])); ?></p>
                                <small class="text-muted"><?php echo date('H:i', strtotime($order['created_at'])); ?></small>
                            </div>
                            <div class="col-lg-2 col-md-3">
                                <h6 class="text-muted mb-1">Total</h6>
                                <h5 class="text-success mb-0"><?php echo number_format($order['total_price'], 2); ?> Birr</h5>
                            </div>
                            <div class="col-lg-2 col-md-3">
                                <h6 class="text-muted mb-1">Status</h6>
                                <span class="badge bg-<?php 
                                    echo $order['status'] == 'pending' ? 'warning' : 
                                        ($order['status'] == 'processing' ? 'info' : 
                                        ($order['status'] == 'shipped' ? 'primary' : 
                                        ($order['status'] == 'delivered' ? 'success' : 'danger'))); 
                                ?>">
                                    <?php echo ucfirst($order['status']); ?>
                                </span>
                            </div>
                            <div class="col-lg-2 col-md-3">
                                <h6 class="text-muted mb-1">Payment</h6>
                                <span class="badge bg-secondary"><?php echo ucfirst($order['payment_method']); ?></span><br>
                                <span class="badge bg-<?php 
                                    echo $order['payment_status'] == 'paid' ? 'success' : 
                                        ($order['payment_status'] == 'failed' ? 'danger' : 'warning'); 
                                ?> mt-1">
                                    <?php echo ucfirst($order['payment_status']); ?>
                                </span>
                            </div>
                            <div class="col-lg-2 col-md-6 text-lg-end">
                                <button class="btn btn-outline-success btn-sm mb-1" onclick="viewOrder(<?php echo $order['id']; ?>)">
                                    <i class="bi bi-eye"></i> View Details
                                </button>
                                <?php if ($order['payment_status'] == 'unpaid' && $order['payment_method'] != 'cash'): ?>
                                <a href="payment_instructions.php?order_id=<?php echo $order['id']; ?>" class="btn btn-warning btn-sm">
                                    <i class="bi bi-credit-card"></i> Pay Now
                                </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</section>

<!-- Order Details Modal -->
<div class="modal fade" id="orderDetailsModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Order Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="orderDetailsContent">
                <div class="text-center py-5">
                    <div class="spinner-border text-success" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function viewOrder(orderId) {
    const modal = new bootstrap.Modal(document.getElementById('orderDetailsModal'));
    const content = document.getElementById('orderDetailsContent');
    
    // Show loading
    content.innerHTML = `
        <div class="text-center py-5">
            <div class="spinner-border text-success" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
    `;
    
    modal.show();
    
    // Fetch order details
    fetch(`ajax/order_details.php?id=${orderId}`)
        .then(response => response.text())
        .then(html => {
            content.innerHTML = html;
        })
        .catch(error => {
            content.innerHTML = `
                <div class="alert alert-danger">
                    <i class="bi bi-exclamation-triangle"></i>
                    Error loading order details. Please try again.
                </div>
            `;
        });
}
</script>

<?php include '../includes/footer.php'; ?>
