<?php
require_once '../includes/db.php';
require_once '../includes/session.php';

$page_title = 'Products';
$css_path = '../assets/css/styles.css';
$js_path = '../assets/js/main.js';
$base_url = '';

// Get search and filter parameters
$search = isset($_GET['search']) ? sanitizeInput($_GET['search']) : '';
$category_id = isset($_GET['category']) ? (int)$_GET['category'] : 0;
$sort = isset($_GET['sort']) ? sanitizeInput($_GET['sort']) : 'name';

// Build query
$where_conditions = ["p.status = 'active'"];
$params = [];
$types = '';

if (!empty($search)) {
    $where_conditions[] = "(p.name LIKE ? OR p.description LIKE ?)";
    $search_param = "%$search%";
    $params[] = $search_param;
    $params[] = $search_param;
    $types .= 'ss';
}

if ($category_id > 0) {
    $where_conditions[] = "p.category_id = ?";
    $params[] = $category_id;
    $types .= 'i';
}

$where_clause = implode(' AND ', $where_conditions);

// Determine sort order
$order_by = 'p.name ASC';
switch ($sort) {
    case 'price-low':
        $order_by = 'p.price ASC';
        break;
    case 'price-high':
        $order_by = 'p.price DESC';
        break;
    case 'newest':
        $order_by = 'p.created_at DESC';
        break;
}

// Get products
$sql = "SELECT p.*, c.name as category_name FROM products p 
        LEFT JOIN categories c ON p.category_id = c.id 
        WHERE $where_clause 
        ORDER BY $order_by";

$products = getMultipleRows($conn, $sql, $params, $types);

// Get categories for filter
$categories = getMultipleRows($conn, "SELECT * FROM categories ORDER BY name");

include '../includes/header.php';
?>

<!-- Page Header -->
<section class="bg-success text-white py-5 mt-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <h1 class="display-4 fw-bold mb-3">Our Products</h1>
                <p class="lead mb-0">Fresh, organic produce directly from local farmers</p>
            </div>
            <div class="col-lg-4 text-lg-end">
                <div class="d-flex align-items-center justify-content-lg-end gap-3">
                    <i class="bi bi-box-seam fs-1"></i>
                    <div>
                        <div class="h4 mb-0"><?php echo count($products); ?>+</div>
                        <small>Products Available</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Filters and Search -->
<section class="py-4 bg-light">
    <div class="container">
        <form method="GET" class="row g-3 align-items-center">
            <div class="col-lg-4">
                <div class="input-group">
                    <span class="input-group-text bg-white border-end-0">
                        <i class="bi bi-search text-muted"></i>
                    </span>
                    <input type="text" class="form-control border-start-0" name="search" 
                           placeholder="Search products..." value="<?php echo htmlspecialchars($search); ?>" id="searchInput">
                </div>
            </div>
            <div class="col-lg-2">
                <select class="form-select" name="category" id="categoryFilter">
                    <option value="">All Categories</option>
                    <?php foreach ($categories as $category): ?>
                    <option value="<?php echo $category['id']; ?>" <?php echo $category_id == $category['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($category['name']); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-lg-2">
                <select class="form-select" name="sort" id="sortFilter">
                    <option value="name" <?php echo $sort == 'name' ? 'selected' : ''; ?>>Sort by Name</option>
                    <option value="price-low" <?php echo $sort == 'price-low' ? 'selected' : ''; ?>>Price: Low to High</option>
                    <option value="price-high" <?php echo $sort == 'price-high' ? 'selected' : ''; ?>>Price: High to Low</option>
                    <option value="newest" <?php echo $sort == 'newest' ? 'selected' : ''; ?>>Newest First</option>
                </select>
            </div>
            <div class="col-lg-2">
                <button type="submit" class="btn btn-success w-100">
                    <i class="bi bi-funnel"></i> Filter
                </button>
            </div>
            <div class="col-lg-2 text-end">
                <span class="text-muted" id="productCount">Showing <?php echo count($products); ?> products</span>
            </div>
        </form>
    </div>
</section>

<!-- Products Grid -->
<section class="py-5">
    <div class="container">
        <?php if (empty($products)): ?>
        <div class="text-center py-5">
            <i class="bi bi-search display-1 text-muted mb-3"></i>
            <h3 class="text-muted">No products found</h3>
            <p class="text-muted">Try adjusting your search criteria or browse all products.</p>
            <a href="products.php" class="btn btn-success">View All Products</a>
        </div>
        <?php else: ?>
        <div class="row g-4" id="productsContainer">
            <?php foreach ($products as $product): ?>
            <div class="col-lg-3 col-md-6 product-item" 
                 data-category="<?php echo strtolower($product['category_name']); ?>" 
                 data-price="<?php echo $product['price']; ?>" 
                 data-name="<?php echo htmlspecialchars($product['name']); ?>">
                <div class="card h-100 shadow-sm border-0 product-card">
                    <div class="position-relative">
                        <img src="../<?php echo htmlspecialchars($product['image']); ?>" 
                             class="card-img-top" alt="<?php echo htmlspecialchars($product['name']); ?>" 
                             style="height: 200px; object-fit: cover;">
                        <div class="position-absolute top-0 end-0 m-2">
                            <span class="badge bg-success">Fresh</span>
                        </div>
                        <div class="position-absolute top-0 start-0 m-2">
                            <button class="btn btn-light btn-sm rounded-circle" title="Add to Wishlist">
                                <i class="bi bi-heart"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body d-flex flex-column">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <h5 class="card-title text-success mb-0"><?php echo htmlspecialchars($product['name']); ?></h5>
                            <div class="text-warning">
                                <i class="bi bi-star-fill"></i>
                                <i class="bi bi-star-fill"></i>
                                <i class="bi bi-star-fill"></i>
                                <i class="bi bi-star-fill"></i>
                                <i class="bi bi-star-half"></i>
                                <small class="text-muted ms-1">(4.5)</small>
                            </div>
                        </div>
                        <p class="card-text text-muted small"><?php echo htmlspecialchars(substr($product['description'], 0, 80)) . '...'; ?></p>
                        <div class="mt-auto">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <div>
                                    <span class="h5 text-success mb-0"><?php echo number_format($product['price'], 2); ?> Birr</span>
                                    <small class="text-muted d-block">Stock: <?php echo $product['stock_quantity']; ?></small>
                                </div>
                                <small class="text-muted">By: <?php echo htmlspecialchars($product['farmer_name']); ?></small>
                            </div>
                            <div class="d-flex gap-2">
                                <button class="btn btn-success flex-fill btn-sm add-to-cart-btn" 
                                        data-product-id="<?php echo $product['id']; ?>"
                                        data-product-name="<?php echo htmlspecialchars($product['name']); ?>"
                                        <?php echo $product['stock_quantity'] <= 0 ? 'disabled' : ''; ?>>
                                    <i class="bi bi-cart-plus"></i> 
                                    <?php echo $product['stock_quantity'] <= 0 ? 'Out of Stock' : 'Add to Cart'; ?>
                                </button>
                                <a href="product.php?id=<?php echo $product['id']; ?>" class="btn btn-outline-success btn-sm" title="View Details">
                                    <i class="bi bi-eye"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</section>

<?php include '../includes/footer.php'; ?>

<script>
// Auto-submit form when filters change
document.getElementById('categoryFilter').addEventListener('change', function() {
    this.form.submit();
});

document.getElementById('sortFilter').addEventListener('change', function() {
    this.form.submit();
});
</script>