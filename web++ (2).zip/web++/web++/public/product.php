<?php
require_once '../includes/db.php';
require_once '../includes/session.php';

// Get product ID
$product_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($product_id <= 0) {
    header('Location: products.php');
    exit;
}

// Get product details
$product = getSingleRow($conn, "SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.id = ? AND p.status = 'active'", [$product_id], 'i');

if (!$product) {
    header('Location: products.php');
    exit;
}

$page_title = $product['name'];
$css_path = '../assets/css/styles.css';
$js_path = '../assets/js/main.js';
$base_url = '';

// Get related products
$related_products = getMultipleRows($conn, "SELECT * FROM products WHERE category_id = ? AND id != ? AND status = 'active' ORDER BY RAND() LIMIT 4", [$product['category_id'], $product_id], 'ii');

include '../includes/header.php';
?>

<!-- Product Details -->
<section class="py-5 mt-5">
    <div class="container">
        <nav aria-label="breadcrumb" class="mb-4">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php" class="text-decoration-none">Home</a></li>
                <li class="breadcrumb-item"><a href="products.php" class="text-decoration-none">Products</a></li>
                <li class="breadcrumb-item"><a href="products.php?category=<?php echo $product['category_id']; ?>" class="text-decoration-none"><?php echo htmlspecialchars($product['category_name']); ?></a></li>
                <li class="breadcrumb-item active"><?php echo htmlspecialchars($product['name']); ?></li>
            </ol>
        </nav>

        <div class="row g-5">
            <!-- Product Image -->
            <div class="col-lg-6">
                <div class="card border-0 shadow-sm">
                    <img src="../<?php echo htmlspecialchars($product['image']); ?>" 
                         class="card-img-top" alt="<?php echo htmlspecialchars($product['name']); ?>" 
                         style="height: 400px; object-fit: cover;">
                </div>
                
                <!-- Additional Images Placeholder -->
                <div class="row g-2 mt-3">
                    <div class="col-3">
                        <img src="../<?php echo htmlspecialchars($product['image']); ?>" 
                             class="img-fluid rounded border" alt="Product view 1" 
                             style="height: 80px; object-fit: cover; cursor: pointer;">
                    </div>
                    <div class="col-3">
                        <img src="../<?php echo htmlspecialchars($product['image']); ?>" 
                             class="img-fluid rounded border opacity-75" alt="Product view 2" 
                             style="height: 80px; object-fit: cover; cursor: pointer;">
                    </div>
                    <div class="col-3">
                        <img src="../<?php echo htmlspecialchars($product['image']); ?>" 
                             class="img-fluid rounded border opacity-75" alt="Product view 3" 
                             style="height: 80px; object-fit: cover; cursor: pointer;">
                    </div>
                    <div class="col-3">
                        <img src="../<?php echo htmlspecialchars($product['image']); ?>" 
                             class="img-fluid rounded border opacity-75" alt="Product view 4" 
                             style="height: 80px; object-fit: cover; cursor: pointer;">
                    </div>
                </div>
            </div>

            <!-- Product Info -->
            <div class="col-lg-6">
                <div class="mb-3">
                    <span class="badge bg-success mb-2"><?php echo htmlspecialchars($product['category_name']); ?></span>
                    <h1 class="display-6 fw-bold text-success mb-3"><?php echo htmlspecialchars($product['name']); ?></h1>
                    
                    <!-- Rating -->
                    <div class="d-flex align-items-center mb-3">
                        <div class="text-warning me-2">
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-half"></i>
                        </div>
                        <span class="text-muted">(4.5) • 127 reviews</span>
                    </div>
                </div>

                <!-- Price -->
                <div class="mb-4">
                    <div class="d-flex align-items-baseline gap-3">
                        <span class="display-5 fw-bold text-success"><?php echo number_format($product['price'], 2); ?> Birr</span>
                        <span class="text-muted text-decoration-line-through">₹<?php echo number_format($product['price'] * 1.2, 2); ?></span>
                        <span class="badge bg-warning text-dark">17% OFF</span>
                    </div>
                    <small class="text-muted">Price per unit • Free shipping on orders over 1000 Birr</small>
                </div>

                <!-- Description -->
                <div class="mb-4">
                    <h5 class="text-success mb-3">Product Description</h5>
                    <p class="text-muted"><?php echo nl2br(htmlspecialchars($product['description'])); ?></p>
                </div>

                <!-- Product Details -->
                <div class="mb-4">
                    <h5 class="text-success mb-3">Product Details</h5>
                    <div class="row g-3">
                        <div class="col-6">
                            <div class="d-flex justify-content-between">
                                <span class="text-muted">Farmer:</span>
                                <span class="fw-bold"><?php echo htmlspecialchars($product['farmer_name']); ?></span>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="d-flex justify-content-between">
                                <span class="text-muted">Stock:</span>
                                <span class="fw-bold <?php echo $product['stock_quantity'] > 10 ? 'text-success' : 'text-warning'; ?>">
                                    <?php echo $product['stock_quantity']; ?> units
                                </span>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="d-flex justify-content-between">
                                <span class="text-muted">Category:</span>
                                <span class="fw-bold"><?php echo htmlspecialchars($product['category_name']); ?></span>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="d-flex justify-content-between">
                                <span class="text-muted">Freshness:</span>
                                <span class="fw-bold text-success">Farm Fresh</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Quantity and Add to Cart -->
                <div class="mb-4">
                    <div class="row g-3 align-items-end">
                        <div class="col-md-4">
                            <label for="quantity" class="form-label">Quantity</label>
                            <div class="input-group">
                                <button class="btn btn-outline-secondary" type="button" onclick="changeQuantity(-1)">
                                    <i class="bi bi-dash"></i>
                                </button>
                                <input type="number" class="form-control text-center" id="quantity" value="1" min="1" max="<?php echo $product['stock_quantity']; ?>">
                                <button class="btn btn-outline-secondary" type="button" onclick="changeQuantity(1)">
                                    <i class="bi bi-plus"></i>
                                </button>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="d-grid gap-2">
                                <button class="btn btn-success btn-lg add-to-cart-btn" 
                                        data-product-id="<?php echo $product['id']; ?>"
                                        data-product-name="<?php echo htmlspecialchars($product['name']); ?>"
                                        <?php echo $product['stock_quantity'] <= 0 ? 'disabled' : ''; ?>>
                                    <i class="bi bi-cart-plus"></i> 
                                    <?php echo $product['stock_quantity'] <= 0 ? 'Out of Stock' : 'Add to Cart'; ?>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Action Buttons -->
                <div class="d-flex gap-3 mb-4">
                    <button class="btn btn-outline-success">
                        <i class="bi bi-heart"></i> Add to Wishlist
                    </button>
                    <button class="btn btn-outline-success">
                        <i class="bi bi-share"></i> Share
                    </button>
                    <button class="btn btn-outline-success">
                        <i class="bi bi-flag"></i> Report
                    </button>
                </div>

                <!-- Delivery Info -->
                <div class="card bg-light border-0">
                    <div class="card-body">
                        <h6 class="text-success mb-3">Delivery Information</h6>
                        <div class="row g-2">
                            <div class="col-12">
                                <div class="d-flex align-items-center">
                                    <i class="bi bi-truck text-success me-2"></i>
                                    <span>Free delivery on orders over 1000 Birr</span>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="d-flex align-items-center">
                                    <i class="bi bi-clock text-success me-2"></i>
                                    <span>Delivered within 24 hours</span>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="d-flex align-items-center">
                                    <i class="bi bi-shield-check text-success me-2"></i>
                                    <span>Quality guaranteed or money back</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Related Products -->
<?php if (!empty($related_products)): ?>
<section class="py-5 bg-light">
    <div class="container">
        <h3 class="text-center text-success mb-5">Related Products</h3>
        <div class="row g-4">
            <?php foreach ($related_products as $related): ?>
            <div class="col-lg-3 col-md-6">
                <div class="card h-100 shadow-sm border-0">
                    <img src="../<?php echo htmlspecialchars($related['image']); ?>" 
                         class="card-img-top" alt="<?php echo htmlspecialchars($related['name']); ?>" 
                         style="height: 200px; object-fit: cover;">
                    <div class="card-body d-flex flex-column">
                        <h6 class="card-title text-success"><?php echo htmlspecialchars($related['name']); ?></h6>
                        <p class="card-text text-muted small"><?php echo htmlspecialchars(substr($related['description'], 0, 60)) . '...'; ?></p>
                        <div class="mt-auto">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <span class="fw-bold text-success"><?php echo number_format($related['price'], 2); ?> Birr</span>
                                <small class="text-muted">By: <?php echo htmlspecialchars($related['farmer_name']); ?></small>
                            </div>
                            <div class="d-grid">
                                <a href="product.php?id=<?php echo $related['id']; ?>" class="btn btn-outline-success btn-sm">
                                    View Details
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>

<script>
function changeQuantity(change) {
    const quantityInput = document.getElementById('quantity');
    const currentValue = parseInt(quantityInput.value);
    const maxValue = parseInt(quantityInput.max);
    const newValue = Math.max(1, Math.min(maxValue, currentValue + change));
    quantityInput.value = newValue;
}

// Override add to cart to include quantity
document.addEventListener('DOMContentLoaded', function() {
    const addToCartBtn = document.querySelector('.add-to-cart-btn');
    if (addToCartBtn) {
        addToCartBtn.addEventListener('click', function() {
            const productId = this.dataset.productId;
            const productName = this.dataset.productName;
            const quantity = parseInt(document.getElementById('quantity').value);
            
            fetch('ajax/cart_operations.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: `action=add&product_id=${productId}&quantity=${quantity}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showNotification(`${quantity} x ${productName} added to cart!`, 'success');
                    updateCartBadge();
                } else {
                    showNotification(data.message || 'Error adding to cart', 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showNotification('Error adding to cart', 'error');
            });
        });
    }
});
</script>