<?php
require_once '../includes/db.php';
require_once '../includes/session.php';

// Require login
requireLogin();

$page_title = 'My Profile';
$css_path = '../assets/css/styles.css';
$js_path = '../assets/js/main.js';
$base_url = './';

$user = getCurrentUser();
$user_details = getSingleRow($conn, "SELECT * FROM users WHERE id = ?", [$user['id']], 'i');

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'update_profile') {
            $name = sanitizeInput($_POST['name']);
            $phone = sanitizeInput($_POST['phone']);
            $address = sanitizeInput($_POST['address']);
            
            $sql = "UPDATE users SET name = ?, phone = ?, address = ? WHERE id = ?";
            executeQuery($conn, $sql, [$name, $phone, $address, $user['id']], 'sssi');
            
            // Update session
            $_SESSION['user_name'] = $name;
            
            setFlashMessage('success', 'Profile updated successfully!');
            header('Location: profile.php');
            exit();
        } elseif ($_POST['action'] == 'change_password') {
            $current_password = $_POST['current_password'];
            $new_password = $_POST['new_password'];
            $confirm_password = $_POST['confirm_password'];
            
            // Verify current password
            if (!password_verify($current_password, $user_details['password'])) {
                setFlashMessage('error', 'Current password is incorrect!');
            } elseif ($new_password !== $confirm_password) {
                setFlashMessage('error', 'New passwords do not match!');
            } elseif (strlen($new_password) < 6) {
                setFlashMessage('error', 'New password must be at least 6 characters long!');
            } else {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                executeQuery($conn, "UPDATE users SET password = ? WHERE id = ?", [$hashed_password, $user['id']], 'si');
                setFlashMessage('success', 'Password changed successfully!');
            }
            
            header('Location: profile.php');
            exit();
        }
    }
}

// Get user statistics
$total_orders = getSingleRow($conn, "SELECT COUNT(*) as count FROM orders WHERE user_id = ?", [$user['id']], 'i')['count'];
$total_spent = getSingleRow($conn, "SELECT COALESCE(SUM(total_price), 0) as total FROM orders WHERE user_id = ? AND status != 'cancelled'", [$user['id']], 'i')['total'];
$pending_orders = getSingleRow($conn, "SELECT COUNT(*) as count FROM orders WHERE user_id = ? AND status = 'pending'", [$user['id']], 'i')['count'];

include '../includes/header.php';
?>

<!-- Profile Header -->
<section class="bg-success text-white py-5 mt-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <h1 class="h2 fw-bold mb-2">My Profile</h1>
                <p class="mb-0">Manage your account information and preferences</p>
            </div>
            <div class="col-lg-4 text-lg-end">
                <a href="orders.php" class="btn btn-outline-light me-2">
                    <i class="bi bi-list-ul"></i> My Orders
                </a>
                <a href="index.php" class="btn btn-warning">
                    <i class="bi bi-house"></i> Home
                </a>
            </div>
        </div>
    </div>
</section>

<!-- Flash Messages -->
<?php 
$flash = getFlashMessage();
if ($flash): 
?>
<div class="container mt-3">
    <div class="alert alert-<?php echo $flash['type'] == 'success' ? 'success' : 'danger'; ?> alert-dismissible fade show">
        <?php echo htmlspecialchars($flash['message']); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
</div>
<?php endif; ?>

<!-- Profile Content -->
<section class="py-5">
    <div class="container">
        <div class="row g-4">
            <!-- Profile Stats -->
            <div class="col-lg-4">
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-body text-center">
                        <div class="bg-success text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px;">
                            <i class="bi bi-person-fill fs-1"></i>
                        </div>
                        <h4 class="fw-bold"><?php echo htmlspecialchars($user_details['name']); ?></h4>
                        <p class="text-muted mb-0"><?php echo htmlspecialchars($user_details['email']); ?></p>
                        <small class="text-muted">Member since <?php echo date('M Y', strtotime($user_details['created_at'])); ?></small>
                    </div>
                </div>

                <!-- Quick Stats -->
                <div class="row g-3">
                    <div class="col-6">
                        <div class="card border-0 shadow-sm">
                            <div class="card-body text-center">
                                <h3 class="text-primary mb-1"><?php echo $total_orders; ?></h3>
                                <p class="text-muted mb-0 small">Total Orders</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="card border-0 shadow-sm">
                            <div class="card-body text-center">
                                <h3 class="text-success mb-1"><?php echo number_format($total_spent, 0); ?></h3>
                                <p class="text-muted mb-0 small">Total Spent (Birr)</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="card border-0 shadow-sm">
                            <div class="card-body text-center">
                                <h3 class="text-warning mb-1"><?php echo $pending_orders; ?></h3>
                                <p class="text-muted mb-0 small">Pending Orders</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Profile Forms -->
            <div class="col-lg-8">
                <!-- Update Profile -->
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-header bg-light">
                        <h5 class="mb-0">
                            <i class="bi bi-person-gear me-2"></i>Update Profile Information
                        </h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <input type="hidden" name="action" value="update_profile">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">Full Name *</label>
                                    <input type="text" class="form-control" name="name" value="<?php echo htmlspecialchars($user_details['name']); ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Email Address</label>
                                    <input type="email" class="form-control" value="<?php echo htmlspecialchars($user_details['email']); ?>" disabled>
                                    <small class="text-muted">Email cannot be changed</small>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Phone Number</label>
                                    <input type="tel" class="form-control" name="phone" value="<?php echo htmlspecialchars($user_details['phone'] ?? ''); ?>" placeholder="+251911223344">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Account Type</label>
                                    <input type="text" class="form-control" value="<?php echo ucfirst($user_details['role']); ?>" disabled>
                                </div>
                                <div class="col-12">
                                    <label class="form-label">Address</label>
                                    <textarea class="form-control" name="address" rows="3" placeholder="Enter your full address"><?php echo htmlspecialchars($user_details['address'] ?? ''); ?></textarea>
                                </div>
                                <div class="col-12">
                                    <button type="submit" class="btn btn-success">
                                        <i class="bi bi-check-circle"></i> Update Profile
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Change Password -->
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-light">
                        <h5 class="mb-0">
                            <i class="bi bi-shield-lock me-2"></i>Change Password
                        </h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" id="changePasswordForm">
                            <input type="hidden" name="action" value="change_password">
                            <div class="row g-3">
                                <div class="col-12">
                                    <label class="form-label">Current Password *</label>
                                    <input type="password" class="form-control" name="current_password" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">New Password *</label>
                                    <input type="password" class="form-control" name="new_password" id="newPassword" required minlength="6">
                                    <small class="text-muted">Minimum 6 characters</small>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Confirm New Password *</label>
                                    <input type="password" class="form-control" name="confirm_password" id="confirmPassword" required>
                                    <div class="invalid-feedback" id="passwordMismatch">
                                        Passwords do not match
                                    </div>
                                </div>
                                <div class="col-12">
                                    <button type="submit" class="btn btn-warning">
                                        <i class="bi bi-key"></i> Change Password
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
// Password confirmation validation
document.getElementById('changePasswordForm').addEventListener('submit', function(e) {
    const newPassword = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const confirmField = document.getElementById('confirmPassword');
    const mismatchMsg = document.getElementById('passwordMismatch');
    
    if (newPassword !== confirmPassword) {
        e.preventDefault();
        confirmField.classList.add('is-invalid');
        mismatchMsg.style.display = 'block';
    } else {
        confirmField.classList.remove('is-invalid');
        mismatchMsg.style.display = 'none';
    }
});

// Real-time password matching
document.getElementById('confirmPassword').addEventListener('input', function() {
    const newPassword = document.getElementById('newPassword').value;
    const confirmPassword = this.value;
    const mismatchMsg = document.getElementById('passwordMismatch');
    
    if (confirmPassword && newPassword !== confirmPassword) {
        this.classList.add('is-invalid');
        mismatchMsg.style.display = 'block';
    } else {
        this.classList.remove('is-invalid');
        mismatchMsg.style.display = 'none';
    }
});
</script>

<?php include '../includes/footer.php'; ?>