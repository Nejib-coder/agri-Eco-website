<?php
require_once '../includes/db.php';
require_once '../includes/session.php';

requireLogin();

$page_title = 'Order Confirmation';
$css_path = '../assets/css/styles.css';
$js_path = '../assets/js/main.js';
$base_url = '';

// Get order ID
$order_id = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;

if ($order_id <= 0) {
    header('Location: index.php');
    exit;
}

// Get order details
$order = getSingleRow($conn, "SELECT o.*, u.name as customer_name, u.email as customer_email FROM orders o JOIN users u ON o.user_id = u.id WHERE o.id = ? AND o.user_id = ?", [$order_id, getCurrentUserId()], 'ii');

if (!$order) {
    header('Location: index.php');
    exit;
}

// Get order items
$order_items = getMultipleRows($conn, "SELECT oi.*, p.name as product_name, p.image as product_image FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?", [$order_id], 'i');

include '../includes/header.php';
?>

<!-- Order Confirmation -->
<section class="py-5 mt-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <!-- Success Message -->
                <div class="text-center mb-5">
                    <div class="bg-success text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-4" style="width: 100px; height: 100px;">
                        <i class="bi bi-check-lg" style="font-size: 3rem;"></i>
                    </div>
                    <h1 class="display-5 fw-bold text-success mb-3">Order Confirmed!</h1>
                    <p class="lead text-muted mb-4">
                        Thank you for your order. We've received your order and will process it shortly.
                    </p>
                    <div class="alert alert-success" role="alert">
                        <strong>Order #<?php echo str_pad($order['id'], 6, '0', STR_PAD_LEFT); ?></strong> has been placed successfully!
                    </div>
                </div>

                <!-- Order Details Card -->
                <div class="card shadow-sm border-0 mb-4">
                    <div class="card-header bg-success text-white">
                        <div class="row align-items-center">
                            <div class="col">
                                <h5 class="mb-0">Order Details</h5>
                            </div>
                            <div class="col-auto">
                                <span class="badge bg-warning text-dark"><?php echo ucfirst($order['status']); ?></span>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row g-4">
                            <div class="col-md-6">
                                <h6 class="text-success mb-3">Customer Information</h6>
                                <p class="mb-1"><strong>Name:</strong> <?php echo htmlspecialchars($order['customer_name']); ?></p>
                                <p class="mb-1"><strong>Email:</strong> <?php echo htmlspecialchars($order['customer_email']); ?></p>
                                <p class="mb-1"><strong>Phone:</strong> <?php echo htmlspecialchars($order['phone']); ?></p>
                                <p class="mb-0"><strong>Order Date:</strong> <?php echo date('M d, Y \a\t g:i A', strtotime($order['created_at'])); ?></p>
                            </div>
                            <div class="col-md-6">
                                <h6 class="text-success mb-3">Delivery Information</h6>
                                <p class="mb-1"><strong>Address:</strong> <?php echo htmlspecialchars($order['shipping_address']); ?></p>
                                <p class="mb-1"><strong>Delivery Type:</strong> <?php echo ucfirst(str_replace('-', ' ', $order['delivery_type'])); ?></p>
                                <p class="mb-0"><strong>Payment Method:</strong> <?php echo ucfirst($order['payment_method']); ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Order Items -->
                <div class="card shadow-sm border-0 mb-4">
                    <div class="card-header bg-light">
                        <h5 class="mb-0">Order Items</h5>
                    </div>
                    <div class="card-body p-0">
                        <?php foreach ($order_items as $index => $item): ?>
                        <div class="p-4 <?php echo $index < count($order_items) - 1 ? 'border-bottom' : ''; ?>">
                            <div class="row align-items-center">
                                <div class="col-md-2">
                                    <img src="../<?php echo htmlspecialchars($item['product_image']); ?>" 
                                         class="img-fluid rounded" alt="<?php echo htmlspecialchars($item['product_name']); ?>" 
                                         style="height: 80px; width: 80px; object-fit: cover;">
                                </div>
                                <div class="col-md-6">
                                    <h6 class="text-success mb-1"><?php echo htmlspecialchars($item['product_name']); ?></h6>
                                    <p class="text-muted small mb-0">Quantity: <?php echo $item['quantity']; ?></p>
                                </div>
                                <div class="col-md-2 text-center">
                                    <span class="fw-bold"><?php echo number_format($item['price'], 2); ?> Birr</span>
                                    <small class="text-muted d-block">per unit</small>
                                </div>
                                <div class="col-md-2 text-end">
                                    <span class="fw-bold text-success"><?php echo number_format($item['price'] * $item['quantity'], 2); ?> Birr</span>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Order Summary -->
                <div class="card shadow-sm border-0 mb-4">
                    <div class="card-header bg-light">
                        <h5 class="mb-0">Order Summary</h5>
                    </div>
                    <div class="card-body">
                        <?php
                        $subtotal = array_sum(array_map(function($item) {
                            return $item['price'] * $item['quantity'];
                        }, $order_items));
                        
                        $delivery_fee = 0;
                        switch ($order['delivery_type']) {
                            case 'express':
                                $delivery_fee = 50;
                                break;
                            case 'same-day':
                                $delivery_fee = 100;
                                break;
                        }
                        
                        $tax = round($subtotal * 0.05, 2);
                        ?>
                        
                        <div class="row">
                            <div class="col-md-8">
                                <div class="d-flex justify-content-between mb-2">
                                    <span>Subtotal:</span>
                                    <span><?php echo number_format($subtotal, 2); ?> Birr</span>
                                </div>
                                <div class="d-flex justify-content-between mb-2">
                                    <span>Delivery Fee:</span>
                                    <span><?php echo $delivery_fee > 0 ? number_format($delivery_fee, 2) . ' Birr' : 'Free'; ?></span>
                                </div>
                                <div class="d-flex justify-content-between mb-2">
                                    <span>Tax (5%):</span>
                                    <span><?php echo number_format($tax, 2); ?> Birr</span>
                                </div>
                                <hr>
                                <div class="d-flex justify-content-between">
                                    <span class="h5">Total:</span>
                                    <span class="h5 text-success fw-bold"><?php echo number_format($order['total_price'], 2); ?> Birr</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Next Steps -->
                <div class="card shadow-sm border-0 mb-4">
                    <div class="card-header bg-info text-white">
                        <h5 class="mb-0">What's Next?</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-4 text-center">
                                <i class="bi bi-clock text-info mb-2" style="font-size: 2rem;"></i>
                                <h6>Order Processing</h6>
                                <p class="small text-muted">We'll prepare your order within 2-4 hours</p>
                            </div>
                            <div class="col-md-4 text-center">
                                <i class="bi bi-truck text-info mb-2" style="font-size: 2rem;"></i>
                                <h6>Shipping</h6>
                                <p class="small text-muted">Your order will be shipped according to your delivery preference</p>
                            </div>
                            <div class="col-md-4 text-center">
                                <i class="bi bi-house-door text-info mb-2" style="font-size: 2rem;"></i>
                                <h6>Delivery</h6>
                                <p class="small text-muted">Enjoy your fresh farm products!</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Action Buttons -->
                <div class="text-center">
                    <div class="d-flex gap-3 justify-content-center flex-wrap">
                        <a href="orders.php" class="btn btn-success btn-lg">
                            <i class="bi bi-list-ul"></i> View All Orders
                        </a>
                        <a href="products.php" class="btn btn-outline-success btn-lg">
                            <i class="bi bi-shop"></i> Continue Shopping
                        </a>
                        <button class="btn btn-outline-secondary btn-lg" onclick="window.print()">
                            <i class="bi bi-printer"></i> Print Order
                        </button>
                    </div>
                </div>

                <!-- Contact Support -->
                <div class="alert alert-light mt-4" role="alert">
                    <div class="d-flex align-items-center">
                        <i class="bi bi-info-circle text-info me-3" style="font-size: 1.5rem;"></i>
                        <div>
                            <h6 class="mb-1">Need Help?</h6>
                            <p class="mb-0">
                                If you have any questions about your order, please contact us at 
                                <a href="mailto:support@agriecommerce.com">support@agriecommerce.com</a> 
                                or call <a href="tel:+251955667788">+251 955667788</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include '../includes/footer.php'; ?>