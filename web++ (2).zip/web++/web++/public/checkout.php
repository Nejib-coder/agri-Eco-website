<?php
require_once '../includes/db.php';
require_once '../includes/session.php';

// Require login for checkout
requireLogin('login.php?redirect=checkout.php');

$page_title = 'Checkout';
$css_path = '../assets/css/styles.css';
$js_path = '../assets/js/main.js';
$base_url = '';

// Get cart items
$cart_items = getCartItems();
if (empty($cart_items)) {
    header('Location: cart.php');
    exit;
}

// Get cart products with details
$product_ids = array_keys($cart_items);
$placeholders = str_repeat('?,', count($product_ids) - 1) . '?';
$types = str_repeat('i', count($product_ids));

$sql = "SELECT * FROM products WHERE id IN ($placeholders) AND status = 'active'";
$products = getMultipleRows($conn, $sql, $product_ids, $types);

$cart_products = [];
$subtotal = 0;

foreach ($products as $product) {
    $quantity = $cart_items[$product['id']];
    $item_total = $product['price'] * $quantity;
    $subtotal += $item_total;
    
    $cart_products[] = [
        'product' => $product,
        'quantity' => $quantity,
        'item_total' => $item_total
    ];
}

$shipping = 100; // Default shipping
$tax = round($subtotal * 0.05, 2);
$total = $subtotal + $shipping + $tax;

// Get current user info
$current_user = getCurrentUser();
$user_details = getSingleRow($conn, "SELECT * FROM users WHERE id = ?", [$current_user['id']], 'i');

// Process order
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitizeInput($_POST['name']);
    $email = sanitizeInput($_POST['email']);
    $phone = sanitizeInput($_POST['phone']);
    $address = sanitizeInput($_POST['address']);
    $city = sanitizeInput($_POST['city']);
    $delivery_type = sanitizeInput($_POST['delivery']);
    $payment_method = sanitizeInput($_POST['payment']);
    
    // Calculate final total based on delivery
    $delivery_fee = 0;
    switch ($delivery_type) {
        case 'express':
            $delivery_fee = 50;
            break;
        case 'same-day':
            $delivery_fee = 100;
            break;
    }
    $final_total = $subtotal + $delivery_fee + $tax;
    
    // Validation
    $errors = [];
    
    // Name validation
    if (empty($name)) {
        $errors[] = 'Name is required';
    } elseif (strlen($name) < 2) {
        $errors[] = 'Name must be at least 2 characters';
    } elseif (!preg_match('/^[a-zA-Z\s]+$/', $name)) {
        $errors[] = 'Name can only contain letters and spaces';
    }
    
    // Email validation
    if (empty($email)) {
        $errors[] = 'Email is required';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Valid email address is required';
    }
    
    // Phone validation (Ethiopian format)
    if (empty($phone)) {
        $errors[] = 'Phone number is required';
    } else {
        $clean_phone = preg_replace('/[\s\-\(\)]/', '', $phone);
        if (!preg_match('/^(\+251|0)[79]\d{8}$/', $clean_phone)) {
            $errors[] = 'Please enter a valid Ethiopian phone number';
        }
    }
    
    // Address validation
    if (empty($address)) {
        $errors[] = 'Address is required';
    } elseif (strlen($address) < 10) {
        $errors[] = 'Please provide a complete address (minimum 10 characters)';
    }
    
    // City validation
    if (empty($city)) {
        $errors[] = 'City is required';
    } elseif (strlen($city) < 2) {
        $errors[] = 'City name must be at least 2 characters';
    }
    
    // Delivery type validation
    $valid_delivery_types = ['standard', 'express', 'same-day'];
    if (!in_array($delivery_type, $valid_delivery_types)) {
        $errors[] = 'Invalid delivery type selected';
    }
    
    // Payment method validation
    $valid_payment_methods = ['cash', 'mobile', 'bank'];
    if (!in_array($payment_method, $valid_payment_methods)) {
        $errors[] = 'Invalid payment method selected';
    }
    
    if (empty($errors)) {
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // Create order with payment status
            $shipping_address = "$address, $city";
            // Cash on delivery is unpaid, others need payment confirmation
            $payment_status = ($payment_method == 'cash') ? 'unpaid' : 'unpaid';
            $sql = "INSERT INTO orders (user_id, total_price, status, shipping_address, phone, delivery_type, payment_method, payment_status) VALUES (?, ?, 'pending', ?, ?, ?, ?, ?)";
            $stmt = executeQuery($conn, $sql, [$current_user['id'], $final_total, $shipping_address, $phone, $delivery_type, $payment_method, $payment_status], 'idsssss');
            
            $order_id = $conn->insert_id;
            
            // Add order items
            foreach ($cart_products as $item) {
                $sql = "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
                executeQuery($conn, $sql, [$order_id, $item['product']['id'], $item['quantity'], $item['product']['price']], 'iiid');
                
                // Update product stock
                $sql = "UPDATE products SET stock_quantity = stock_quantity - ? WHERE id = ?";
                executeQuery($conn, $sql, [$item['quantity'], $item['product']['id']], 'ii');
            }
            
            // Commit transaction
            $conn->commit();
            
            // Clear cart
            clearCart();
            
            // Redirect to payment instructions
            header("Location: payment_instructions.php?order_id=$order_id");
            exit;
            
        } catch (Exception $e) {
            $conn->rollback();
            $error = 'Error processing order. Please try again.';
        }
    }
}

include '../includes/header.php';
?>

<!-- Checkout Progress -->
<section class="py-3 bg-light mt-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="d-flex align-items-center">
                        <div class="bg-success text-white rounded-circle d-flex align-items-center justify-content-center me-2" style="width: 30px; height: 30px;">
                            <i class="bi bi-cart-check"></i>
                        </div>
                        <span class="text-success fw-bold">Cart</span>
                    </div>
                    <div class="flex-fill mx-3">
                        <hr class="border-success">
                    </div>
                    <div class="d-flex align-items-center">
                        <div class="bg-success text-white rounded-circle d-flex align-items-center justify-content-center me-2" style="width: 30px; height: 30px;">
                            <i class="bi bi-credit-card"></i>
                        </div>
                        <span class="text-success fw-bold">Checkout</span>
                    </div>
                    <div class="flex-fill mx-3">
                        <hr class="border-muted">
                    </div>
                    <div class="d-flex align-items-center">
                        <div class="bg-light text-muted rounded-circle d-flex align-items-center justify-content-center me-2" style="width: 30px; height: 30px;">
                            <i class="bi bi-check-circle"></i>
                        </div>
                        <span class="text-muted">Complete</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Checkout Form -->
<section class="py-5">
    <div class="container">
        <div class="row g-5">
            <!-- Checkout Form -->
            <div class="col-lg-7">
                <h3 class="text-success mb-4">Checkout Details</h3>
                
                <?php if (isset($errors) && !empty($errors)): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php foreach ($errors as $error): ?>
                        <li><?php echo htmlspecialchars($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>

                <form method="POST" id="checkoutForm">
                    <!-- Shipping Information -->
                    <div class="card mb-4">
                        <div class="card-header bg-light">
                            <h5 class="mb-0">
                                <i class="bi bi-truck me-2"></i>Shipping Information
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label for="name" class="form-label">Full Name *</label>
                                    <input type="text" class="form-control" id="name" name="name" 
                                           value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : htmlspecialchars($user_details['name']); ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="email" class="form-label">Email Address *</label>
                                    <input type="email" class="form-control" id="email" name="email" 
                                           value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : htmlspecialchars($user_details['email']); ?>" required>
                                </div>
                                <div class="col-12">
                                    <label for="phone" class="form-label">Phone Number *</label>
                                    <input type="tel" class="form-control" id="phone" name="phone" 
                                           placeholder="+251 9XX XXX XXX" 
                                           value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : htmlspecialchars($user_details['phone']); ?>" required>
                                </div>
                                <div class="col-12">
                                    <label for="address" class="form-label">Street Address *</label>
                                    <textarea class="form-control" id="address" name="address" rows="2" 
                                              placeholder="Enter your full address" required><?php echo isset($_POST['address']) ? htmlspecialchars($_POST['address']) : htmlspecialchars($user_details['address']); ?></textarea>
                                </div>
                                <div class="col-md-6">
                                    <label for="city" class="form-label">City *</label>
                                    <input type="text" class="form-control" id="city" name="city" 
                                           value="<?php echo isset($_POST['city']) ? htmlspecialchars($_POST['city']) : ''; ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="region" class="form-label">Region</label>
                                    <select class="form-select" id="region" name="region">
                                        <option value="">Choose Region</option>
                                        <option value="addis-ababa">Addis Ababa</option>
                                        <option value="oromia">Oromia</option>
                                        <option value="amhara">Amhara</option>
                                        <option value="tigray">Tigray</option>
                                        <option value="snnp">SNNP</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Delivery Options -->
                    <div class="card mb-4">
                        <div class="card-header bg-light">
                            <h5 class="mb-0">
                                <i class="bi bi-calendar-check me-2"></i>Delivery Options
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="row g-3">
                                <div class="col-12">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="delivery" id="standard" value="standard" checked>
                                        <label class="form-check-label" for="standard">
                                            <strong>Standard Delivery (Free)</strong>
                                            <br><small class="text-muted">2-3 business days</small>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="delivery" id="express" value="express">
                                        <label class="form-check-label" for="express">
                                            <strong>Express Delivery (+50 Birr)</strong>
                                            <br><small class="text-muted">Next business day</small>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="delivery" id="same-day" value="same-day">
                                        <label class="form-check-label" for="same-day">
                                            <strong>Same Day Delivery (+100 Birr)</strong>
                                            <br><small class="text-muted">Within 6 hours (Addis Ababa only)</small>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Payment Method -->
                    <div class="card mb-4">
                        <div class="card-header bg-light">
                            <h5 class="mb-0">
                                <i class="bi bi-credit-card me-2"></i>Payment Method
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="row g-3">
                                <div class="col-12">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="payment" id="cash" value="cash" checked>
                                        <label class="form-check-label" for="cash">
                                            <i class="bi bi-cash me-2"></i><strong>Cash on Delivery</strong>
                                            <br><small class="text-muted">Pay when you receive your order</small>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="payment" id="mobile" value="mobile">
                                        <label class="form-check-label" for="mobile">
                                            <i class="bi bi-phone me-2"></i><strong>Mobile Money</strong>
                                            <br><small class="text-muted">M-Birr, HelloCash, etc.</small>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="payment" id="bank" value="bank">
                                        <label class="form-check-label" for="bank">
                                            <i class="bi bi-bank me-2"></i><strong>Bank Transfer</strong>
                                            <br><small class="text-muted">Direct bank transfer</small>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Special Instructions -->
                    <div class="card mb-4">
                        <div class="card-header bg-light">
                            <h5 class="mb-0">
                                <i class="bi bi-chat-text me-2"></i>Special Instructions
                            </h5>
                        </div>
                        <div class="card-body">
                            <textarea class="form-control" name="instructions" rows="3" 
                                      placeholder="Any special delivery instructions or notes..."></textarea>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Order Summary -->
            <div class="col-lg-5">
                <div class="card sticky-top" style="top: 20px;">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0">Order Summary</h5>
                    </div>
                    <div class="card-body">
                        <!-- Order Items -->
                        <div class="mb-3">
                            <?php foreach ($cart_products as $item): ?>
                            <div class="d-flex align-items-center mb-2">
                                <img src="../<?php echo htmlspecialchars($item['product']['image']); ?>" 
                                     class="rounded me-3" style="width: 50px; height: 50px; object-fit: cover;" 
                                     alt="<?php echo htmlspecialchars($item['product']['name']); ?>">
                                <div class="flex-grow-1">
                                    <h6 class="mb-0"><?php echo htmlspecialchars($item['product']['name']); ?></h6>
                                    <small class="text-muted">Qty: <?php echo $item['quantity']; ?></small>
                                </div>
                                <span class="fw-bold"><?php echo number_format($item['item_total'], 2); ?> Birr</span>
                            </div>
                            <?php endforeach; ?>
                        </div>

                        <hr>

                        <!-- Price Breakdown -->
                        <div class="d-flex justify-content-between mb-2">
                            <span>Subtotal:</span>
                            <span><?php echo number_format($subtotal, 2); ?> Birr</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span>Delivery:</span>
                            <span id="deliveryFee">Free</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span>Tax (5%):</span>
                            <span><?php echo number_format($tax, 2); ?> Birr</span>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between mb-4">
                            <span class="h5">Total:</span>
                            <span class="h5 text-success fw-bold" id="totalAmount" data-base-total="<?php echo $total; ?>"><?php echo number_format($total, 2); ?> Birr</span>
                        </div>

                        <!-- Place Order Button -->
                        <div class="d-grid">
                            <button type="submit" form="checkoutForm" class="btn btn-success btn-lg">
                                <i class="bi bi-check-circle me-2"></i>Place Order
                            </button>
                        </div>

                        <!-- Security Notice -->
                        <div class="mt-3 text-center">
                            <small class="text-muted">
                                <i class="bi bi-shield-check me-1"></i>
                                Your information is secure and protected
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include '../includes/footer.php'; ?>

<script>
// Update delivery fee based on selection
document.querySelectorAll('input[name="delivery"]').forEach(radio => {
    radio.addEventListener('change', function() {
        const deliveryFeeElement = document.getElementById('deliveryFee');
        const totalElement = document.getElementById('totalAmount');
        let deliveryFee = 0;
        let baseTotal = <?php echo $subtotal + $tax; ?>;

        switch(this.value) {
            case 'express':
                deliveryFee = 50;
                deliveryFeeElement.textContent = '50 Birr';
                break;
            case 'same-day':
                deliveryFee = 100;
                deliveryFeeElement.textContent = '100 Birr';
                break;
            default:
                deliveryFee = 0;
                deliveryFeeElement.textContent = 'Free';
        }

        totalElement.textContent = (baseTotal + deliveryFee).toFixed(2) + ' Birr';
    });
});
</script>