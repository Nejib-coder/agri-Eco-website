<?php
require_once '../../includes/db.php';
require_once '../../includes/session.php';

// Require login
requireLogin();

$current_user = getCurrentUser();
$order_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($order_id <= 0) {
    echo '<div class="alert alert-danger">Invalid order ID</div>';
    exit;
}

// Get order details - ensure it belongs to the current user
$order = getSingleRow($conn, "
    SELECT o.*, u.name as customer_name, u.email as customer_email 
    FROM orders o 
    JOIN users u ON o.user_id = u.id 
    WHERE o.id = ? AND o.user_id = ?
", [$order_id, $current_user['id']], 'ii');

if (!$order) {
    echo '<div class="alert alert-danger">Order not found or access denied</div>';
    exit;
}

// Get order items with product details
$order_items = getMultipleRows($conn, "
    SELECT oi.*, p.name as product_name, p.image as product_image 
    FROM order_items oi 
    JOIN products p ON oi.product_id = p.id 
    WHERE oi.order_id = ?
", [$order_id], 'i');

// Calculate subtotal
$subtotal = 0;
foreach ($order_items as $item) {
    $subtotal += $item['price'] * $item['quantity'];
}
?>

<!-- Order Header -->
<div class="row mb-4">
    <div class="col-md-6">
        <h4>Order #<?php echo str_pad($order['id'], 6, '0', STR_PAD_LEFT); ?></h4>
        <p class="text-muted mb-0">
            <i class="bi bi-calendar"></i> 
            <?php echo date('F d, Y \a\t H:i', strtotime($order['created_at'])); ?>
        </p>
    </div>
    <div class="col-md-6 text-md-end">
        <span class="badge bg-<?php 
            echo $order['status'] == 'pending' ? 'warning' : 
                ($order['status'] == 'processing' ? 'info' : 
                ($order['status'] == 'shipped' ? 'primary' : 
                ($order['status'] == 'delivered' ? 'success' : 'danger'))); 
        ?> fs-6">
            <?php echo ucfirst($order['status']); ?>
        </span>
    </div>
</div>

<!-- Order Items -->
<div class="card mb-3">
    <div class="card-header bg-light">
        <h6 class="mb-0">Order Items</h6>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Product</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th class="text-end">Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($order_items as $item): ?>
                    <tr>
                        <td>
                            <div class="d-flex align-items-center">
                                <img src="../../<?php echo htmlspecialchars($item['product_image']); ?>" 
                                     class="rounded me-3" 
                                     style="width: 50px; height: 50px; object-fit: cover;" 
                                     alt="<?php echo htmlspecialchars($item['product_name']); ?>">
                                <span><?php echo htmlspecialchars($item['product_name']); ?></span>
                            </div>
                        </td>
                        <td><?php echo number_format($item['price'], 2); ?> Birr</td>
                        <td><?php echo $item['quantity']; ?></td>
                        <td class="text-end"><?php echo number_format($item['price'] * $item['quantity'], 2); ?> Birr</td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Order Summary -->
<div class="row">
    <div class="col-md-6">
        <div class="card mb-3">
            <div class="card-header bg-light">
                <h6 class="mb-0">Shipping Information</h6>
            </div>
            <div class="card-body">
                <p class="mb-2">
                    <strong><i class="bi bi-person"></i> Name:</strong><br>
                    <?php echo htmlspecialchars($order['customer_name']); ?>
                </p>
                <p class="mb-2">
                    <strong><i class="bi bi-envelope"></i> Email:</strong><br>
                    <?php echo htmlspecialchars($order['customer_email']); ?>
                </p>
                <p class="mb-2">
                    <strong><i class="bi bi-telephone"></i> Phone:</strong><br>
                    <?php echo htmlspecialchars($order['phone']); ?>
                </p>
                <p class="mb-0">
                    <strong><i class="bi bi-geo-alt"></i> Address:</strong><br>
                    <?php echo htmlspecialchars($order['shipping_address']); ?>
                </p>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card mb-3">
            <div class="card-header bg-light">
                <h6 class="mb-0">Order Summary</h6>
            </div>
            <div class="card-body">
                <div class="d-flex justify-content-between mb-2">
                    <span>Subtotal:</span>
                    <span><?php echo number_format($subtotal, 2); ?> Birr</span>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span>Delivery (<?php echo ucfirst($order['delivery_type']); ?>):</span>
                    <span>
                        <?php 
                        $delivery_fee = $order['delivery_type'] == 'express' ? 50 : 
                                       ($order['delivery_type'] == 'same-day' ? 100 : 0);
                        echo $delivery_fee > 0 ? number_format($delivery_fee, 2) . ' Birr' : 'Free';
                        ?>
                    </span>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span>Tax (5%):</span>
                    <span><?php echo number_format($subtotal * 0.05, 2); ?> Birr</span>
                </div>
                <hr>
                <div class="d-flex justify-content-between">
                    <strong>Total:</strong>
                    <strong class="text-success"><?php echo number_format($order['total_price'], 2); ?> Birr</strong>
                </div>
                <hr>
                <div class="d-flex justify-content-between mb-2">
                    <span>Payment Method:</span>
                    <span class="badge bg-secondary"><?php echo ucfirst($order['payment_method']); ?></span>
                </div>
                <div class="d-flex justify-content-between">
                    <span>Payment Status:</span>
                    <span class="badge bg-<?php 
                        echo $order['payment_status'] == 'paid' ? 'success' : 
                            ($order['payment_status'] == 'failed' ? 'danger' : 'warning'); 
                    ?>">
                        <?php echo ucfirst($order['payment_status']); ?>
                    </span>
                </div>
                <?php if ($order['payment_status'] == 'paid' && $order['payment_date']): ?>
                <div class="d-flex justify-content-between mt-2">
                    <small class="text-muted">Paid on:</small>
                    <small class="text-muted"><?php echo date('M d, Y H:i', strtotime($order['payment_date'])); ?></small>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Order Status Timeline -->
<div class="card">
    <div class="card-header bg-light">
        <h6 class="mb-0">Order Status</h6>
    </div>
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center">
            <div class="text-center flex-fill">
                <div class="mb-2">
                    <div class="rounded-circle d-inline-flex align-items-center justify-content-center <?php echo in_array($order['status'], ['pending', 'processing', 'shipped', 'delivered']) ? 'bg-success text-white' : 'bg-light text-muted'; ?>" 
                         style="width: 40px; height: 40px;">
                        <i class="bi bi-check-circle"></i>
                    </div>
                </div>
                <small class="<?php echo in_array($order['status'], ['pending', 'processing', 'shipped', 'delivered']) ? 'text-success fw-bold' : 'text-muted'; ?>">
                    Pending
                </small>
            </div>
            <div class="flex-fill">
                <hr class="<?php echo in_array($order['status'], ['processing', 'shipped', 'delivered']) ? 'border-success' : 'border-muted'; ?>">
            </div>
            <div class="text-center flex-fill">
                <div class="mb-2">
                    <div class="rounded-circle d-inline-flex align-items-center justify-content-center <?php echo in_array($order['status'], ['processing', 'shipped', 'delivered']) ? 'bg-success text-white' : 'bg-light text-muted'; ?>" 
                         style="width: 40px; height: 40px;">
                        <i class="bi bi-arrow-repeat"></i>
                    </div>
                </div>
                <small class="<?php echo in_array($order['status'], ['processing', 'shipped', 'delivered']) ? 'text-success fw-bold' : 'text-muted'; ?>">
                    Processing
                </small>
            </div>
            <div class="flex-fill">
                <hr class="<?php echo in_array($order['status'], ['shipped', 'delivered']) ? 'border-success' : 'border-muted'; ?>">
            </div>
            <div class="text-center flex-fill">
                <div class="mb-2">
                    <div class="rounded-circle d-inline-flex align-items-center justify-content-center <?php echo in_array($order['status'], ['shipped', 'delivered']) ? 'bg-success text-white' : 'bg-light text-muted'; ?>" 
                         style="width: 40px; height: 40px;">
                        <i class="bi bi-truck"></i>
                    </div>
                </div>
                <small class="<?php echo in_array($order['status'], ['shipped', 'delivered']) ? 'text-success fw-bold' : 'text-muted'; ?>">
                    Shipped
                </small>
            </div>
            <div class="flex-fill">
                <hr class="<?php echo $order['status'] == 'delivered' ? 'border-success' : 'border-muted'; ?>">
            </div>
            <div class="text-center flex-fill">
                <div class="mb-2">
                    <div class="rounded-circle d-inline-flex align-items-center justify-content-center <?php echo $order['status'] == 'delivered' ? 'bg-success text-white' : 'bg-light text-muted'; ?>" 
                         style="width: 40px; height: 40px;">
                        <i class="bi bi-box-seam"></i>
                    </div>
                </div>
                <small class="<?php echo $order['status'] == 'delivered' ? 'text-success fw-bold' : 'text-muted'; ?>">
                    Delivered
                </small>
            </div>
        </div>
        
        <?php if ($order['status'] == 'cancelled'): ?>
        <div class="alert alert-danger mt-3 mb-0">
            <i class="bi bi-x-circle"></i> This order has been cancelled
        </div>
        <?php endif; ?>
    </div>
</div>
