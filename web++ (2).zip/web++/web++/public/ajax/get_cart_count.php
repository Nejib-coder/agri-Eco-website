<?php
require_once '../../includes/session.php';

header('Content-Type: application/json');

echo json_encode(['count' => getCartItemCount()]);
?>