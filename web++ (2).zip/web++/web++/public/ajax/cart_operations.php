<?php
require_once '../../includes/db.php';
require_once '../../includes/session.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$action = isset($_POST['action']) ? sanitizeInput($_POST['action']) : '';
$product_id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
$quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;

if (empty($action) || $product_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid parameters']);
    exit;
}

// Verify product exists and is active
$product = getSingleRow($conn, "SELECT * FROM products WHERE id = ? AND status = 'active'", [$product_id], 'i');

if (!$product) {
    echo json_encode(['success' => false, 'message' => 'Product not found']);
    exit;
}

switch ($action) {
    case 'add':
        if ($product['stock_quantity'] < $quantity) {
            echo json_encode(['success' => false, 'message' => 'Insufficient stock']);
            exit;
        }
        
        addToCart($product_id, $quantity);
        echo json_encode([
            'success' => true, 
            'message' => 'Product added to cart',
            'cart_count' => getCartItemCount()
        ]);
        break;
        
    case 'update':
        if ($quantity > 0 && $product['stock_quantity'] < $quantity) {
            echo json_encode(['success' => false, 'message' => 'Insufficient stock']);
            exit;
        }
        
        updateCartQuantity($product_id, $quantity);
        echo json_encode([
            'success' => true, 
            'message' => 'Cart updated',
            'cart_count' => getCartItemCount()
        ]);
        break;
        
    case 'remove':
        removeFromCart($product_id);
        echo json_encode([
            'success' => true, 
            'message' => 'Product removed from cart',
            'cart_count' => getCartItemCount()
        ]);
        break;
        
    case 'clear':
        clearCart();
        echo json_encode([
            'success' => true, 
            'message' => 'Cart cleared successfully',
            'cart_count' => 0
        ]);
        break;
        
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
        break;
}
?>