<?php
require_once '../../includes/db.php';
require_once '../../includes/session.php';

header('Content-Type: application/json');

// Require login
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Please log in to cancel orders']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] != 'POST' || !isset($_POST['order_id'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
    exit();
}

$order_id = intval($_POST['order_id']);
$user = getCurrentUser();

// Get order details and verify ownership
$order = getSingleRow($conn, "
    SELECT id, status, user_id 
    FROM orders 
    WHERE id = ? AND user_id = ?
", [$order_id, $user['id']], 'ii');

if (!$order) {
    echo json_encode(['success' => false, 'message' => 'Order not found']);
    exit();
}

// Check if order can be cancelled
if ($order['status'] != 'pending') {
    echo json_encode(['success' => false, 'message' => 'Only pending orders can be cancelled']);
    exit();
}

// Update order status to cancelled
$result = executeQuery($conn, "UPDATE orders SET status = 'cancelled' WHERE id = ?", [$order_id], 'i');

if ($result) {
    echo json_encode(['success' => true, 'message' => 'Order cancelled successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Error cancelling order']);
}
?>