<?php
require_once '../../includes/db.php';
require_once '../../includes/session.php';

header('Content-Type: application/json');

// Require login
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Please log in to reorder']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] != 'POST' || !isset($_POST['order_id'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
    exit();
}

$order_id = intval($_POST['order_id']);
$user = getCurrentUser();

// Verify order belongs to user
$order = getSingleRow($conn, "SELECT id FROM orders WHERE id = ? AND user_id = ?", [$order_id, $user['id']], 'ii');

if (!$order) {
    echo json_encode(['success' => false, 'message' => 'Order not found']);
    exit();
}

// Get order items
$order_items = getMultipleRows($conn, "
    SELECT oi.product_id, oi.quantity, p.stock_quantity, p.status, p.name
    FROM order_items oi
    JOIN products p ON oi.product_id = p.id
    WHERE oi.order_id = ?
", [$order_id], 'i');

if (empty($order_items)) {
    echo json_encode(['success' => false, 'message' => 'No items found in this order']);
    exit();
}

$added_items = 0;
$unavailable_items = [];

// Add each item to cart
foreach ($order_items as $item) {
    // Check if product is still available
    if ($item['status'] != 'active') {
        $unavailable_items[] = $item['name'] . ' (discontinued)';
        continue;
    }
    
    // Check stock
    if ($item['stock_quantity'] < $item['quantity']) {
        if ($item['stock_quantity'] > 0) {
            // Add available quantity
            addToCart($item['product_id'], $item['stock_quantity']);
            $added_items++;
            $unavailable_items[] = $item['name'] . ' (only ' . $item['stock_quantity'] . ' available)';
        } else {
            $unavailable_items[] = $item['name'] . ' (out of stock)';
        }
        continue;
    }
    
    // Add to cart
    addToCart($item['product_id'], $item['quantity']);
    $added_items++;
}

$message = '';
if ($added_items > 0) {
    $message = $added_items . ' item(s) added to cart';
    if (!empty($unavailable_items)) {
        $message .= '. Note: ' . implode(', ', $unavailable_items);
    }
    echo json_encode(['success' => true, 'message' => $message]);
} else {
    echo json_encode(['success' => false, 'message' => 'No items could be added: ' . implode(', ', $unavailable_items)]);
}
?>