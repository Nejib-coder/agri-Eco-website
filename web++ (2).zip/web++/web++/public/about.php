<?php
require_once '../includes/db.php';
require_once '../includes/session.php';

$page_title = 'About Us';
$css_path = '../assets/css/styles.css';
$js_path = '../assets/js/main.js';
$base_url = '';

// Get some statistics
$total_products = getSingleRow($conn, "SELECT COUNT(*) as count FROM products WHERE status = 'active'")['count'];
$total_farmers = getSingleRow($conn, "SELECT COUNT(DISTINCT farmer_name) as count FROM products WHERE status = 'active'")['count'];
$total_orders = getSingleRow($conn, "SELECT COUNT(*) as count FROM orders")['count'];
$total_customers = getSingleRow($conn, "SELECT COUNT(*) as count FROM users WHERE role = 'customer'")['count'];

include '../includes/header.php';
?>

<!-- Hero Section -->
<section class="bg-success text-white py-5 mt-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <h1 class="display-4 fw-bold mb-4">About AgriE-Commerce</h1>
                <p class="lead">
                    Connecting farmers directly with consumers, creating a sustainable and fair agricultural marketplace 
                    that benefits everyone in the supply chain.
                </p>
            </div>
            <div class="col-lg-6">
                <img src="../assets/images/imges/orginc.jpg" class="img-fluid rounded shadow" alt="About Us">
            </div>
        </div>
    </div>
</section>

<!-- Mission Section -->
<section class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 text-center">
                <h2 class="display-5 fw-bold text-success mb-4">Our Mission</h2>
                <p class="lead text-muted mb-5">
                    We believe in creating a direct connection between farmers and consumers, 
                    eliminating middlemen and ensuring fair prices for both parties while 
                    promoting sustainable agricultural practices and supporting local communities.
                </p>
            </div>
        </div>

        <div class="row g-4">
            <div class="col-md-4">
                <div class="text-center">
                    <div class="bg-success text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px;">
                        <i class="bi bi-truck fs-2"></i>
                    </div>
                    <h5 class="text-success">Fast Delivery</h5>
                    <p class="text-muted">Fresh products delivered within 24 hours of harvest, ensuring maximum freshness and quality for our customers.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="text-center">
                    <div class="bg-success text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px;">
                        <i class="bi bi-heart fs-2"></i>
                    </div>
                    <h5 class="text-success">Support Local</h5>
                    <p class="text-muted">100% of profits go directly to farmers and their communities, supporting local agriculture and sustainable farming practices.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="text-center">
                    <div class="bg-success text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px;">
                        <i class="bi bi-shield-check fs-2"></i>
                    </div>
                    <h5 class="text-success">Quality Guaranteed</h5>
                    <p class="text-muted">All products are quality checked and certified organic, ensuring you get the best produce for your family.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Stats Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row g-4 text-center">
            <div class="col-md-3">
                <div class="card border-0 bg-transparent">
                    <div class="card-body">
                        <h2 class="display-4 fw-bold text-success"><?php echo $total_products; ?>+</h2>
                        <p class="text-muted">Products Available</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-0 bg-transparent">
                    <div class="card-body">
                        <h2 class="display-4 fw-bold text-success"><?php echo $total_farmers; ?>+</h2>
                        <p class="text-muted">Partner Farmers</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-0 bg-transparent">
                    <div class="card-body">
                        <h2 class="display-4 fw-bold text-success"><?php echo $total_customers; ?>+</h2>
                        <p class="text-muted">Happy Customers</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card border-0 bg-transparent">
                    <div class="card-body">
                        <h2 class="display-4 fw-bold text-success">2+</h2>
                        <p class="text-muted">Years of Service</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Our Story Section -->
<section class="py-5">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-6">
                <h2 class="display-6 fw-bold text-success mb-4">Our Story</h2>
                <p class="text-muted mb-4">
                    AgriE-Commerce was founded in 2023 with a simple yet powerful vision: to create a direct bridge 
                    between hardworking farmers and conscious consumers. We recognized that traditional agricultural 
                    supply chains often disadvantage both farmers and consumers, with middlemen taking large cuts 
                    while farmers struggle to get fair prices for their produce.
                </p>
                <p class="text-muted mb-4">
                    Our platform eliminates these intermediaries, allowing farmers to sell directly to consumers 
                    at fair prices while ensuring customers receive the freshest, highest-quality produce possible. 
                    We're not just an e-commerce platform; we're a movement towards sustainable agriculture and 
                    community empowerment.
                </p>
                <p class="text-muted">
                    Today, we're proud to work with dozens of local farmers across Ethiopia, helping them reach 
                    new markets while providing our customers with access to fresh, organic, and locally-sourced 
                    agricultural products.
                </p>
            </div>
            <div class="col-lg-6">
                <div class="row g-3">
                    <div class="col-6">
                        <img src="../assets/images/imges/fresh.avif" class="img-fluid rounded shadow" alt="Fresh Produce">
                    </div>
                    <div class="col-6">
                        <img src="../assets/images/imges/grain.jpg" class="img-fluid rounded shadow" alt="Quality Grains">
                    </div>
                    <div class="col-12">
                        <img src="../assets/images/imges/dagi.jpg" class="img-fluid rounded shadow" alt="Our Farmers" style="height: 200px; width: 100%; object-fit: cover;">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Values Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="display-5 fw-bold text-success">Our Values</h2>
            <p class="lead text-muted">The principles that guide everything we do</p>
        </div>
        
        <div class="row g-4">
            <div class="col-lg-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center p-4">
                        <div class="bg-success text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 60px; height: 60px;">
                            <i class="bi bi-people fs-4"></i>
                        </div>
                        <h5 class="text-success mb-3">Community First</h5>
                        <p class="text-muted">We prioritize the well-being of farming communities and work to create sustainable livelihoods for local farmers.</p>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center p-4">
                        <div class="bg-success text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 60px; height: 60px;">
                            <i class="bi bi-leaf fs-4"></i>
                        </div>
                        <h5 class="text-success mb-3">Sustainability</h5>
                        <p class="text-muted">We promote environmentally friendly farming practices and support organic agriculture for a healthier planet.</p>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center p-4">
                        <div class="bg-success text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 60px; height: 60px;">
                            <i class="bi bi-handshake fs-4"></i>
                        </div>
                        <h5 class="text-success mb-3">Transparency</h5>
                        <p class="text-muted">We believe in honest, transparent relationships with both our farmers and customers, building trust through openness.</p>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center p-4">
                        <div class="bg-success text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 60px; height: 60px;">
                            <i class="bi bi-award fs-4"></i>
                        </div>
                        <h5 class="text-success mb-3">Quality Excellence</h5>
                        <p class="text-muted">We maintain the highest standards for product quality and customer service, ensuring satisfaction at every step.</p>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center p-4">
                        <div class="bg-success text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 60px; height: 60px;">
                            <i class="bi bi-lightbulb fs-4"></i>
                        </div>
                        <h5 class="text-success mb-3">Innovation</h5>
                        <p class="text-muted">We continuously innovate to improve our platform and create better solutions for farmers and consumers alike.</p>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center p-4">
                        <div class="bg-success text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 60px; height: 60px;">
                            <i class="bi bi-globe fs-4"></i>
                        </div>
                        <h5 class="text-success mb-3">Local Impact</h5>
                        <p class="text-muted">We focus on creating positive impact in local communities while contributing to Ethiopia's agricultural development.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Team Section -->
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="display-5 fw-bold text-success">Meet Our Team</h2>
            <p class="lead text-muted">The people behind AgriE-Commerce</p>
        </div>
        
        <div class="row g-4 justify-content-center">
            <div class="col-lg-4 col-md-6">
                <div class="card border-0 shadow-sm">
                    <div class="card-body text-center p-4">
                        <div class="bg-success text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px;">
                            <i class="bi bi-person fs-2"></i>
                        </div>
                        <h5 class="text-success">Development Team</h5>
                        <p class="text-muted small">University Students</p>
                        <p class="text-muted">Passionate about technology and agriculture, working to create innovative solutions for farmers and consumers.</p>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-6">
                <div class="card border-0 shadow-sm">
                    <div class="card-body text-center p-4">
                        <div class="bg-success text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px;">
                            <i class="bi bi-people fs-2"></i>
                        </div>
                        <h5 class="text-success">Farmer Network</h5>
                        <p class="text-muted small">Local Partners</p>
                        <p class="text-muted">Dedicated farmers across Ethiopia who provide fresh, high-quality produce and share our vision for sustainable agriculture.</p>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-6">
                <div class="card border-0 shadow-sm">
                    <div class="card-body text-center p-4">
                        <div class="bg-success text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px;">
                            <i class="bi bi-heart fs-2"></i>
                        </div>
                        <h5 class="text-success">Community</h5>
                        <p class="text-muted small">Our Customers</p>
                        <p class="text-muted">Amazing customers who support local agriculture and help us build a more sustainable food system for everyone.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Call to Action -->
<section class="py-5 bg-success text-white">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <h3 class="fw-bold mb-3">Join Our Mission</h3>
                <p class="lead mb-0">
                    Whether you're a farmer looking to reach new markets or a consumer seeking fresh, 
                    local produce, we invite you to be part of our growing community.
                </p>
            </div>
            <div class="col-lg-4 text-lg-end">
                <div class="d-flex gap-3 justify-content-lg-end flex-wrap">
                    <a href="products.php" class="btn btn-warning btn-lg">
                        <i class="bi bi-shop"></i> Shop Now
                    </a>
                    <a href="contact.php" class="btn btn-outline-light btn-lg">
                        <i class="bi bi-envelope"></i> Contact Us
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include '../includes/footer.php'; ?>