<?php
require_once '../includes/db.php';
require_once '../includes/session.php';

requireLogin('login.php');

$page_title = 'Payment Instructions';
$css_path = '../assets/css/styles.css';
$js_path = '../assets/js/main.js';
$base_url = '';

$order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;
$current_user = getCurrentUser();

if ($order_id <= 0) {
    header('Location: orders.php');
    exit;
}

// Get order details - ensure it belongs to current user
$order = getSingleRow($conn, "
    SELECT * FROM orders 
    WHERE id = ? AND user_id = ?
", [$order_id, $current_user['id']], 'ii');

if (!$order) {
    header('Location: orders.php');
    exit;
}

include '../includes/header.php';
?>

<section class="py-5 mt-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <!-- Order Summary Card -->
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0">
                            <i class="bi bi-receipt"></i> Order #<?php echo str_pad($order['id'], 6, '0', STR_PAD_LEFT); ?>
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <p class="mb-2"><strong>Total Amount:</strong></p>
                                <h3 class="text-success"><?php echo number_format($order['total_price'], 2); ?> Birr</h3>
                            </div>
                            <div class="col-md-6 text-md-end">
                                <p class="mb-2"><strong>Payment Method:</strong></p>
                                <span class="badge bg-secondary fs-6"><?php echo ucfirst($order['payment_method']); ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <?php if ($order['payment_method'] == 'cash'): ?>
                <!-- Cash on Delivery Instructions -->
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-light">
                        <h5 class="mb-0">
                            <i class="bi bi-cash-coin text-success"></i> Cash on Delivery Instructions
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-info">
                            <i class="bi bi-info-circle"></i> 
                            <strong>No payment required now!</strong> You will pay when you receive your order.
                        </div>
                        
                        <h6 class="fw-bold mb-3">What to expect:</h6>
                        <ol class="mb-4">
                            <li class="mb-2">Your order is being processed</li>
                            <li class="mb-2">Our delivery team will contact you before delivery</li>
                            <li class="mb-2">Prepare the exact amount: <strong class="text-success"><?php echo number_format($order['total_price'], 2); ?> Birr</strong></li>
                            <li class="mb-2">Inspect your products upon delivery</li>
                            <li class="mb-2">Pay the delivery person in cash</li>
                        </ol>

                        <div class="alert alert-warning">
                            <i class="bi bi-exclamation-triangle"></i> 
                            <strong>Important:</strong> Please have the exact amount ready. Our delivery personnel may not have change.
                        </div>

                        <div class="d-grid gap-2">
                            <a href="orders.php" class="btn btn-success">
                                <i class="bi bi-bag-check"></i> View My Orders
                            </a>
                        </div>
                    </div>
                </div>

                <?php elseif ($order['payment_method'] == 'mobile'): ?>
                <!-- Mobile Money Instructions -->
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-light">
                        <h5 class="mb-0">
                            <i class="bi bi-phone text-success"></i> Mobile Money Payment Instructions
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-warning">
                            <i class="bi bi-clock-history"></i> 
                            <strong>Payment Pending:</strong> Please complete your payment within 24 hours to confirm your order.
                        </div>

                        <h6 class="fw-bold mb-3">Payment Options:</h6>
                        
                        <!-- M-Birr -->
                        <div class="card mb-3">
                            <div class="card-body">
                                <h6 class="text-success mb-3">
                                    <i class="bi bi-phone-fill"></i> M-Birr
                                </h6>
                                <ol>
                                    <li>Dial <strong>*847#</strong></li>
                                    <li>Select "Send Money"</li>
                                    <li>Enter: <strong>0911234567</strong></li>
                                    <li>Amount: <strong><?php echo number_format($order['total_price'], 2); ?> Birr</strong></li>
                                    <li>Reference: <strong>ORDER<?php echo str_pad($order['id'], 6, '0', STR_PAD_LEFT); ?></strong></li>
                                </ol>
                            </div>
                        </div>

                        <!-- HelloCash -->
                        <div class="card mb-3">
                            <div class="card-body">
                                <h6 class="text-primary mb-3">
                                    <i class="bi bi-phone-fill"></i> HelloCash
                                </h6>
                                <ol>
                                    <li>Dial <strong>*847#</strong></li>
                                    <li>Select "Send Money"</li>
                                    <li>Enter: <strong>0922345678</strong></li>
                                    <li>Amount: <strong><?php echo number_format($order['total_price'], 2); ?> Birr</strong></li>
                                    <li>Reference: <strong>ORDER<?php echo str_pad($order['id'], 6, '0', STR_PAD_LEFT); ?></strong></li>
                                </ol>
                            </div>
                        </div>

                        <div class="alert alert-info">
                            <i class="bi bi-info-circle"></i> 
                            <strong>After Payment:</strong> Your order will be automatically confirmed within 1-2 hours. You can track your order status in "My Orders".
                        </div>

                        <div class="d-grid gap-2">
                            <a href="orders.php" class="btn btn-success">
                                <i class="bi bi-bag-check"></i> View My Orders
                            </a>
                        </div>
                    </div>
                </div>

                <?php elseif ($order['payment_method'] == 'bank'): ?>
                <!-- Bank Transfer Instructions -->
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-light">
                        <h5 class="mb-0">
                            <i class="bi bi-bank text-success"></i> Bank Transfer Instructions
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-warning">
                            <i class="bi bi-clock-history"></i> 
                            <strong>Payment Pending:</strong> Please complete your bank transfer within 24 hours to confirm your order.
                        </div>

                        <h6 class="fw-bold mb-3">Bank Account Details:</h6>
                        
                        <!-- Commercial Bank of Ethiopia -->
                        <div class="card mb-3">
                            <div class="card-body">
                                <h6 class="text-success mb-3">
                                    <i class="bi bi-bank2"></i> Commercial Bank of Ethiopia
                                </h6>
                                <table class="table table-borderless mb-0">
                                    <tr>
                                        <td class="text-muted">Account Name:</td>
                                        <td><strong>AgriE-Commerce PLC</strong></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted">Account Number:</td>
                                        <td><strong>1000123456789</strong></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted">Branch:</td>
                                        <td><strong>Addis Ababa, Bole Branch</strong></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted">Amount:</td>
                                        <td><strong class="text-success"><?php echo number_format($order['total_price'], 2); ?> Birr</strong></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted">Reference:</td>
                                        <td><strong>ORDER<?php echo str_pad($order['id'], 6, '0', STR_PAD_LEFT); ?></strong></td>
                                    </tr>
                                </table>
                            </div>
                        </div>

                        <!-- Awash Bank -->
                        <div class="card mb-3">
                            <div class="card-body">
                                <h6 class="text-primary mb-3">
                                    <i class="bi bi-bank2"></i> Awash Bank
                                </h6>
                                <table class="table table-borderless mb-0">
                                    <tr>
                                        <td class="text-muted">Account Name:</td>
                                        <td><strong>AgriE-Commerce PLC</strong></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted">Account Number:</td>
                                        <td><strong>01234567890123</strong></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted">Branch:</td>
                                        <td><strong>Addis Ababa, Meskel Square</strong></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted">Amount:</td>
                                        <td><strong class="text-success"><?php echo number_format($order['total_price'], 2); ?> Birr</strong></td>
                                    </tr>
                                    <tr>
                                        <td class="text-muted">Reference:</td>
                                        <td><strong>ORDER<?php echo str_pad($order['id'], 6, '0', STR_PAD_LEFT); ?></strong></td>
                                    </tr>
                                </table>
                            </div>
                        </div>

                        <div class="alert alert-info">
                            <i class="bi bi-info-circle"></i> 
                            <strong>Important:</strong> Please include the order reference number in your transfer description. Your order will be confirmed within 24 hours after payment verification.
                        </div>

                        <div class="d-grid gap-2">
                            <a href="orders.php" class="btn btn-success">
                                <i class="bi bi-bag-check"></i> View My Orders
                            </a>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Support Card -->
                <div class="card border-0 shadow-sm mt-4">
                    <div class="card-body text-center">
                        <h6 class="mb-3">Need Help?</h6>
                        <p class="text-muted mb-3">Contact our support team if you have any questions</p>
                        <div class="d-flex justify-content-center gap-3">
                            <a href="contact.php" class="btn btn-outline-success">
                                <i class="bi bi-envelope"></i> Contact Us
                            </a>
                            <a href="tel:+251911234567" class="btn btn-outline-success">
                                <i class="bi bi-telephone"></i> Call Us
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include '../includes/footer.php'; ?>
