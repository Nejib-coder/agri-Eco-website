<?php
require_once '../includes/db.php';
require_once '../includes/session.php';

// Redirect if already logged in
if (isLoggedIn()) {
    header('Location: index.php');
    exit;
}

$page_title = 'Login';
$css_path = '../assets/css/styles.css';
$js_path = '../assets/js/main.js';
$base_url = '';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitizeInput($_POST['email']);
    $password = $_POST['password'];
    
    if (empty($email) || empty($password)) {
        $error = 'Please fill in all fields';
    } else {
        // Check user credentials
        $user = getSingleRow($conn, "SELECT * FROM users WHERE email = ?", [$email], 's');
        
        if ($user && password_verify($password, $user['password'])) {
            // Login successful
            loginUser($user);
            
            // Redirect based on user role
            if ($user['role'] === 'admin') {
                setFlashMessage('success', 'Welcome back, ' . $user['name'] . '!');
                // Correct relative path from public/ to admin/
                header("Location: ../admin/dashboard.php");
                exit;
            } else {
                // Regular customer
                $redirect = isset($_GET['redirect']) ? $_GET['redirect'] : 'index.php';
                setFlashMessage('success', 'Welcome back, ' . $user['name'] . '!');
                header("Location: $redirect");
                exit;
            }
        } else {
            if (!$user) {
                $error = 'No account found with this email address';
            } else {
                $error = 'Invalid password';
            }
        }
    }
}

include '../includes/header.php';
?>

<div class="container-fluid bg-light min-vh-100 d-flex align-items-center">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-4">
                <div class="card shadow border-0 mt-5">
                    <div class="card-body p-5">
                        <div class="text-center mb-4">
                            <i class="bi bi-person-circle text-success" style="font-size: 3rem;"></i>
                            <h2 class="mt-3 text-success">Welcome Back</h2>
                            <p class="text-muted">Sign in to your account</p>
                        </div>

                        <?php if (!empty($error)): ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo htmlspecialchars($error); ?>
                        </div>
                        <?php endif; ?>

                        <form method="POST" id="loginForm">
                            <div class="mb-3">
                                <label for="email" class="form-label">Email Address</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light border-end-0">
                                        <i class="bi bi-envelope text-muted"></i>
                                    </span>
                                    <input type="email" class="form-control border-start-0" id="email" name="email" 
                                           placeholder="Enter your email" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" required>
                                </div>
                            </div>

                            <div class="mb-4">
                                <label for="password" class="form-label">Password</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light border-end-0">
                                        <i class="bi bi-lock text-muted"></i>
                                    </span>
                                    <input type="password" class="form-control border-start-0" id="password" name="password" 
                                           placeholder="Enter your password" required>
                                </div>
                            </div>

                            <div class="d-grid">
                                <button type="submit" class="btn btn-success btn-lg">
                                    <i class="bi bi-box-arrow-in-right"></i> Sign In
                                </button>
                            </div>
                        </form>

                        <div class="text-center mt-4">
                            <p class="mb-2">
                                <a href="forgot_password.php" class="text-decoration-none">Forgot your password?</a>
                            </p>
                            <p class="text-muted">
                                Don't have an account? 
                                <a href="register.php" class="text-success text-decoration-none fw-bold">Sign up</a>
                            </p>
                        </div>

                        <!-- Demo Credentials -->
                        <div class="mt-4 p-3 bg-light rounded">
                            <small class="text-muted">
                                <strong>Demo Credentials:</strong><br>
                                Admin: admin@agriecommerce.com / admin123<br>
                                Customer: customer@example.com / customer123
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>