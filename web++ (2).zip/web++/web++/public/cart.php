<?php
require_once '../includes/db.php';
require_once '../includes/session.php';

$page_title = 'Shopping Cart';
$css_path = '../assets/css/styles.css';
$js_path = '../assets/js/main.js';
$base_url = '';

// Get cart items with product details
$cart_items = getCartItems();
$cart_products = [];
$subtotal = 0;

if (!empty($cart_items)) {
    $product_ids = array_keys($cart_items);
    $placeholders = str_repeat('?,', count($product_ids) - 1) . '?';
    $types = str_repeat('i', count($product_ids));
    
    $sql = "SELECT * FROM products WHERE id IN ($placeholders) AND status = 'active'";
    $products = getMultipleRows($conn, $sql, $product_ids, $types);
    
    foreach ($products as $product) {
        $quantity = $cart_items[$product['id']];
        $item_total = $product['price'] * $quantity;
        $subtotal += $item_total;
        
        $cart_products[] = [
            'product' => $product,
            'quantity' => $quantity,
            'item_total' => $item_total
        ];
    }
}

$shipping = !empty($cart_products) ? 100 : 0;
$tax = round($subtotal * 0.05, 2);
$total = $subtotal + $shipping + $tax;

include '../includes/header.php';
?>

<!-- Page Header -->
<section class="bg-success text-white py-4 mt-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <h1 class="h2 fw-bold mb-2">Shopping Cart</h1>
                <p class="mb-0">Review your items before checkout</p>
            </div>
            <div class="col-lg-4 text-lg-end">
                <div class="d-flex align-items-center justify-content-lg-end gap-3">
                    <i class="bi bi-cart3 fs-1"></i>
                    <div>
                        <div class="h4 mb-0"><?php echo count($cart_products); ?></div>
                        <small>Items in Cart</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Cart Content -->
<?php if (empty($cart_products)): ?>
<!-- Empty Cart State -->
<section class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 text-center">
                <i class="bi bi-cart-x display-1 text-muted mb-4"></i>
                <h3 class="text-muted mb-3">Your cart is empty</h3>
                <p class="text-muted mb-4">Looks like you haven't added any items to your cart yet.</p>
                <a href="products.php" class="btn btn-success btn-lg">
                    <i class="bi bi-shop"></i> Start Shopping
                </a>
            </div>
        </div>
    </div>
</section>
<?php else: ?>
<section class="py-5">
    <div class="container">
        <div class="row g-4">
            <!-- Cart Items -->
            <div class="col-lg-8">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Cart Items</h5>
                        <button class="btn btn-outline-danger btn-sm" onclick="clearCart()">
                            <i class="bi bi-trash"></i> Clear Cart
                        </button>
                    </div>
                    <div class="card-body p-0">
                        <?php foreach ($cart_products as $index => $item): ?>
                        <div class="cart-item <?php echo $index < count($cart_products) - 1 ? 'border-bottom' : ''; ?> p-4">
                            <div class="row align-items-center">
                                <div class="col-md-2">
                                    <img src="../<?php echo htmlspecialchars($item['product']['image']); ?>" 
                                         class="img-fluid rounded" alt="<?php echo htmlspecialchars($item['product']['name']); ?>" 
                                         style="height: 80px; width: 80px; object-fit: cover;">
                                </div>
                                <div class="col-md-4">
                                    <h6 class="text-success mb-1"><?php echo htmlspecialchars($item['product']['name']); ?></h6>
                                    <p class="text-muted small mb-1"><?php echo htmlspecialchars(substr($item['product']['description'], 0, 50)) . '...'; ?></p>
                                    <small class="text-muted">By: <?php echo htmlspecialchars($item['product']['farmer_name']); ?></small>
                                </div>
                                <div class="col-md-2">
                                    <span class="fw-bold text-success"><?php echo number_format($item['product']['price'], 2); ?> Birr</span>
                                    <small class="text-muted d-block">per unit</small>
                                </div>
                                <div class="col-md-2">
                                    <div class="input-group input-group-sm">
                                        <button class="btn btn-outline-secondary quantity-btn" type="button" 
                                                data-product-id="<?php echo $item['product']['id']; ?>" data-action="decrease">
                                            <i class="bi bi-dash"></i>
                                        </button>
                                        <input type="number" class="form-control text-center quantity-input" 
                                               value="<?php echo $item['quantity']; ?>" min="1" readonly>
                                        <button class="btn btn-outline-secondary quantity-btn" type="button" 
                                                data-product-id="<?php echo $item['product']['id']; ?>" data-action="increase">
                                            <i class="bi bi-plus"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="col-md-1 text-end">
                                    <span class="fw-bold item-total"><?php echo number_format($item['item_total'], 2); ?> Birr</span>
                                </div>
                                <div class="col-md-1 text-end">
                                    <button class="btn btn-outline-danger btn-sm remove-from-cart-btn" 
                                            data-product-id="<?php echo $item['product']['id']; ?>"
                                            data-product-name="<?php echo htmlspecialchars($item['product']['name']); ?>"
                                            title="Remove item">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Continue Shopping -->
                <div class="mt-4">
                    <a href="products.php" class="btn btn-outline-success">
                        <i class="bi bi-arrow-left"></i> Continue Shopping
                    </a>
                </div>
            </div>

            <!-- Order Summary -->
            <div class="col-lg-4">
                <div class="card border-0 shadow-sm sticky-top" style="top: 100px;">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0">Order Summary</h5>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between mb-3">
                            <span>Subtotal (<?php echo count($cart_products); ?> items):</span>
                            <span class="fw-bold"><?php echo number_format($subtotal, 2); ?> Birr</span>
                        </div>
                        <div class="d-flex justify-content-between mb-3">
                            <span>Shipping:</span>
                            <span class="fw-bold"><?php echo number_format($shipping, 2); ?> Birr</span>
                        </div>
                        <div class="d-flex justify-content-between mb-3">
                            <span>Tax (5%):</span>
                            <span class="fw-bold"><?php echo number_format($tax, 2); ?> Birr</span>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between mb-4">
                            <span class="h5">Total:</span>
                            <span class="h5 text-success fw-bold"><?php echo number_format($total, 2); ?> Birr</span>
                        </div>
                        
                        <!-- Promo Code -->
                        <div class="mb-4">
                            <label for="promoCode" class="form-label">Promo Code</label>
                            <div class="input-group">
                                <input type="text" class="form-control" id="promoCode" placeholder="Enter code">
                                <button class="btn btn-outline-success" type="button" onclick="applyPromoCode()">Apply</button>
                            </div>
                        </div>

                        <div class="d-grid gap-2">
                            <?php if (isLoggedIn()): ?>
                            <a href="checkout.php" class="btn btn-success btn-lg">
                                <i class="bi bi-credit-card"></i> Proceed to Checkout
                            </a>
                            <?php else: ?>
                            <a href="login.php?redirect=checkout.php" class="btn btn-success btn-lg">
                                <i class="bi bi-box-arrow-in-right"></i> Login to Checkout
                            </a>
                            <?php endif; ?>
                            <button class="btn btn-outline-success" onclick="saveForLater()">
                                <i class="bi bi-bookmark"></i> Save for Later
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Recommended Products -->
                <div class="card border-0 shadow-sm mt-4">
                    <div class="card-header bg-light">
                        <h6 class="mb-0">You might also like</h6>
                    </div>
                    <div class="card-body">
                        <?php
                        // Get 2 random products not in cart
                        $cart_product_ids = array_keys($cart_items);
                        $not_in_cart = !empty($cart_product_ids) ? 'AND id NOT IN (' . implode(',', $cart_product_ids) . ')' : '';
                        $recommended = getMultipleRows($conn, "SELECT * FROM products WHERE status = 'active' $not_in_cart ORDER BY RAND() LIMIT 2");
                        ?>
                        <div class="row g-3">
                            <?php foreach ($recommended as $product): ?>
                            <div class="col-6">
                                <div class="card border-0">
                                    <img src="../<?php echo htmlspecialchars($product['image']); ?>" 
                                         class="card-img-top rounded" alt="<?php echo htmlspecialchars($product['name']); ?>" 
                                         style="height: 80px; object-fit: cover;">
                                    <div class="card-body p-2">
                                        <h6 class="card-title small text-success mb-1"><?php echo htmlspecialchars($product['name']); ?></h6>
                                        <p class="small text-success fw-bold mb-1"><?php echo number_format($product['price'], 2); ?> Birr</p>
                                        <button class="btn btn-success btn-sm w-100 add-to-cart-btn" 
                                                data-product-id="<?php echo $product['id']; ?>"
                                                data-product-name="<?php echo htmlspecialchars($product['name']); ?>">Add</button>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>

<script>
function clearCart() {
    if (confirm('Are you sure you want to clear your entire cart?')) {
        fetch('ajax/cart_operations.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=clear'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                showNotification(data.message || 'Error clearing cart', 'error');
            }
        });
    }
}

function applyPromoCode() {
    const code = document.getElementById('promoCode').value.trim();
    if (code) {
        // Demo promo codes
        const validCodes = {
            'SAVE10': 10,
            'FARMER20': 20,
            'ORGANIC15': 15
        };
        
        if (validCodes[code.toUpperCase()]) {
            showNotification(`Promo code applied! ${validCodes[code.toUpperCase()]}% discount`, 'success');
        } else {
            showNotification('Invalid promo code', 'error');
        }
    }
}

function saveForLater() {
    showNotification('Items saved for later! You can find them in your account.', 'success');
}
</script>