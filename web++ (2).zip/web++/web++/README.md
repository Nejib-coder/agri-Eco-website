# AgriE-Commerce Platform

A complete e-commerce platform for agricultural products built with PHP, MySQL, and Bootstrap 5.

## 📋 Table of Contents
- [Features](#features)
- [Installation](#installation)
- [Database Setup](#database-setup)
- [Project Structure](#project-structure)
- [User Roles](#user-roles)
- [Payment System](#payment-system)
- [Testing](#testing)
- [Documentation](#documentation)

## ✨ Features

### Customer Features
- User registration and authentication
- Browse products by category
- Shopping cart management
- Multiple payment methods (Cash, Mobile Money, Bank Transfer)
- Order tracking with status updates
- Payment status tracking
- Order history
- User profile management
- Contact form

### Admin Features
- Admin dashboard with statistics
- Product management (CRUD operations)
- Order management
- Payment confirmation system
- Customer message management
- Order status updates
- Sales analytics

## 🚀 Installation

### Prerequisites
- XAMPP (or similar) with PHP 7.4+ and MySQL
- Web browser
- Text editor (optional)

### Steps

1. **Install XAMPP**
   - Download from [https://www.apachefriends.org](https://www.apachefriends.org)
   - Install and start Apache and MySQL

2. **Copy Project Files**
   ```
   Copy the web++ folder to: C:\xampp\htdocs\
   ```

3. **Setup Database**
   - Open phpMyAdmin: http://localhost/phpmyadmin
   - Click "Import" or "SQL" tab
   - Run the SQL file: `web++/database/database_setup.sql`
   - This creates the database with all tables and sample data

4. **Access the Application**
   - Customer Site: http://localhost/web++/public/
   - Admin Panel: http://localhost/web++/admin/

## 💾 Database Setup

### Automatic Setup
Run this single SQL file in phpMyAdmin:
```
web++/database/database_setup.sql
```

This creates:
- Database: `agri_ecommerce`
- All tables with proper relationships
- Sample products and categories
- Admin and customer demo accounts
- Payment tracking fields

### Demo Accounts

**Admin Account:**
- Email: `admin@agriecommerce.com`
- Password: `admin123`

**Customer Account:**
- Email: `customer@example.com`
- Password: `customer123`

## 📁 Project Structure

```
web++/
├── admin/                      # Admin panel
│   ├── dashboard.php          # Admin dashboard
│   ├── orders.php             # Order management
│   ├── order_details_ajax.php # Order details modal
│   ├── products.php           # Product management
│   ├── messages.php           # Customer messages
│   └── message_details_ajax.php
│
├── public/                     # Customer-facing pages
│   ├── index.php              # Homepage
│   ├── products.php           # Product listing
│   ├── product.php            # Product details
│   ├── cart.php               # Shopping cart
│   ├── checkout.php           # Checkout process
│   ├── orders.php             # Order history
│   ├── payment_instructions.php # Payment guide
│   ├── profile.php            # User profile
│   ├── login.php              # Login page
│   ├── register.php           # Registration
│   ├── about.php              # About page
│   ├── contact.php            # Contact form
│   └── ajax/                  # AJAX endpoints
│       ├── order_details.php  # Order details modal
│       ├── cart_operations.php
│       ├── cancel_order.php
│       ├── reorder.php
│       └── get_cart_count.php
│
├── includes/                   # Shared PHP files
│   ├── db.php                 # Database connection
│   ├── session.php            # Session management
│   ├── header.php             # Site header
│   └── footer.php             # Site footer
│
├── assets/                     # Static resources
│   ├── css/                   # Stylesheets
│   ├── js/                    # JavaScript files
│   └── images/                # Product images
│
├── database/                   # Database files
│   ├── database_setup.sql     # Complete DB setup
│   └── fix_demo_passwords.sql # Password reset script
│
├── docs/                       # Documentation
│   ├── INSTALLATION_GUIDE.md
│   ├── PAYMENT_SYSTEM_GUIDE.md
│   ├── README_UNIVERSITY.md
│   └── SYSTEM_FIXES_SUMMARY.md
│
├── legacy/                     # Old HTML templates
│   └── (static HTML files)
│
└── README.md                   # This file
```

## 👥 User Roles

### Customer
- Browse and purchase products
- Manage shopping cart
- Place orders
- Track order status
- View payment instructions
- Manage profile

### Admin
- Full system access
- Manage products
- Process orders
- Confirm payments
- View analytics
- Respond to messages

## 💳 Payment System

### Payment Methods

1. **Cash on Delivery**
   - Customer pays upon delivery
   - No upfront payment required
   - Status: Unpaid until delivery

2. **Mobile Money**
   - M-Birr, HelloCash supported
   - Customer receives USSD codes
   - Admin confirms payment manually

3. **Bank Transfer**
   - Bank account details provided
   - Customer transfers to company account
   - Admin verifies and confirms

### Payment Workflow

```
Customer Places Order
    ↓
Payment Status: Unpaid
    ↓
Customer Sees Payment Instructions
    ↓
Customer Makes Payment
    ↓
Admin Verifies Payment
    ↓
Admin Confirms Payment
    ↓
Payment Status: Paid
    ↓
Order Processed & Shipped
```

### Payment Status
- **Unpaid** (Yellow) - Awaiting payment
- **Paid** (Green) - Payment confirmed
- **Failed** (Red) - Payment rejected

## 🧪 Testing

### Test as Customer
1. Go to: http://localhost/web++/public/
2. Register new account or login:
   - Email: `customer@example.com`
   - Password: `customer123`
3. Add products to cart
4. Complete checkout
5. View payment instructions
6. Check order status in "My Orders"

### Test as Admin
1. Go to: http://localhost/web++/admin/
2. Login with:
   - Email: `admin@agriecommerce.com`
   - Password: `admin123`
3. View dashboard statistics
4. Manage orders
5. Confirm payments
6. Update order status

### Test Payment System
1. Place order as customer
2. Note the order ID
3. Login as admin
4. Go to Orders
5. Find the order
6. Click payment confirmation button
7. Verify status changes to "Paid"
8. Check customer's order page shows updated status

## 📚 Documentation

Detailed guides available in `/docs/` folder:

- **INSTALLATION_GUIDE.md** - Step-by-step setup
- **PAYMENT_SYSTEM_GUIDE.md** - Payment features explained
- **README_UNIVERSITY.md** - University project notes
- **SYSTEM_FIXES_SUMMARY.md** - Bug fixes and improvements

## 🔧 Configuration

### Database Connection
Edit `includes/db.php` if needed:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'agri_ecommerce');
```

### File Paths
All paths are relative and should work automatically when placed in `htdocs/web++/`

## 🐛 Troubleshooting

### Common Issues

**Database Connection Error**
- Ensure MySQL is running in XAMPP
- Verify database name is `agri_ecommerce`
- Check credentials in `includes/db.php`

**Images Not Loading**
- Check image paths in database
- Ensure images exist in `assets/images/`
- Verify file permissions

**Login Not Working**
- Clear browser cache
- Check if database was imported correctly
- Try demo accounts provided above

**Orders Page Blank**
- Ensure you ran the complete `database_setup.sql`
- Check if payment_status fields exist in orders table
- Verify user is logged in

## 🎓 University Project Notes

This project demonstrates:
- **Full-stack development** with PHP and MySQL
- **MVC-like architecture** with separation of concerns
- **Database design** with proper relationships
- **User authentication** and session management
- **CRUD operations** for all entities
- **Payment workflow** implementation
- **Responsive design** with Bootstrap 5
- **AJAX** for dynamic content loading
- **Security practices** (prepared statements, input sanitization)

## 📝 License

This is an educational project for university coursework.

## 👨‍💻 Support

For issues or questions:
1. Check the documentation in `/docs/`
2. Review code comments
3. Test with demo accounts
4. Verify database setup

---

**Version:** 2.0  
**Last Updated:** January 2026  
**Built with:** PHP, MySQL, Bootstrap 5, JavaScript
