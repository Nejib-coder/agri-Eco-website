# Quick Start Guide

Get your AgriE-Commerce platform running in 5 minutes!

## 🚀 Quick Setup

### 1. Install XAMPP
- Download: https://www.apachefriends.org
- Install and start **Apache** and **MySQL**

### 2. Copy Files
```
Copy web++ folder to: C:\xampp\htdocs\
```

### 3. Setup Database
1. Open: http://localhost/phpmyadmin
2. Click "SQL" tab
3. Copy and paste content from: `web++/database/database_setup.sql`
4. Click "Go"

### 4. Access Application

**Customer Site:**
```
http://localhost/web++/public/
```

**Admin Panel:**
```
http://localhost/web++/admin/
```

## 🔑 Demo Accounts

### Admin Login
- Email: `admin@agriecommerce.com`
- Password: `admin123`

### Customer Login
- Email: `customer@example.com`
- Password: `customer123`

## ✅ Test Checklist

- [ ] Can access homepage
- [ ] Can login as customer
- [ ] Can add products to cart
- [ ] Can complete checkout
- [ ] Can view orders
- [ ] Can login as admin
- [ ] Can view dashboard
- [ ] Can manage orders
- [ ] Can confirm payments

## 🐛 Problems?

**Can't connect to database?**
- Make sure MySQL is running in XAMPP
- Check database name is `agri_ecommerce`

**Images not showing?**
- Images are in `assets/images/imges/` folder
- Check if folder exists

**Login not working?**
- Clear browser cache
- Use demo accounts above
- Check if database was imported

## 📚 Need More Help?

See full documentation:
- `README.md` - Complete guide
- `docs/INSTALLATION_GUIDE.md` - Detailed setup
- `docs/PAYMENT_SYSTEM_GUIDE.md` - Payment features

---

**That's it! You're ready to go! 🎉**
