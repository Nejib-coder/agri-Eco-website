    <!-- Footer -->
    <footer class="bg-success text-white py-5">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-4">
                    <h5 class="fw-bold mb-3">AgriE-Commerce</h5>
                    <p class="text-light opacity-75">
                        Fresh agricultural products directly from farmers to your doorstep. 
                        Supporting local agriculture since 2023.
                    </p>
                </div>
                <div class="col-lg-4">
                    <h6 class="fw-bold mb-3">Quick Links</h6>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo isset($base_url) ? $base_url : ''; ?>index.php" class="text-light text-decoration-none opacity-75">Home</a></li>
                        <li><a href="<?php echo isset($base_url) ? $base_url : ''; ?>products.php" class="text-light text-decoration-none opacity-75">Products</a></li>
                        <li><a href="<?php echo isset($base_url) ? $base_url : ''; ?>cart.php" class="text-light text-decoration-none opacity-75">Cart</a></li>
                        <li><a href="<?php echo isset($base_url) ? $base_url : ''; ?>about.php" class="text-light text-decoration-none opacity-75">About</a></li>
                        <li><a href="<?php echo isset($base_url) ? $base_url : ''; ?>contact.php" class="text-light text-decoration-none opacity-75">Contact</a></li>
                    </ul>
                </div>
                <div class="col-lg-4">
                    <h6 class="fw-bold mb-3">Connect With Us</h6>
                    <div class="d-flex gap-3 mb-3">
                        <a href="#" class="text-light"><i class="bi bi-facebook fs-4"></i></a>
                        <a href="#" class="text-light"><i class="bi bi-twitter fs-4"></i></a>
                        <a href="#" class="text-light"><i class="bi bi-instagram fs-4"></i></a>
                        <a href="#" class="text-light"><i class="bi bi-linkedin fs-4"></i></a>
                    </div>
                    <?php if (isAdmin()): ?>
                    <a href="<?php echo isset($base_url) ? '../admin/' : 'admin/'; ?>dashboard.php" class="btn btn-warning">
                        <i class="bi bi-speedometer2"></i> Admin Dashboard
                    </a>
                    <?php endif; ?>
                </div>
            </div>
            <hr class="my-4 opacity-25">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <p class="mb-0 text-light opacity-75">&copy; <?php echo date('Y'); ?> AgriE-Commerce. All rights reserved.</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <p class="mb-0 text-light opacity-75">Supporting sustainable farming practices</p>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Validation JavaScript -->
    <script src="<?php echo isset($base_url) ? str_replace('../public/', '../', $base_url) : '../'; ?>assets/js/validation.js"></script>
    <!-- Custom JavaScript -->
    <script src="<?php echo isset($js_path) ? $js_path : 'assets/js/main.js'; ?>"></script>
</body>
</html>