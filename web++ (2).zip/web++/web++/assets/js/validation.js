/**
 * Comprehensive Form Validation for AgriE-Commerce
 * University Project - Clean, Well-Commented JavaScript
 * 
 * This file handles ALL client-side form validation
 * Do NOT mix validation logic inside HTML files
 */

// Validation utility functions
const ValidationUtils = {
    /**
     * Check if email format is valid
     */
    isValidEmail: function(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    },

    /**
     * Check if string contains only letters and spaces
     */
    isValidName: function(name) {
        const nameRegex = /^[a-zA-Z\s]+$/;
        return nameRegex.test(name.trim());
    },

    /**
     * Check if phone number is valid (Ethiopian format)
     */
    isValidPhone: function(phone) {
        // Remove spaces and special characters
        const cleanPhone = phone.replace(/[\s\-\(\)]/g, '');
        // Ethiopian phone: +251XXXXXXXXX or 09XXXXXXXX or 07XXXXXXXX
        const phoneRegex = /^(\+251|0)[79]\d{8}$/;
        return phoneRegex.test(cleanPhone);
    },

    /**
     * Check if price is valid (numeric and greater than 0)
     */
    isValidPrice: function(price) {
        const numPrice = parseFloat(price);
        return !isNaN(numPrice) && numPrice > 0;
    },

    /**
     * Check if quantity is valid (integer and greater than 0)
     */
    isValidQuantity: function(quantity) {
        const numQuantity = parseInt(quantity);
        return !isNaN(numQuantity) && numQuantity > 0;
    },

    /**
     * Show error message for a field
     */
    showError: function(fieldId, message) {
        const field = document.getElementById(fieldId);
        if (!field) return;

        // Remove existing error
        this.clearError(fieldId);

        // Add error class to field
        field.classList.add('is-invalid');

        // Create error message element
        const errorDiv = document.createElement('div');
        errorDiv.className = 'invalid-feedback';
        errorDiv.id = fieldId + '_error';
        errorDiv.textContent = message;

        // Insert error message after the field
        field.parentNode.insertBefore(errorDiv, field.nextSibling);
    },

    /**
     * Clear error message for a field
     */
    clearError: function(fieldId) {
        const field = document.getElementById(fieldId);
        if (!field) return;

        // Remove error class
        field.classList.remove('is-invalid');
        field.classList.add('is-valid');

        // Remove error message
        const errorElement = document.getElementById(fieldId + '_error');
        if (errorElement) {
            errorElement.remove();
        }
    },

    /**
     * Clear all errors in a form
     */
    clearAllErrors: function(formId) {
        const form = document.getElementById(formId);
        if (!form) return;

        // Remove all error classes and messages
        const invalidFields = form.querySelectorAll('.is-invalid');
        invalidFields.forEach(field => {
            field.classList.remove('is-invalid');
        });

        const errorMessages = form.querySelectorAll('.invalid-feedback');
        errorMessages.forEach(error => error.remove());
    }
};

/**
 * Registration Form Validation
 */
const RegistrationValidator = {
    validateForm: function(formId) {
        const form = document.getElementById(formId);
        if (!form) return false;

        let isValid = true;
        ValidationUtils.clearAllErrors(formId);

        // Get form fields
        const name = document.getElementById('name');
        const email = document.getElementById('email');
        const password = document.getElementById('password');
        const confirmPassword = document.getElementById('confirm_password');
        const phone = document.getElementById('phone');

        // Validate name
        if (!name.value.trim()) {
            ValidationUtils.showError('name', 'Full name is required');
            isValid = false;
        } else if (name.value.trim().length < 2) {
            ValidationUtils.showError('name', 'Name must be at least 2 characters');
            isValid = false;
        } else if (!ValidationUtils.isValidName(name.value)) {
            ValidationUtils.showError('name', 'Name can only contain letters and spaces');
            isValid = false;
        } else {
            ValidationUtils.clearError('name');
        }

        // Validate email
        if (!email.value.trim()) {
            ValidationUtils.showError('email', 'Email address is required');
            isValid = false;
        } else if (!ValidationUtils.isValidEmail(email.value)) {
            ValidationUtils.showError('email', 'Please enter a valid email address');
            isValid = false;
        } else {
            ValidationUtils.clearError('email');
        }

        // Validate password
        if (!password.value) {
            ValidationUtils.showError('password', 'Password is required');
            isValid = false;
        } else if (password.value.length < 6) {
            ValidationUtils.showError('password', 'Password must be at least 6 characters');
            isValid = false;
        } else {
            ValidationUtils.clearError('password');
        }

        // Validate confirm password
        if (!confirmPassword.value) {
            ValidationUtils.showError('confirm_password', 'Please confirm your password');
            isValid = false;
        } else if (password.value !== confirmPassword.value) {
            ValidationUtils.showError('confirm_password', 'Passwords do not match');
            isValid = false;
        } else {
            ValidationUtils.clearError('confirm_password');
        }

        // Validate phone (optional but if provided must be valid)
        if (phone && phone.value.trim()) {
            if (!ValidationUtils.isValidPhone(phone.value)) {
                ValidationUtils.showError('phone', 'Please enter a valid Ethiopian phone number');
                isValid = false;
            } else {
                ValidationUtils.clearError('phone');
            }
        }

        return isValid;
    },

    // Real-time validation for registration form
    setupRealTimeValidation: function(formId) {
        const form = document.getElementById(formId);
        if (!form) return;

        // Password confirmation real-time check
        const password = document.getElementById('password');
        const confirmPassword = document.getElementById('confirm_password');

        if (password && confirmPassword) {
            confirmPassword.addEventListener('input', function() {
                if (this.value && password.value !== this.value) {
                    ValidationUtils.showError('confirm_password', 'Passwords do not match');
                } else if (this.value && password.value === this.value) {
                    ValidationUtils.clearError('confirm_password');
                }
            });
        }

        // Email format check
        const email = document.getElementById('email');
        if (email) {
            email.addEventListener('blur', function() {
                if (this.value && !ValidationUtils.isValidEmail(this.value)) {
                    ValidationUtils.showError('email', 'Please enter a valid email address');
                } else if (this.value && ValidationUtils.isValidEmail(this.value)) {
                    ValidationUtils.clearError('email');
                }
            });
        }
    }
};

/**
 * Login Form Validation
 */
const LoginValidator = {
    validateForm: function(formId) {
        const form = document.getElementById(formId);
        if (!form) return false;

        let isValid = true;
        ValidationUtils.clearAllErrors(formId);

        // Get form fields
        const email = document.getElementById('email');
        const password = document.getElementById('password');

        // Validate email
        if (!email.value.trim()) {
            ValidationUtils.showError('email', 'Email address is required');
            isValid = false;
        } else if (!ValidationUtils.isValidEmail(email.value)) {
            ValidationUtils.showError('email', 'Please enter a valid email address');
            isValid = false;
        } else {
            ValidationUtils.clearError('email');
        }

        // Validate password
        if (!password.value) {
            ValidationUtils.showError('password', 'Password is required');
            isValid = false;
        } else {
            ValidationUtils.clearError('password');
        }

        return isValid;
    }
};

/**
 * Checkout Form Validation
 */
const CheckoutValidator = {
    validateForm: function(formId) {
        const form = document.getElementById(formId);
        if (!form) return false;

        let isValid = true;
        ValidationUtils.clearAllErrors(formId);

        // Get form fields
        const name = document.getElementById('name');
        const email = document.getElementById('email');
        const phone = document.getElementById('phone');
        const address = document.getElementById('address');
        const city = document.getElementById('city');

        // Validate name
        if (!name.value.trim()) {
            ValidationUtils.showError('name', 'Full name is required');
            isValid = false;
        } else if (!ValidationUtils.isValidName(name.value)) {
            ValidationUtils.showError('name', 'Name can only contain letters and spaces');
            isValid = false;
        } else {
            ValidationUtils.clearError('name');
        }

        // Validate email
        if (!email.value.trim()) {
            ValidationUtils.showError('email', 'Email address is required');
            isValid = false;
        } else if (!ValidationUtils.isValidEmail(email.value)) {
            ValidationUtils.showError('email', 'Please enter a valid email address');
            isValid = false;
        } else {
            ValidationUtils.clearError('email');
        }

        // Validate phone
        if (!phone.value.trim()) {
            ValidationUtils.showError('phone', 'Phone number is required');
            isValid = false;
        } else if (!ValidationUtils.isValidPhone(phone.value)) {
            ValidationUtils.showError('phone', 'Please enter a valid Ethiopian phone number (+251XXXXXXXXX or 09XXXXXXXX)');
            isValid = false;
        } else {
            ValidationUtils.clearError('phone');
        }

        // Validate address
        if (!address.value.trim()) {
            ValidationUtils.showError('address', 'Street address is required');
            isValid = false;
        } else if (address.value.trim().length < 10) {
            ValidationUtils.showError('address', 'Please provide a complete address (minimum 10 characters)');
            isValid = false;
        } else {
            ValidationUtils.clearError('address');
        }

        // Validate city
        if (!city.value.trim()) {
            ValidationUtils.showError('city', 'City is required');
            isValid = false;
        } else {
            ValidationUtils.clearError('city');
        }

        return isValid;
    }
};

/**
 * Contact Form Validation
 */
const ContactValidator = {
    validateForm: function(formId) {
        const form = document.getElementById(formId);
        if (!form) return false;

        let isValid = true;
        ValidationUtils.clearAllErrors(formId);

        // Get form fields
        const name = document.getElementById('name');
        const email = document.getElementById('email');
        const subject = document.getElementById('subject');
        const message = document.getElementById('message');

        // Validate name
        if (!name.value.trim()) {
            ValidationUtils.showError('name', 'Your name is required');
            isValid = false;
        } else if (!ValidationUtils.isValidName(name.value)) {
            ValidationUtils.showError('name', 'Name can only contain letters and spaces');
            isValid = false;
        } else {
            ValidationUtils.clearError('name');
        }

        // Validate email
        if (!email.value.trim()) {
            ValidationUtils.showError('email', 'Email address is required');
            isValid = false;
        } else if (!ValidationUtils.isValidEmail(email.value)) {
            ValidationUtils.showError('email', 'Please enter a valid email address');
            isValid = false;
        } else {
            ValidationUtils.clearError('email');
        }

        // Validate subject (optional but if provided must be reasonable length)
        if (subject && subject.value.trim() && subject.value.trim().length < 3) {
            ValidationUtils.showError('subject', 'Subject must be at least 3 characters');
            isValid = false;
        } else if (subject) {
            ValidationUtils.clearError('subject');
        }

        // Validate message
        if (!message.value.trim()) {
            ValidationUtils.showError('message', 'Message is required');
            isValid = false;
        } else if (message.value.trim().length < 10) {
            ValidationUtils.showError('message', 'Message must be at least 10 characters');
            isValid = false;
        } else {
            ValidationUtils.clearError('message');
        }

        return isValid;
    }
};

/**
 * Admin Product Form Validation
 */
const ProductValidator = {
    validateForm: function(formId) {
        const form = document.getElementById(formId);
        if (!form) return false;

        let isValid = true;
        ValidationUtils.clearAllErrors(formId);

        // Get form fields
        const name = document.getElementById('name') || document.getElementById('edit_name');
        const price = document.getElementById('price') || document.getElementById('edit_price');
        const categoryId = document.getElementById('category_id') || document.getElementById('edit_category_id');
        const stockQuantity = document.getElementById('stock_quantity') || document.getElementById('edit_stock_quantity');
        const image = document.getElementById('image') || document.getElementById('edit_image');

        // Validate product name
        if (!name.value.trim()) {
            ValidationUtils.showError(name.id, 'Product name is required');
            isValid = false;
        } else if (name.value.trim().length < 3) {
            ValidationUtils.showError(name.id, 'Product name must be at least 3 characters');
            isValid = false;
        } else {
            ValidationUtils.clearError(name.id);
        }

        // Validate price
        if (!price.value.trim()) {
            ValidationUtils.showError(price.id, 'Price is required');
            isValid = false;
        } else if (!ValidationUtils.isValidPrice(price.value)) {
            ValidationUtils.showError(price.id, 'Price must be a valid number greater than 0');
            isValid = false;
        } else {
            ValidationUtils.clearError(price.id);
        }

        // Validate category
        if (!categoryId.value) {
            ValidationUtils.showError(categoryId.id, 'Please select a category');
            isValid = false;
        } else {
            ValidationUtils.clearError(categoryId.id);
        }

        // Validate stock quantity
        if (!stockQuantity.value.trim()) {
            ValidationUtils.showError(stockQuantity.id, 'Stock quantity is required');
            isValid = false;
        } else if (!ValidationUtils.isValidQuantity(stockQuantity.value)) {
            ValidationUtils.showError(stockQuantity.id, 'Stock quantity must be a valid number greater than 0');
            isValid = false;
        } else {
            ValidationUtils.clearError(stockQuantity.id);
        }

        // Validate image (optional but if provided should have valid format)
        if (image && image.value.trim()) {
            const validExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp'];
            const hasValidExtension = validExtensions.some(ext => 
                image.value.toLowerCase().endsWith(ext)
            );
            
            if (!hasValidExtension) {
                ValidationUtils.showError(image.id, 'Image must be a valid format (.jpg, .png, .gif, .webp)');
                isValid = false;
            } else {
                ValidationUtils.clearError(image.id);
            }
        }

        return isValid;
    }
};

/**
 * Initialize validation for all forms on page load
 */
document.addEventListener('DOMContentLoaded', function() {
    // Registration form
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        RegistrationValidator.setupRealTimeValidation('registerForm');
        registerForm.addEventListener('submit', function(e) {
            if (!RegistrationValidator.validateForm('registerForm')) {
                e.preventDefault();
                // Scroll to first error
                const firstError = document.querySelector('.is-invalid');
                if (firstError) {
                    firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    firstError.focus();
                }
            }
        });
    }

    // Login form
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            if (!LoginValidator.validateForm('loginForm')) {
                e.preventDefault();
                const firstError = document.querySelector('.is-invalid');
                if (firstError) {
                    firstError.focus();
                }
            }
        });
    }

    // Checkout form
    const checkoutForm = document.getElementById('checkoutForm');
    if (checkoutForm) {
        checkoutForm.addEventListener('submit', function(e) {
            if (!CheckoutValidator.validateForm('checkoutForm')) {
                e.preventDefault();
                const firstError = document.querySelector('.is-invalid');
                if (firstError) {
                    firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    firstError.focus();
                }
            }
        });
    }

    // Contact form
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            if (!ContactValidator.validateForm('contactForm')) {
                e.preventDefault();
                const firstError = document.querySelector('.is-invalid');
                if (firstError) {
                    firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    firstError.focus();
                }
            }
        });
    }

    // Admin product forms (add and edit)
    const addProductForm = document.getElementById('addProductForm');
    if (addProductForm) {
        addProductForm.addEventListener('submit', function(e) {
            if (!ProductValidator.validateForm('addProductForm')) {
                e.preventDefault();
                const firstError = document.querySelector('.is-invalid');
                if (firstError) {
                    firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    firstError.focus();
                }
            }
        });
    }

    const editProductForm = document.getElementById('editProductForm');
    if (editProductForm) {
        editProductForm.addEventListener('submit', function(e) {
            if (!ProductValidator.validateForm('editProductForm')) {
                e.preventDefault();
                const firstError = document.querySelector('.is-invalid');
                if (firstError) {
                    firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    firstError.focus();
                }
            }
        });
    }

    // Real-time validation for price fields
    const priceFields = document.querySelectorAll('input[type="number"][name="price"]');
    priceFields.forEach(field => {
        field.addEventListener('input', function() {
            if (this.value && !ValidationUtils.isValidPrice(this.value)) {
                ValidationUtils.showError(this.id, 'Price must be greater than 0');
            } else if (this.value && ValidationUtils.isValidPrice(this.value)) {
                ValidationUtils.clearError(this.id);
            }
        });
    });

    // Real-time validation for phone fields
    const phoneFields = document.querySelectorAll('input[type="tel"], input[name="phone"]');
    phoneFields.forEach(field => {
        field.addEventListener('blur', function() {
            if (this.value && !ValidationUtils.isValidPhone(this.value)) {
                ValidationUtils.showError(this.id, 'Please enter a valid phone number');
            } else if (this.value && ValidationUtils.isValidPhone(this.value)) {
                ValidationUtils.clearError(this.id);
            }
        });
    });
});

// Export for use in other scripts if needed
window.ValidationUtils = ValidationUtils;
window.RegistrationValidator = RegistrationValidator;
window.LoginValidator = LoginValidator;
window.CheckoutValidator = CheckoutValidator;
window.ContactValidator = ContactValidator;
window.ProductValidator = ProductValidator;