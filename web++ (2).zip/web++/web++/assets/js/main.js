/**
 * AgriE-Commerce Main JavaScript File
 * Handles frontend interactivity and AJAX operations
 */

// Global variables
let cartCount = 0;

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

/**
 * Initialize application
 */
function initializeApp() {
    updateCartBadge();
    initializeFormValidation();
    initializeCartFunctionality();
    initializeProductSearch();
    initializeCheckoutCalculations();
}

/**
 * Form Validation Functions
 */
function initializeFormValidation() {
    // Login form validation
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', validateLoginForm);
    }

    // Register form validation
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', validateRegisterForm);
    }

    // Contact form validation
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', validateContactForm);
    }

    // Checkout form validation
    const checkoutForm = document.getElementById('checkoutForm');
    if (checkoutForm) {
        checkoutForm.addEventListener('submit', validateCheckoutForm);
    }
}

function validateLoginForm(e) {
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();
    
    let isValid = true;
    
    // Email validation
    if (!email) {
        showFieldError('email', 'Email is required');
        isValid = false;
    } else if (!isValidEmail(email)) {
        showFieldError('email', 'Please enter a valid email');
        isValid = false;
    } else {
        clearFieldError('email');
    }
    
    // Password validation
    if (!password) {
        showFieldError('password', 'Password is required');
        isValid = false;
    } else if (password.length < 6) {
        showFieldError('password', 'Password must be at least 6 characters');
        isValid = false;
    } else {
        clearFieldError('password');
    }
    
    if (!isValid) {
        e.preventDefault();
    }
}

function validateRegisterForm(e) {
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();
    const confirmPassword = document.getElementById('confirm_password').value.trim();
    
    let isValid = true;
    
    // Name validation
    if (!name) {
        showFieldError('name', 'Name is required');
        isValid = false;
    } else if (name.length < 2) {
        showFieldError('name', 'Name must be at least 2 characters');
        isValid = false;
    } else {
        clearFieldError('name');
    }
    
    // Email validation
    if (!email) {
        showFieldError('email', 'Email is required');
        isValid = false;
    } else if (!isValidEmail(email)) {
        showFieldError('email', 'Please enter a valid email');
        isValid = false;
    } else {
        clearFieldError('email');
    }
    
    // Password validation
    if (!password) {
        showFieldError('password', 'Password is required');
        isValid = false;
    } else if (password.length < 6) {
        showFieldError('password', 'Password must be at least 6 characters');
        isValid = false;
    } else {
        clearFieldError('password');
    }
    
    // Confirm password validation
    if (!confirmPassword) {
        showFieldError('confirm_password', 'Please confirm your password');
        isValid = false;
    } else if (password !== confirmPassword) {
        showFieldError('confirm_password', 'Passwords do not match');
        isValid = false;
    } else {
        clearFieldError('confirm_password');
    }
    
    if (!isValid) {
        e.preventDefault();
    }
}

function validateContactForm(e) {
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const message = document.getElementById('message').value.trim();
    
    let isValid = true;
    
    if (!name) {
        showFieldError('name', 'Name is required');
        isValid = false;
    } else {
        clearFieldError('name');
    }
    
    if (!email || !isValidEmail(email)) {
        showFieldError('email', 'Please enter a valid email');
        isValid = false;
    } else {
        clearFieldError('email');
    }
    
    if (!message) {
        showFieldError('message', 'Message is required');
        isValid = false;
    } else {
        clearFieldError('message');
    }
    
    if (!isValid) {
        e.preventDefault();
    }
}

function validateCheckoutForm(e) {
    const requiredFields = ['name', 'email', 'phone', 'address', 'city'];
    let isValid = true;
    
    requiredFields.forEach(field => {
        const value = document.getElementById(field).value.trim();
        if (!value) {
            showFieldError(field, `${field.charAt(0).toUpperCase() + field.slice(1)} is required`);
            isValid = false;
        } else {
            clearFieldError(field);
        }
    });
    
    // Email validation
    const email = document.getElementById('email').value.trim();
    if (email && !isValidEmail(email)) {
        showFieldError('email', 'Please enter a valid email');
        isValid = false;
    }
    
    if (!isValid) {
        e.preventDefault();
    }
}

/**
 * Cart Functionality
 */
function initializeCartFunctionality() {
    // Add to cart buttons
    document.querySelectorAll('.add-to-cart-btn').forEach(button => {
        button.addEventListener('click', function() {
            const productId = this.dataset.productId;
            const productName = this.dataset.productName;
            addToCartAjax(productId, 1, productName);
        });
    });

    // Cart quantity update buttons
    document.querySelectorAll('.quantity-btn').forEach(button => {
        button.addEventListener('click', function() {
            const productId = this.dataset.productId;
            const action = this.dataset.action;
            const currentQty = parseInt(this.parentElement.querySelector('.quantity-input').value);
            
            let newQty = currentQty;
            if (action === 'increase') {
                newQty = currentQty + 1;
            } else if (action === 'decrease' && currentQty > 1) {
                newQty = currentQty - 1;
            }
            
            updateCartQuantityAjax(productId, newQty);
        });
    });

    // Remove from cart buttons
    document.querySelectorAll('.remove-from-cart-btn').forEach(button => {
        button.addEventListener('click', function() {
            const productId = this.dataset.productId;
            const productName = this.dataset.productName;
            
            if (confirm(`Are you sure you want to remove ${productName} from your cart?`)) {
                removeFromCartAjax(productId);
            }
        });
    });
}

function addToCartAjax(productId, quantity, productName) {
    fetch('ajax/cart_operations.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `action=add&product_id=${productId}&quantity=${quantity}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification(`${productName} added to cart!`, 'success');
            updateCartBadge();
        } else {
            showNotification(data.message || 'Error adding to cart', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('Error adding to cart', 'error');
    });
}

function updateCartQuantityAjax(productId, quantity) {
    fetch('ajax/cart_operations.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `action=update&product_id=${productId}&quantity=${quantity}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload(); // Reload to update cart display
        } else {
            showNotification(data.message || 'Error updating cart', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('Error updating cart', 'error');
    });
}

function removeFromCartAjax(productId) {
    fetch('ajax/cart_operations.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `action=remove&product_id=${productId}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload(); // Reload to update cart display
        } else {
            showNotification(data.message || 'Error removing from cart', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('Error removing from cart', 'error');
    });
}

/**
 * Product Search and Filter
 */
function initializeProductSearch() {
    const searchInput = document.getElementById('searchInput');
    const categoryFilter = document.getElementById('categoryFilter');
    const sortFilter = document.getElementById('sortFilter');

    if (searchInput) {
        searchInput.addEventListener('input', debounce(filterProducts, 300));
    }

    if (categoryFilter) {
        categoryFilter.addEventListener('change', filterProducts);
    }

    if (sortFilter) {
        sortFilter.addEventListener('change', filterProducts);
    }
}

function filterProducts() {
    const searchTerm = document.getElementById('searchInput')?.value.toLowerCase() || '';
    const selectedCategory = document.getElementById('categoryFilter')?.value || '';
    const sortBy = document.getElementById('sortFilter')?.value || '';

    const productItems = document.querySelectorAll('.product-item');
    let visibleCount = 0;

    // Filter products
    productItems.forEach(item => {
        const productName = item.dataset.name?.toLowerCase() || '';
        const productCategory = item.dataset.category || '';
        
        const matchesSearch = productName.includes(searchTerm);
        const matchesCategory = !selectedCategory || productCategory === selectedCategory;
        
        if (matchesSearch && matchesCategory) {
            item.style.display = 'block';
            visibleCount++;
        } else {
            item.style.display = 'none';
        }
    });

    // Sort products
    if (sortBy) {
        sortProducts(sortBy);
    }

    // Update product count
    const productCount = document.getElementById('productCount');
    if (productCount) {
        productCount.textContent = `Showing ${visibleCount} products`;
    }
}

function sortProducts(sortBy) {
    const container = document.getElementById('productsContainer');
    if (!container) return;

    const items = Array.from(container.querySelectorAll('.product-item'));
    
    items.sort((a, b) => {
        switch(sortBy) {
            case 'price-low':
                return parseFloat(a.dataset.price) - parseFloat(b.dataset.price);
            case 'price-high':
                return parseFloat(b.dataset.price) - parseFloat(a.dataset.price);
            case 'name':
                return a.dataset.name.localeCompare(b.dataset.name);
            default:
                return 0;
        }
    });
    
    items.forEach(item => container.appendChild(item));
}

/**
 * Checkout Calculations
 */
function initializeCheckoutCalculations() {
    const deliveryOptions = document.querySelectorAll('input[name="delivery"]');
    
    deliveryOptions.forEach(option => {
        option.addEventListener('change', updateCheckoutTotal);
    });
}

function updateCheckoutTotal() {
    const selectedDelivery = document.querySelector('input[name="delivery"]:checked');
    if (!selectedDelivery) return;

    const deliveryFeeElement = document.getElementById('deliveryFee');
    const totalElement = document.getElementById('totalAmount');
    
    if (!deliveryFeeElement || !totalElement) return;

    let deliveryFee = 0;
    const baseTotal = parseFloat(totalElement.dataset.baseTotal) || 0;

    switch(selectedDelivery.value) {
        case 'express':
            deliveryFee = 50;
            break;
        case 'same-day':
            deliveryFee = 100;
            break;
        default:
            deliveryFee = 0;
    }

    deliveryFeeElement.textContent = deliveryFee === 0 ? 'Free' : deliveryFee + ' Birr';
    totalElement.textContent = (baseTotal + deliveryFee) + ' Birr';
}

/**
 * Utility Functions
 */
function updateCartBadge() {
    fetch('ajax/get_cart_count.php')
        .then(response => response.json())
        .then(data => {
            const badge = document.getElementById('cartBadge');
            if (badge && data.count !== undefined) {
                badge.textContent = data.count;
            }
        })
        .catch(error => console.error('Error updating cart badge:', error));
}

function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `alert alert-${type === 'error' ? 'danger' : type} alert-dismissible fade show position-fixed`;
    notification.style.cssText = 'top: 100px; right: 20px; z-index: 1050; min-width: 300px;';
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;

    document.body.appendChild(notification);

    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 5000);
}

function showFieldError(fieldId, message) {
    const field = document.getElementById(fieldId);
    if (!field) return;

    field.classList.add('is-invalid');
    
    let errorDiv = field.parentElement.querySelector('.invalid-feedback');
    if (!errorDiv) {
        errorDiv = document.createElement('div');
        errorDiv.className = 'invalid-feedback';
        field.parentElement.appendChild(errorDiv);
    }
    
    errorDiv.textContent = message;
}

function clearFieldError(fieldId) {
    const field = document.getElementById(fieldId);
    if (!field) return;

    field.classList.remove('is-invalid');
    
    const errorDiv = field.parentElement.querySelector('.invalid-feedback');
    if (errorDiv) {
        errorDiv.remove();
    }
}

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}