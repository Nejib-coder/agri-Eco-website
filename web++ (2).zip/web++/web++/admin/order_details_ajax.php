<?php
require_once '../includes/db.php';
require_once '../includes/session.php';

// Require admin access
requireAdmin();

if (!isset($_GET['id'])) {
    echo '<div class="alert alert-danger">Order ID not provided</div>';
    exit();
}

$order_id = intval($_GET['id']);

// Get order details with customer info
$order = getSingleRow($conn, "
    SELECT o.*, u.name as customer_name, u.email as customer_email, u.phone as customer_phone, u.address as customer_address
    FROM orders o 
    JOIN users u ON o.user_id = u.id 
    WHERE o.id = ?
", [$order_id], 'i');

if (!$order) {
    echo '<div class="alert alert-danger">Order not found</div>';
    exit();
}

// Get order items with product details
$order_items = getMultipleRows($conn, "
    SELECT oi.*, p.name as product_name, p.image as product_image
    FROM order_items oi
    JOIN products p ON oi.product_id = p.id
    WHERE oi.order_id = ?
", [$order_id], 'i');
?>

<div class="row">
    <div class="col-md-6">
        <h6 class="fw-bold mb-3">Order Information</h6>
        <table class="table table-sm">
            <tr>
                <td><strong>Order ID:</strong></td>
                <td>#<?php echo str_pad($order['id'], 6, '0', STR_PAD_LEFT); ?></td>
            </tr>
            <tr>
                <td><strong>Status:</strong></td>
                <td>
                    <span class="badge bg-<?php 
                        echo $order['status'] == 'pending' ? 'warning' : 
                            ($order['status'] == 'processing' ? 'info' : 
                            ($order['status'] == 'shipped' ? 'primary' : 
                            ($order['status'] == 'delivered' ? 'success' : 'danger'))); 
                    ?>">
                        <?php echo ucfirst($order['status']); ?>
                    </span>
                </td>
            </tr>
            <tr>
                <td><strong>Total:</strong></td>
                <td><?php echo number_format($order['total_price'], 2); ?> Birr</td>
            </tr>
            <tr>
                <td><strong>Payment Method:</strong></td>
                <td><?php echo ucfirst($order['payment_method']); ?></td>
            </tr>
            <tr>
                <td><strong>Payment Status:</strong></td>
                <td>
                    <span class="badge bg-<?php 
                        echo $order['payment_status'] == 'paid' ? 'success' : 
                            ($order['payment_status'] == 'failed' ? 'danger' : 'warning'); 
                    ?>">
                        <?php echo ucfirst($order['payment_status']); ?>
                    </span>
                    <?php if ($order['payment_status'] == 'paid' && $order['payment_date']): ?>
                    <br><small class="text-muted">Paid: <?php echo date('M d, Y H:i', strtotime($order['payment_date'])); ?></small>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td><strong>Delivery Type:</strong></td>
                <td><?php echo ucfirst(str_replace('-', ' ', $order['delivery_type'])); ?></td>
            </tr>
            <tr>
                <td><strong>Order Date:</strong></td>
                <td><?php echo date('M d, Y H:i', strtotime($order['created_at'])); ?></td>
            </tr>
        </table>
    </div>
    
    <div class="col-md-6">
        <h6 class="fw-bold mb-3">Customer Information</h6>
        <table class="table table-sm">
            <tr>
                <td><strong>Name:</strong></td>
                <td><?php echo htmlspecialchars($order['customer_name']); ?></td>
            </tr>
            <tr>
                <td><strong>Email:</strong></td>
                <td><?php echo htmlspecialchars($order['customer_email']); ?></td>
            </tr>
            <tr>
                <td><strong>Phone:</strong></td>
                <td><?php echo htmlspecialchars($order['phone'] ?? $order['customer_phone'] ?? 'N/A'); ?></td>
            </tr>
            <tr>
                <td><strong>Shipping Address:</strong></td>
                <td><?php echo nl2br(htmlspecialchars($order['shipping_address'])); ?></td>
            </tr>
        </table>
    </div>
</div>

<hr>

<h6 class="fw-bold mb-3">Order Items</h6>
<div class="table-responsive">
    <table class="table table-sm">
        <thead class="table-light">
            <tr>
                <th>Product</th>
                <th>Image</th>
                <th>Quantity</th>
                <th>Unit Price</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($order_items as $item): ?>
            <tr>
                <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                <td>
                    <img src="../<?php echo htmlspecialchars($item['product_image']); ?>" 
                         class="rounded" style="width: 40px; height: 40px; object-fit: cover;" 
                         alt="<?php echo htmlspecialchars($item['product_name']); ?>">
                </td>
                <td><?php echo $item['quantity']; ?></td>
                <td><?php echo number_format($item['price'], 2); ?> Birr</td>
                <td><?php echo number_format($item['price'] * $item['quantity'], 2); ?> Birr</td>
            </tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot class="table-light">
            <tr>
                <th colspan="4" class="text-end">Total:</th>
                <th><?php echo number_format($order['total_price'], 2); ?> Birr</th>
            </tr>
        </tfoot>
    </table>
</div>