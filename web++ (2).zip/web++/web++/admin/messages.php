<?php
require_once '../includes/db.php';
require_once '../includes/session.php';

// Require admin access
requireAdmin();

$page_title = 'Message Management';
$css_path = '../assets/css/styles.css';
$js_path = '../assets/js/main.js';
$base_url = '../public/';

// Handle message actions
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] == 'mark_read') {
        $message_id = intval($_POST['message_id']);
        executeQuery($conn, "UPDATE messages SET status = 'read' WHERE id = ?", [$message_id], 'i');
        setFlashMessage('success', 'Message marked as read!');
    } elseif ($_POST['action'] == 'mark_replied') {
        $message_id = intval($_POST['message_id']);
        executeQuery($conn, "UPDATE messages SET status = 'replied' WHERE id = ?", [$message_id], 'i');
        setFlashMessage('success', 'Message marked as replied!');
    } elseif ($_POST['action'] == 'delete') {
        $message_id = intval($_POST['message_id']);
        executeQuery($conn, "DELETE FROM messages WHERE id = ?", [$message_id], 'i');
        setFlashMessage('success', 'Message deleted successfully!');
    }
    header('Location: messages.php');
    exit();
}

// Get filter parameters
$status_filter = isset($_GET['status']) ? sanitizeInput($_GET['status']) : '';
$search = isset($_GET['search']) ? sanitizeInput($_GET['search']) : '';

// Build query with filters
$where_conditions = [];
$params = [];
$types = '';

if (!empty($status_filter)) {
    $where_conditions[] = "status = ?";
    $params[] = $status_filter;
    $types .= 's';
}

if (!empty($search)) {
    $where_conditions[] = "(name LIKE ? OR email LIKE ? OR subject LIKE ? OR message LIKE ?)";
    $search_param = "%$search%";
    $params = array_merge($params, [$search_param, $search_param, $search_param, $search_param]);
    $types .= 'ssss';
}

$where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

// Get messages
$messages = getMultipleRows($conn, "
    SELECT * FROM messages 
    $where_clause
    ORDER BY created_at DESC
", $params, $types);

// Get message statistics
$total_messages = getSingleRow($conn, "SELECT COUNT(*) as count FROM messages")['count'];
$unread_messages = getSingleRow($conn, "SELECT COUNT(*) as count FROM messages WHERE status = 'unread'")['count'];
$read_messages = getSingleRow($conn, "SELECT COUNT(*) as count FROM messages WHERE status = 'read'")['count'];
$replied_messages = getSingleRow($conn, "SELECT COUNT(*) as count FROM messages WHERE status = 'replied'")['count'];

include '../includes/header.php';
?>

<!-- Admin Header -->
<section class="bg-success text-white py-4 mt-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <h1 class="h2 fw-bold mb-2">Message Management</h1>
                <p class="mb-0">Manage customer inquiries and feedback</p>
            </div>
            <div class="col-lg-4 text-lg-end">
                <a href="dashboard.php" class="btn btn-outline-light">
                    <i class="bi bi-arrow-left"></i> Dashboard
                </a>
            </div>
        </div>
    </div>
</section>

<!-- Flash Messages -->
<?php 
$flash = getFlashMessage();
if ($flash): 
?>
<div class="container mt-3">
    <div class="alert alert-<?php echo $flash['type'] == 'success' ? 'success' : 'danger'; ?> alert-dismissible fade show">
        <?php echo htmlspecialchars($flash['message']); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
</div>
<?php endif; ?>

<!-- Message Statistics -->
<section class="py-4">
    <div class="container">
        <div class="row g-3">
            <div class="col-lg-3 col-md-6">
                <div class="card border-0 shadow-sm">
                    <div class="card-body text-center">
                        <h3 class="text-primary mb-1"><?php echo $total_messages; ?></h3>
                        <p class="text-muted mb-0">Total Messages</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="card border-0 shadow-sm">
                    <div class="card-body text-center">
                        <h3 class="text-danger mb-1"><?php echo $unread_messages; ?></h3>
                        <p class="text-muted mb-0">Unread</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="card border-0 shadow-sm">
                    <div class="card-body text-center">
                        <h3 class="text-warning mb-1"><?php echo $read_messages; ?></h3>
                        <p class="text-muted mb-0">Read</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="card border-0 shadow-sm">
                    <div class="card-body text-center">
                        <h3 class="text-success mb-1"><?php echo $replied_messages; ?></h3>
                        <p class="text-muted mb-0">Replied</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Filters and Search -->
<section class="py-3">
    <div class="container">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <form method="GET" class="row g-3 align-items-end">
                    <div class="col-md-4">
                        <label class="form-label">Filter by Status</label>
                        <select name="status" class="form-select">
                            <option value="">All Messages</option>
                            <option value="unread" <?php echo $status_filter == 'unread' ? 'selected' : ''; ?>>Unread</option>
                            <option value="read" <?php echo $status_filter == 'read' ? 'selected' : ''; ?>>Read</option>
                            <option value="replied" <?php echo $status_filter == 'replied' ? 'selected' : ''; ?>>Replied</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Search Messages</label>
                        <input type="text" name="search" class="form-control" placeholder="Search by name, email, subject, or message content" value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-success w-100">
                            <i class="bi bi-search"></i> Filter
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- Messages List -->
<section class="pb-5">
    <div class="container">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-light">
                <h5 class="mb-0">Messages (<?php echo count($messages); ?>)</h5>
            </div>
            <div class="card-body p-0">
                <?php if (empty($messages)): ?>
                <div class="p-5 text-center text-muted">
                    <i class="bi bi-chat display-4 mb-3"></i>
                    <h5>No messages found</h5>
                    <p>No messages match your current filters</p>
                </div>
                <?php else: ?>
                <div class="list-group list-group-flush">
                    <?php foreach ($messages as $message): ?>
                    <div class="list-group-item <?php echo $message['status'] == 'unread' ? 'bg-light' : ''; ?>">
                        <div class="row align-items-start">
                            <div class="col-md-8">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <div>
                                        <h6 class="mb-1 <?php echo $message['status'] == 'unread' ? 'fw-bold' : ''; ?>">
                                            <?php echo htmlspecialchars($message['name']); ?>
                                            <small class="text-muted">- <?php echo htmlspecialchars($message['email']); ?></small>
                                        </h6>
                                        <?php if (!empty($message['subject'])): ?>
                                        <p class="mb-1 text-primary small">
                                            <strong>Subject:</strong> <?php echo htmlspecialchars($message['subject']); ?>
                                        </p>
                                        <?php endif; ?>
                                    </div>
                                    <span class="badge bg-<?php 
                                        echo $message['status'] == 'unread' ? 'danger' : 
                                            ($message['status'] == 'read' ? 'warning' : 'success'); 
                                    ?>">
                                        <?php echo ucfirst($message['status']); ?>
                                    </span>
                                </div>
                                <p class="mb-2 text-muted">
                                    <?php echo nl2br(htmlspecialchars(substr($message['message'], 0, 200))); ?>
                                    <?php if (strlen($message['message']) > 200): ?>
                                    <span class="text-primary" style="cursor: pointer;" onclick="showFullMessage(<?php echo $message['id']; ?>)">... Read more</span>
                                    <?php endif; ?>
                                </p>
                                <small class="text-muted">
                                    <i class="bi bi-clock"></i> <?php echo date('M d, Y H:i', strtotime($message['created_at'])); ?>
                                </small>
                            </div>
                            <div class="col-md-4 text-end">
                                <div class="btn-group btn-group-sm mb-2">
                                    <?php if ($message['status'] == 'unread'): ?>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="action" value="mark_read">
                                        <input type="hidden" name="message_id" value="<?php echo $message['id']; ?>">
                                        <button type="submit" class="btn btn-outline-warning" title="Mark as Read">
                                            <i class="bi bi-eye"></i>
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                    
                                    <?php if ($message['status'] != 'replied'): ?>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="action" value="mark_replied">
                                        <input type="hidden" name="message_id" value="<?php echo $message['id']; ?>">
                                        <button type="submit" class="btn btn-outline-success" title="Mark as Replied">
                                            <i class="bi bi-reply"></i>
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                    
                                    <button class="btn btn-outline-primary" onclick="showFullMessage(<?php echo $message['id']; ?>)" title="View Full Message">
                                        <i class="bi bi-eye-fill"></i>
                                    </button>
                                    
                                    <button class="btn btn-outline-danger" onclick="deleteMessage(<?php echo $message['id']; ?>, '<?php echo htmlspecialchars($message['name']); ?>')" title="Delete Message">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </div>
                                <div>
                                    <a href="mailto:<?php echo htmlspecialchars($message['email']); ?>?subject=Re: <?php echo htmlspecialchars($message['subject'] ?? 'Your inquiry'); ?>" 
                                       class="btn btn-sm btn-success">
                                        <i class="bi bi-envelope"></i> Reply via Email
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<!-- Full Message Modal -->
<div class="modal fade" id="fullMessageModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Message Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="fullMessageContent">
                <div class="text-center">
                    <div class="spinner-border text-success" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteMessageModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirm Delete</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete the message from <strong id="deleteMessageName"></strong>?</p>
                <p class="text-danger small">This action cannot be undone.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <form method="POST" style="display: inline;">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="message_id" id="deleteMessageId">
                    <button type="submit" class="btn btn-danger">Delete Message</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function showFullMessage(messageId) {
    const modal = new bootstrap.Modal(document.getElementById('fullMessageModal'));
    const content = document.getElementById('fullMessageContent');
    
    // Show loading
    content.innerHTML = `
        <div class="text-center">
            <div class="spinner-border text-success" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
    `;
    
    modal.show();
    
    // Fetch message details
    fetch(`message_details_ajax.php?id=${messageId}`)
        .then(response => response.text())
        .then(html => {
            content.innerHTML = html;
        })
        .catch(error => {
            content.innerHTML = `
                <div class="alert alert-danger">
                    <i class="bi bi-exclamation-triangle"></i>
                    Error loading message details. Please try again.
                </div>
            `;
        });
}

function deleteMessage(id, name) {
    document.getElementById('deleteMessageId').value = id;
    document.getElementById('deleteMessageName').textContent = name;
    
    new bootstrap.Modal(document.getElementById('deleteMessageModal')).show();
}
</script>

<?php include '../includes/footer.php'; ?>