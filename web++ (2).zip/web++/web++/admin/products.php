<?php
require_once '../includes/db.php';
require_once '../includes/session.php';

// Require admin access
requireAdmin();

$page_title = 'Product Management';
$css_path = '../assets/css/styles.css';
$js_path = '../assets/js/main.js';
$base_url = '../public/';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $name = sanitizeInput($_POST['name']);
                $price = floatval($_POST['price']);
                $description = sanitizeInput($_POST['description']);
                $category_id = intval($_POST['category_id']);
                $farmer_name = sanitizeInput($_POST['farmer_name']);
                $stock_quantity = intval($_POST['stock_quantity']);
                $image = sanitizeInput($_POST['image']);
                
                // Enhanced validation
                $errors = [];
                
                if (empty($name) || strlen($name) < 3) {
                    $errors[] = 'Product name must be at least 3 characters';
                }
                
                if ($price <= 0) {
                    $errors[] = 'Price must be greater than 0';
                }
                
                if ($category_id <= 0) {
                    $errors[] = 'Please select a valid category';
                }
                
                if ($stock_quantity < 0) {
                    $errors[] = 'Stock quantity cannot be negative';
                }
                
                if (!empty($image)) {
                    $valid_extensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp'];
                    $has_valid_extension = false;
                    foreach ($valid_extensions as $ext) {
                        if (stripos($image, $ext) !== false) {
                            $has_valid_extension = true;
                            break;
                        }
                    }
                    if (!$has_valid_extension) {
                        $errors[] = 'Image must have a valid extension (.jpg, .png, .gif, .webp)';
                    }
                }
                
                if (empty($errors)) {
                    $sql = "INSERT INTO products (name, price, description, image, category_id, farmer_name, stock_quantity) VALUES (?, ?, ?, ?, ?, ?, ?)";
                    executeQuery($conn, $sql, [$name, $price, $description, $image, $category_id, $farmer_name, $stock_quantity], 'sdsisis');
                    setFlashMessage('success', 'Product added successfully!');
                } else {
                    setFlashMessage('error', implode('<br>', $errors));
                }
                break;
                
            case 'update':
                $id = intval($_POST['id']);
                $name = sanitizeInput($_POST['name']);
                $price = floatval($_POST['price']);
                $description = sanitizeInput($_POST['description']);
                $category_id = intval($_POST['category_id']);
                $farmer_name = sanitizeInput($_POST['farmer_name']);
                $stock_quantity = intval($_POST['stock_quantity']);
                $status = sanitizeInput($_POST['status']);
                $image = sanitizeInput($_POST['image']);
                
                $sql = "UPDATE products SET name=?, price=?, description=?, image=?, category_id=?, farmer_name=?, stock_quantity=?, status=? WHERE id=?";
                executeQuery($conn, $sql, [$name, $price, $description, $image, $category_id, $farmer_name, $stock_quantity, $status, $id], 'sdsisissi');
                setFlashMessage('success', 'Product updated successfully!');
                break;
                
            case 'delete':
                $id = intval($_POST['id']);
                executeQuery($conn, "DELETE FROM products WHERE id=?", [$id], 'i');
                setFlashMessage('success', 'Product deleted successfully!');
                break;
        }
        header('Location: products.php');
        exit();
    }
}

// Get all products with category names
$products = getMultipleRows($conn, "
    SELECT p.*, c.name as category_name 
    FROM products p 
    LEFT JOIN categories c ON p.category_id = c.id 
    ORDER BY p.created_at DESC
");

// Get all categories for dropdown
$categories = getMultipleRows($conn, "SELECT * FROM categories ORDER BY name");

include '../includes/header.php';
?>

<!-- Admin Header -->
<section class="bg-success text-white py-4 mt-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <h1 class="h2 fw-bold mb-2">Product Management</h1>
                <p class="mb-0">Manage your product catalog</p>
            </div>
            <div class="col-lg-4 text-lg-end">
                <div class="d-flex gap-2 justify-content-lg-end flex-wrap">
                    <a href="dashboard.php" class="btn btn-outline-light">
                        <i class="bi bi-arrow-left"></i> Dashboard
                    </a>
                    <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#addProductModal">
                        <i class="bi bi-plus-circle"></i> Add Product
                    </button>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Flash Messages -->
<?php 
$flash = getFlashMessage();
if ($flash): 
?>
<div class="container mt-3">
    <div class="alert alert-<?php echo $flash['type'] == 'success' ? 'success' : 'danger'; ?> alert-dismissible fade show">
        <?php echo htmlspecialchars($flash['message']); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
</div>
<?php endif; ?>

<!-- Products Table -->
<section class="py-5">
    <div class="container">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-light">
                <h5 class="mb-0">All Products (<?php echo count($products); ?>)</h5>
            </div>
            <div class="card-body p-0">
                <?php if (empty($products)): ?>
                <div class="p-5 text-center text-muted">
                    <i class="bi bi-box-seam display-4 mb-3"></i>
                    <h5>No products found</h5>
                    <p>Start by adding your first product</p>
                    <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addProductModal">
                        <i class="bi bi-plus-circle"></i> Add Product
                    </button>
                </div>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Image</th>
                                <th>Product</th>
                                <th>Category</th>
                                <th>Price</th>
                                <th>Stock</th>
                                <th>Status</th>
                                <th>Farmer</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($products as $product): ?>
                            <tr>
                                <td>
                                    <img src="../<?php echo htmlspecialchars($product['image']); ?>" 
                                         class="rounded" style="width: 50px; height: 50px; object-fit: cover;" 
                                         alt="<?php echo htmlspecialchars($product['name']); ?>">
                                </td>
                                <td>
                                    <h6 class="mb-0"><?php echo htmlspecialchars($product['name']); ?></h6>
                                    <small class="text-muted"><?php echo htmlspecialchars(substr($product['description'], 0, 50)) . '...'; ?></small>
                                </td>
                                <td>
                                    <span class="badge bg-secondary"><?php echo htmlspecialchars($product['category_name'] ?? 'No Category'); ?></span>
                                </td>
                                <td><strong><?php echo number_format($product['price'], 2); ?> Birr</strong></td>
                                <td>
                                    <span class="badge bg-<?php echo $product['stock_quantity'] <= 10 ? 'danger' : 'success'; ?>">
                                        <?php echo $product['stock_quantity']; ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="badge bg-<?php echo $product['status'] == 'active' ? 'success' : 'secondary'; ?>">
                                        <?php echo ucfirst($product['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($product['farmer_name']); ?></td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <button class="btn btn-outline-primary" onclick="editProduct(<?php echo htmlspecialchars(json_encode($product)); ?>)">
                                            <i class="bi bi-pencil"></i>
                                        </button>
                                        <button class="btn btn-outline-danger" onclick="deleteProduct(<?php echo $product['id']; ?>, '<?php echo htmlspecialchars($product['name']); ?>')">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<!-- Add Product Modal -->
<div class="modal fade" id="addProductModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Product</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" id="addProductForm">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Product Name *</label>
                            <input type="text" class="form-control" name="name" id="name" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Price (Birr) *</label>
                            <input type="number" class="form-control" name="price" id="price" step="0.01" min="0" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Category *</label>
                            <select class="form-select" name="category_id" id="category_id" required>
                                <option value="">Select Category</option>
                                <?php foreach ($categories as $category): ?>
                                <option value="<?php echo $category['id']; ?>"><?php echo htmlspecialchars($category['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Stock Quantity *</label>
                            <input type="number" class="form-control" name="stock_quantity" id="stock_quantity" min="0" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Farmer Name</label>
                            <input type="text" class="form-control" name="farmer_name" id="farmer_name">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Image Path</label>
                            <input type="text" class="form-control" name="image" id="image" placeholder="assets/images/product.jpg">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Description</label>
                            <textarea class="form-control" name="description" id="description" rows="3"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success">Add Product</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Product Modal -->
<div class="modal fade" id="editProductModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Product</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" id="editProductForm">
                <div class="modal-body">
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="id" id="edit_id">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Product Name *</label>
                            <input type="text" class="form-control" name="name" id="edit_name" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Price (Birr) *</label>
                            <input type="number" class="form-control" name="price" id="edit_price" step="0.01" min="0" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Category *</label>
                            <select class="form-select" name="category_id" id="edit_category_id" required>
                                <option value="">Select Category</option>
                                <?php foreach ($categories as $category): ?>
                                <option value="<?php echo $category['id']; ?>"><?php echo htmlspecialchars($category['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Stock Quantity *</label>
                            <input type="number" class="form-control" name="stock_quantity" id="edit_stock_quantity" min="0" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Farmer Name</label>
                            <input type="text" class="form-control" name="farmer_name" id="edit_farmer_name">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Status</label>
                            <select class="form-select" name="status" id="edit_status">
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Image Path</label>
                            <input type="text" class="form-control" name="image" id="edit_image">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Description</label>
                            <textarea class="form-control" name="description" id="edit_description" rows="3"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update Product</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteProductModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirm Delete</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete <strong id="deleteProductName"></strong>?</p>
                <p class="text-danger small">This action cannot be undone.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <form method="POST" style="display: inline;">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" id="deleteProductId">
                    <button type="submit" class="btn btn-danger">Delete Product</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function editProduct(product) {
    document.getElementById('edit_id').value = product.id;
    document.getElementById('edit_name').value = product.name;
    document.getElementById('edit_price').value = product.price;
    document.getElementById('edit_category_id').value = product.category_id;
    document.getElementById('edit_stock_quantity').value = product.stock_quantity;
    document.getElementById('edit_farmer_name').value = product.farmer_name;
    document.getElementById('edit_status').value = product.status;
    document.getElementById('edit_image').value = product.image;
    document.getElementById('edit_description').value = product.description;
    
    new bootstrap.Modal(document.getElementById('editProductModal')).show();
}

function deleteProduct(id, name) {
    document.getElementById('deleteProductId').value = id;
    document.getElementById('deleteProductName').textContent = name;
    
    new bootstrap.Modal(document.getElementById('deleteProductModal')).show();
}
</script>

<?php include '../includes/footer.php'; ?>