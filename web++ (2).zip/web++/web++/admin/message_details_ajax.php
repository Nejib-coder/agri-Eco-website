<?php
require_once '../includes/db.php';
require_once '../includes/session.php';

// Require admin access
requireAdmin();

if (!isset($_GET['id'])) {
    echo '<div class="alert alert-danger">Message ID not provided</div>';
    exit();
}

$message_id = intval($_GET['id']);

// Get message details
$message = getSingleRow($conn, "SELECT * FROM messages WHERE id = ?", [$message_id], 'i');

if (!$message) {
    echo '<div class="alert alert-danger">Message not found</div>';
    exit();
}
?>

<div class="row">
    <div class="col-md-6">
        <h6 class="fw-bold mb-3">Contact Information</h6>
        <table class="table table-sm">
            <tr>
                <td><strong>Name:</strong></td>
                <td><?php echo htmlspecialchars($message['name']); ?></td>
            </tr>
            <tr>
                <td><strong>Email:</strong></td>
                <td>
                    <a href="mailto:<?php echo htmlspecialchars($message['email']); ?>">
                        <?php echo htmlspecialchars($message['email']); ?>
                    </a>
                </td>
            </tr>
            <?php if (!empty($message['subject'])): ?>
            <tr>
                <td><strong>Subject:</strong></td>
                <td><?php echo htmlspecialchars($message['subject']); ?></td>
            </tr>
            <?php endif; ?>
            <tr>
                <td><strong>Status:</strong></td>
                <td>
                    <span class="badge bg-<?php 
                        echo $message['status'] == 'unread' ? 'danger' : 
                            ($message['status'] == 'read' ? 'warning' : 'success'); 
                    ?>">
                        <?php echo ucfirst($message['status']); ?>
                    </span>
                </td>
            </tr>
            <tr>
                <td><strong>Received:</strong></td>
                <td><?php echo date('M d, Y H:i', strtotime($message['created_at'])); ?></td>
            </tr>
        </table>
    </div>
    
    <div class="col-md-6">
        <h6 class="fw-bold mb-3">Quick Actions</h6>
        <div class="d-grid gap-2">
            <a href="mailto:<?php echo htmlspecialchars($message['email']); ?>?subject=Re: <?php echo htmlspecialchars($message['subject'] ?? 'Your inquiry'); ?>" 
               class="btn btn-success">
                <i class="bi bi-envelope"></i> Reply via Email
            </a>
            
            <?php if ($message['status'] != 'replied'): ?>
            <form method="POST" action="messages.php">
                <input type="hidden" name="action" value="mark_replied">
                <input type="hidden" name="message_id" value="<?php echo $message['id']; ?>">
                <button type="submit" class="btn btn-outline-success w-100">
                    <i class="bi bi-check-circle"></i> Mark as Replied
                </button>
            </form>
            <?php endif; ?>
            
            <?php if ($message['status'] == 'unread'): ?>
            <form method="POST" action="messages.php">
                <input type="hidden" name="action" value="mark_read">
                <input type="hidden" name="message_id" value="<?php echo $message['id']; ?>">
                <button type="submit" class="btn btn-outline-warning w-100">
                    <i class="bi bi-eye"></i> Mark as Read
                </button>
            </form>
            <?php endif; ?>
        </div>
    </div>
</div>

<hr>

<h6 class="fw-bold mb-3">Message Content</h6>
<div class="card bg-light">
    <div class="card-body">
        <p class="mb-0" style="white-space: pre-wrap;"><?php echo htmlspecialchars($message['message']); ?></p>
    </div>
</div>