<?php
require_once '../includes/db.php';
require_once '../includes/session.php';

// Require admin access
requireAdmin();

$page_title = 'Order Management';
$css_path = '../assets/css/styles.css';
$js_path = '../assets/js/main.js';
$base_url = '../public/';

// Handle status updates
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] == 'update_status') {
        $order_id = intval($_POST['order_id']);
        $status = sanitizeInput($_POST['status']);
        
        executeQuery($conn, "UPDATE orders SET status = ? WHERE id = ?", [$status, $order_id], 'si');
        setFlashMessage('success', 'Order status updated successfully!');
        header('Location: orders.php');
        exit();
    } elseif ($_POST['action'] == 'confirm_payment') {
        $order_id = intval($_POST['order_id']);
        
        executeQuery($conn, "UPDATE orders SET payment_status = 'paid', payment_date = NOW() WHERE id = ?", [$order_id], 'i');
        setFlashMessage('success', 'Payment confirmed successfully!');
        header('Location: orders.php');
        exit();
    } elseif ($_POST['action'] == 'reject_payment') {
        $order_id = intval($_POST['order_id']);
        
        executeQuery($conn, "UPDATE orders SET payment_status = 'failed' WHERE id = ?", [$order_id], 'i');
        setFlashMessage('success', 'Payment marked as failed!');
        header('Location: orders.php');
        exit();
    }
}

// Get filter parameters
$status_filter = isset($_GET['status']) ? sanitizeInput($_GET['status']) : '';
$search = isset($_GET['search']) ? sanitizeInput($_GET['search']) : '';

// Build query with filters
$where_conditions = [];
$params = [];
$types = '';

if (!empty($status_filter)) {
    $where_conditions[] = "o.status = ?";
    $params[] = $status_filter;
    $types .= 's';
}

if (!empty($search)) {
    $where_conditions[] = "(u.name LIKE ? OR u.email LIKE ? OR o.id LIKE ?)";
    $search_param = "%$search%";
    $params = array_merge($params, [$search_param, $search_param, $search_param]);
    $types .= 'sss';
}

$where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

// Get orders with customer information
$orders = getMultipleRows($conn, "
    SELECT o.*, u.name as customer_name, u.email as customer_email, u.phone as customer_phone
    FROM orders o 
    JOIN users u ON o.user_id = u.id 
    $where_clause
    ORDER BY o.created_at DESC
", $params, $types);

// Get order statistics
$total_orders = getSingleRow($conn, "SELECT COUNT(*) as count FROM orders")['count'];
$pending_orders = getSingleRow($conn, "SELECT COUNT(*) as count FROM orders WHERE status = 'pending'")['count'];
$processing_orders = getSingleRow($conn, "SELECT COUNT(*) as count FROM orders WHERE status = 'processing'")['count'];
$delivered_orders = getSingleRow($conn, "SELECT COUNT(*) as count FROM orders WHERE status = 'delivered'")['count'];

include '../includes/header.php';
?>

<!-- Admin Header -->
<section class="bg-success text-white py-4 mt-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <h1 class="h2 fw-bold mb-2">Order Management</h1>
                <p class="mb-0">Track and manage customer orders</p>
            </div>
            <div class="col-lg-4 text-lg-end">
                <a href="dashboard.php" class="btn btn-outline-light">
                    <i class="bi bi-arrow-left"></i> Dashboard
                </a>
            </div>
        </div>
    </div>
</section>

<!-- Flash Messages -->
<?php 
$flash = getFlashMessage();
if ($flash): 
?>
<div class="container mt-3">
    <div class="alert alert-<?php echo $flash['type'] == 'success' ? 'success' : 'danger'; ?> alert-dismissible fade show">
        <?php echo htmlspecialchars($flash['message']); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
</div>
<?php endif; ?>

<!-- Order Statistics -->
<section class="py-4">
    <div class="container">
        <div class="row g-3">
            <div class="col-lg-3 col-md-6">
                <div class="card border-0 shadow-sm">
                    <div class="card-body text-center">
                        <h3 class="text-primary mb-1"><?php echo $total_orders; ?></h3>
                        <p class="text-muted mb-0">Total Orders</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="card border-0 shadow-sm">
                    <div class="card-body text-center">
                        <h3 class="text-warning mb-1"><?php echo $pending_orders; ?></h3>
                        <p class="text-muted mb-0">Pending</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="card border-0 shadow-sm">
                    <div class="card-body text-center">
                        <h3 class="text-info mb-1"><?php echo $processing_orders; ?></h3>
                        <p class="text-muted mb-0">Processing</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="card border-0 shadow-sm">
                    <div class="card-body text-center">
                        <h3 class="text-success mb-1"><?php echo $delivered_orders; ?></h3>
                        <p class="text-muted mb-0">Delivered</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Filters and Search -->
<section class="py-3">
    <div class="container">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <form method="GET" class="row g-3 align-items-end">
                    <div class="col-md-4">
                        <label class="form-label">Filter by Status</label>
                        <select name="status" class="form-select">
                            <option value="">All Orders</option>
                            <option value="pending" <?php echo $status_filter == 'pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="processing" <?php echo $status_filter == 'processing' ? 'selected' : ''; ?>>Processing</option>
                            <option value="shipped" <?php echo $status_filter == 'shipped' ? 'selected' : ''; ?>>Shipped</option>
                            <option value="delivered" <?php echo $status_filter == 'delivered' ? 'selected' : ''; ?>>Delivered</option>
                            <option value="cancelled" <?php echo $status_filter == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Search Orders</label>
                        <input type="text" name="search" class="form-control" placeholder="Search by customer name, email, or order ID" value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-success w-100">
                            <i class="bi bi-search"></i> Filter
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- Orders Table -->
<section class="pb-5">
    <div class="container">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-light">
                <h5 class="mb-0">Orders (<?php echo count($orders); ?>)</h5>
            </div>
            <div class="card-body p-0">
                <?php if (empty($orders)): ?>
                <div class="p-5 text-center text-muted">
                    <i class="bi bi-inbox display-4 mb-3"></i>
                    <h5>No orders found</h5>
                    <p>No orders match your current filters</p>
                </div>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Order ID</th>
                                <th>Customer</th>
                                <th>Contact</th>
                                <th>Total</th>
                                <th>Status</th>
                                <th>Payment</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($orders as $order): ?>
                            <tr>
                                <td><strong>#<?php echo str_pad($order['id'], 6, '0', STR_PAD_LEFT); ?></strong></td>
                                <td>
                                    <h6 class="mb-0"><?php echo htmlspecialchars($order['customer_name']); ?></h6>
                                    <small class="text-muted"><?php echo htmlspecialchars($order['customer_email']); ?></small>
                                </td>
                                <td>
                                    <small><?php echo htmlspecialchars($order['phone'] ?? $order['customer_phone'] ?? 'N/A'); ?></small>
                                </td>
                                <td><strong><?php echo number_format($order['total_price'], 2); ?> Birr</strong></td>
                                <td>
                                    <span class="badge bg-<?php 
                                        echo $order['status'] == 'pending' ? 'warning' : 
                                            ($order['status'] == 'processing' ? 'info' : 
                                            ($order['status'] == 'shipped' ? 'primary' : 
                                            ($order['status'] == 'delivered' ? 'success' : 'danger'))); 
                                    ?>">
                                        <?php echo ucfirst($order['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="badge bg-secondary"><?php echo ucfirst($order['payment_method']); ?></span><br>
                                    <span class="badge bg-<?php 
                                        echo $order['payment_status'] == 'paid' ? 'success' : 
                                            ($order['payment_status'] == 'failed' ? 'danger' : 'warning'); 
                                    ?> mt-1">
                                        <?php echo ucfirst($order['payment_status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <small><?php echo date('M d, Y', strtotime($order['created_at'])); ?></small><br>
                                    <small class="text-muted"><?php echo date('H:i', strtotime($order['created_at'])); ?></small>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <button class="btn btn-outline-primary" onclick="viewOrder(<?php echo $order['id']; ?>)">
                                            <i class="bi bi-eye"></i>
                                        </button>
                                        <button class="btn btn-outline-success" onclick="updateStatus(<?php echo $order['id']; ?>, '<?php echo $order['status']; ?>')">
                                            <i class="bi bi-arrow-repeat"></i>
                                        </button>
                                        <?php if ($order['payment_status'] == 'unpaid' && $order['payment_method'] != 'cash'): ?>
                                        <button class="btn btn-outline-warning" onclick="confirmPayment(<?php echo $order['id']; ?>)">
                                            <i class="bi bi-check-circle"></i>
                                        </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<!-- Order Details Modal -->
<div class="modal fade" id="orderDetailsModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Order Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="orderDetailsContent">
                <div class="text-center">
                    <div class="spinner-border text-success" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Update Status Modal -->
<div class="modal fade" id="updateStatusModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Update Order Status</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="update_status">
                    <input type="hidden" name="order_id" id="statusOrderId">
                    
                    <div class="mb-3">
                        <label class="form-label">Current Status: <span id="currentStatus" class="badge"></span></label>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">New Status</label>
                        <select name="status" class="form-select" id="newStatus" required>
                            <option value="pending">Pending</option>
                            <option value="processing">Processing</option>
                            <option value="shipped">Shipped</option>
                            <option value="delivered">Delivered</option>
                            <option value="cancelled">Cancelled</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success">Update Status</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Confirm Payment Modal -->
<div class="modal fade" id="confirmPaymentModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirm Payment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="confirm_payment">
                    <input type="hidden" name="order_id" id="paymentOrderId">
                    
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle"></i> 
                        Are you sure you want to confirm payment for this order?
                    </div>
                    
                    <p class="mb-0">This will mark the order as <strong class="text-success">PAID</strong> and the order can proceed to processing.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success">Confirm Payment</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function viewOrder(orderId) {
    const modal = new bootstrap.Modal(document.getElementById('orderDetailsModal'));
    const content = document.getElementById('orderDetailsContent');
    
    // Show loading
    content.innerHTML = `
        <div class="text-center">
            <div class="spinner-border text-success" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
    `;
    
    modal.show();
    
    // Fetch order details
    fetch(`order_details_ajax.php?id=${orderId}`)
        .then(response => response.text())
        .then(html => {
            content.innerHTML = html;
        })
        .catch(error => {
            content.innerHTML = `
                <div class="alert alert-danger">
                    <i class="bi bi-exclamation-triangle"></i>
                    Error loading order details. Please try again.
                </div>
            `;
        });
}

function updateStatus(orderId, currentStatus) {
    document.getElementById('statusOrderId').value = orderId;
    document.getElementById('currentStatus').textContent = currentStatus.charAt(0).toUpperCase() + currentStatus.slice(1);
    document.getElementById('currentStatus').className = `badge bg-${getStatusColor(currentStatus)}`;
    document.getElementById('newStatus').value = currentStatus;
    
    new bootstrap.Modal(document.getElementById('updateStatusModal')).show();
}

function confirmPayment(orderId) {
    document.getElementById('paymentOrderId').value = orderId;
    new bootstrap.Modal(document.getElementById('confirmPaymentModal')).show();
}

function getStatusColor(status) {
    switch(status) {
        case 'pending': return 'warning';
        case 'processing': return 'info';
        case 'shipped': return 'primary';
        case 'delivered': return 'success';
        case 'cancelled': return 'danger';
        default: return 'secondary';
    }
}
</script>

<?php include '../includes/footer.php'; ?>