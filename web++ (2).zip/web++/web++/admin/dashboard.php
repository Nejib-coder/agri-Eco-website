<?php
require_once '../includes/db.php';
require_once '../includes/session.php';

// Require admin access
requireAdmin();

$page_title = 'Admin Dashboard';
$css_path = '../assets/css/styles.css';
$js_path = '../assets/js/main.js';
$base_url = '../public/';

// Get dashboard statistics
$total_products = getSingleRow($conn, "SELECT COUNT(*) as count FROM products")['count'];
$active_products = getSingleRow($conn, "SELECT COUNT(*) as count FROM products WHERE status = 'active'")['count'];
$total_orders = getSingleRow($conn, "SELECT COUNT(*) as count FROM orders")['count'];
$pending_orders = getSingleRow($conn, "SELECT COUNT(*) as count FROM orders WHERE status = 'pending'")['count'];
$total_customers = getSingleRow($conn, "SELECT COUNT(*) as count FROM users WHERE role = 'customer'")['count'];
$total_revenue = getSingleRow($conn, "SELECT COALESCE(SUM(total_price), 0) as total FROM orders WHERE status != 'cancelled'")['total'];
$unread_messages = getSingleRow($conn, "SELECT COUNT(*) as count FROM messages WHERE status = 'unread'")['count'];

// Get recent orders
$recent_orders = getMultipleRows($conn, "SELECT o.*, u.name as customer_name FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC LIMIT 5");

// Get low stock products
$low_stock_products = getMultipleRows($conn, "SELECT * FROM products WHERE stock_quantity <= 10 AND status = 'active' ORDER BY stock_quantity ASC LIMIT 5");

// Get recent messages
$recent_messages = getMultipleRows($conn, "SELECT * FROM messages ORDER BY created_at DESC LIMIT 5");

include '../includes/header.php';
?>

<!-- Admin Header -->
<section class="bg-success text-white py-4 mt-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <h1 class="h2 fw-bold mb-2">Admin Dashboard</h1>
                <p class="mb-0">Welcome back, <?php echo htmlspecialchars(getCurrentUser()['name']); ?>!</p>
            </div>
            <div class="col-lg-4 text-lg-end">
                <div class="d-flex gap-2 justify-content-lg-end flex-wrap">
                    <a href="products.php" class="btn btn-warning">
                        <i class="bi bi-plus-circle"></i> Add Product
                    </a>
                    <a href="orders.php" class="btn btn-outline-light">
                        <i class="bi bi-list-ul"></i> View Orders
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Dashboard Stats -->
<section class="py-5">
    <div class="container">
        <!-- Stats Cards -->
        <div class="row g-4 mb-5">
            <div class="col-lg-3 col-md-6">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="bg-success text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 50px; height: 50px;">
                                <i class="bi bi-currency-dollar fs-4"></i>
                            </div>
                            <div>
                                <h3 class="text-success mb-0"><?php echo number_format($total_revenue, 2); ?> Birr</h3>
                                <p class="text-muted mb-0">Total Revenue</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-md-6">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="bg-info text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 50px; height: 50px;">
                                <i class="bi bi-bag fs-4"></i>
                            </div>
                            <div>
                                <h3 class="text-info mb-0"><?php echo $total_orders; ?></h3>
                                <p class="text-muted mb-0">Total Orders</p>
                                <?php if ($pending_orders > 0): ?>
                                <small class="text-warning"><?php echo $pending_orders; ?> pending</small>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-md-6">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="bg-warning text-dark rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 50px; height: 50px;">
                                <i class="bi bi-box-seam fs-4"></i>
                            </div>
                            <div>
                                <h3 class="text-warning mb-0"><?php echo $active_products; ?></h3>
                                <p class="text-muted mb-0">Active Products</p>
                                <small class="text-muted"><?php echo $total_products; ?> total</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-3 col-md-6">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 50px; height: 50px;">
                                <i class="bi bi-people fs-4"></i>
                            </div>
                            <div>
                                <h3 class="text-primary mb-0"><?php echo $total_customers; ?></h3>
                                <p class="text-muted mb-0">Customers</p>
                                <?php if ($unread_messages > 0): ?>
                                <small class="text-danger"><?php echo $unread_messages; ?> new messages</small>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <!-- Recent Orders -->
            <div class="col-lg-8">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Recent Orders</h5>
                        <a href="orders.php" class="btn btn-outline-success btn-sm">View All</a>
                    </div>
                    <div class="card-body p-0">
                        <?php if (empty($recent_orders)): ?>
                        <div class="p-4 text-center text-muted">
                            <i class="bi bi-inbox display-4 mb-3"></i>
                            <p>No orders yet</p>
                        </div>
                        <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Order ID</th>
                                        <th>Customer</th>
                                        <th>Total</th>
                                        <th>Status</th>
                                        <th>Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recent_orders as $order): ?>
                                    <tr>
                                        <td><strong>#<?php echo str_pad($order['id'], 6, '0', STR_PAD_LEFT); ?></strong></td>
                                        <td><?php echo htmlspecialchars($order['customer_name']); ?></td>
                                        <td><?php echo number_format($order['total_price'], 2); ?> Birr</td>
                                        <td>
                                            <span class="badge bg-<?php 
                                                echo $order['status'] == 'pending' ? 'warning' : 
                                                    ($order['status'] == 'delivered' ? 'success' : 'info'); 
                                            ?>">
                                                <?php echo ucfirst($order['status']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo date('M d, Y', strtotime($order['created_at'])); ?></td>
                                        <td>
                                            <a href="order_details.php?id=<?php echo $order['id']; ?>" class="btn btn-outline-success btn-sm">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Quick Actions & Alerts -->
            <div class="col-lg-4">
                <!-- Low Stock Alert -->
                <?php if (!empty($low_stock_products)): ?>
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-header bg-warning text-dark">
                        <h6 class="mb-0">
                            <i class="bi bi-exclamation-triangle me-2"></i>Low Stock Alert
                        </h6>
                    </div>
                    <div class="card-body p-0">
                        <?php foreach ($low_stock_products as $product): ?>
                        <div class="d-flex align-items-center p-3 border-bottom">
                            <img src="../<?php echo htmlspecialchars($product['image']); ?>" 
                                 class="rounded me-3" style="width: 40px; height: 40px; object-fit: cover;" 
                                 alt="<?php echo htmlspecialchars($product['name']); ?>">
                            <div class="flex-grow-1">
                                <h6 class="mb-0 small"><?php echo htmlspecialchars($product['name']); ?></h6>
                                <small class="text-danger">Only <?php echo $product['stock_quantity']; ?> left</small>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        <div class="p-3">
                            <a href="products.php" class="btn btn-warning btn-sm w-100">Manage Stock</a>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Recent Messages -->
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-light d-flex justify-content-between align-items-center">
                        <h6 class="mb-0">Recent Messages</h6>
                        <a href="messages.php" class="btn btn-outline-success btn-sm">View All</a>
                    </div>
                    <div class="card-body p-0">
                        <?php if (empty($recent_messages)): ?>
                        <div class="p-3 text-center text-muted">
                            <i class="bi bi-chat display-6 mb-2"></i>
                            <p class="small">No messages yet</p>
                        </div>
                        <?php else: ?>
                        <?php foreach (array_slice($recent_messages, 0, 3) as $message): ?>
                        <div class="p-3 border-bottom">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <h6 class="mb-0 small"><?php echo htmlspecialchars($message['name']); ?></h6>
                                <span class="badge bg-<?php echo $message['status'] == 'unread' ? 'danger' : 'secondary'; ?> small">
                                    <?php echo ucfirst($message['status']); ?>
                                </span>
                            </div>
                            <p class="small text-muted mb-1"><?php echo htmlspecialchars(substr($message['message'], 0, 60)) . '...'; ?></p>
                            <small class="text-muted"><?php echo date('M d, Y', strtotime($message['created_at'])); ?></small>
                        </div>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include '../includes/footer.php'; ?>