<?php
// Simple Login Test - Place this in web++/ directory
// Access via: http://localhost/web++/simple_login_test.php

require_once '../includes/db.php';
require_once '../includes/session.php';

echo "<h2>Simple Login Test</h2>";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    echo "<h3>Login Attempt:</h3>";
    echo "Email: " . htmlspecialchars($email) . "<br>";
    
    // Get user
    $user = getSingleRow($conn, "SELECT * FROM users WHERE email = ?", [$email], 's');
    
    if ($user) {
        echo "✅ User found: " . $user['name'] . " (Role: " . $user['role'] . ")<br>";
        
        if (password_verify($password, $user['password'])) {
            echo "✅ Password correct<br>";
            
            // Login user
            loginUser($user);
            echo "✅ User logged in<br>";
            
            // Test redirect
            if ($user['role'] === 'admin') {
                echo "<p style='color: green;'>✅ Admin login successful!</p>";
                echo "<p>Redirecting to admin dashboard...</p>";
                echo "<script>setTimeout(function(){ window.location.href = 'admin/dashboard.php'; }, 2000);</script>";
            } else {
                echo "<p style='color: green;'>✅ Customer login successful!</p>";
                echo "<p>Redirecting to homepage...</p>";
                echo "<script>setTimeout(function(){ window.location.href = 'public/index.php'; }, 2000);</script>";
            }
        } else {
            echo "❌ Password incorrect<br>";
        }
    } else {
        echo "❌ User not found<br>";
    }
} else {
    // Show current session status
    if (isLoggedIn()) {
        $current_user = getCurrentUser();
        echo "<p style='color: green;'>✅ Already logged in as: " . $current_user['name'] . " (" . $current_user['role'] . ")</p>";
        
        if ($current_user['role'] === 'admin') {
            echo "<a href='admin/dashboard.php' style='padding: 10px; background: #28a745; color: white; text-decoration: none;'>Go to Admin Dashboard</a><br><br>";
        } else {
            echo "<a href='public/index.php' style='padding: 10px; background: #007bff; color: white; text-decoration: none;'>Go to Homepage</a><br><br>";
        }
        
        echo "<a href='public/logout.php' style='padding: 10px; background: #dc3545; color: white; text-decoration: none;'>Logout</a><br><br>";
    } else {
        echo "<p>Not logged in</p>";
    }
}
?>

<form method="POST" style="border: 1px solid #ccc; padding: 20px; margin: 20px 0;">
    <h3>Test Login</h3>
    <div style="margin-bottom: 10px;">
        <label>Email:</label><br>
        <select name="email" style="width: 300px; padding: 5px;">
            <option value="admin@agriecommerce.com">admin@agriecommerce.com (Admin)</option>
            <option value="customer@example.com">customer@example.com (Customer)</option>
        </select>
    </div>
    <div style="margin-bottom: 10px;">
        <label>Password:</label><br>
        <input type="password" name="password" value="admin123" style="width: 300px; padding: 5px;">
        <small style="display: block; color: #666;">Default: admin123 or customer123</small>
    </div>
    <button type="submit" style="padding: 10px 20px; background: #28a745; color: white; border: none;">Test Login</button>
</form>

<div style="background: #f8f9fa; padding: 15px; margin: 20px 0;">
    <h4>Quick Links for Testing:</h4>
    <a href="admin/dashboard.php" target="_blank">Direct Admin Dashboard Access</a><br>
    <a href="public/login.php" target="_blank">Regular Login Page</a><br>
    <a href="public/index.php" target="_blank">Homepage</a><br>
</div>

<p><strong>Instructions:</strong></p>
<ol>
    <li>Try the test login form above</li>
    <li>Check if admin dashboard opens correctly</li>
    <li>Test the direct links</li>
    <li>Delete this file after testing</li>
</ol>