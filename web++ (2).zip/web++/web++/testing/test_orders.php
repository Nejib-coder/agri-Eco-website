<?php
// Order System Testing Tool
// Access via: http://localhost/web++/test_orders.php

require_once '../includes/db.php';
require_once '../includes/session.php';

echo "<h2>Order System Testing & Debugging</h2>";

// Test database tables
echo "<h3>1. Database Tables Check</h3>";
$tables = ['orders', 'order_items', 'users', 'products'];
foreach ($tables as $table) {
    $result = $conn->query("SHOW TABLES LIKE '$table'");
    if ($result->num_rows > 0) {
        echo "✅ Table '$table' exists<br>";
        
        // Check table structure
        $structure = $conn->query("DESCRIBE $table");
        echo "<details><summary>View $table structure</summary>";
        echo "<table border='1' style='margin: 10px;'>";
        echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th></tr>";
        while ($row = $structure->fetch_assoc()) {
            echo "<tr><td>{$row['Field']}</td><td>{$row['Type']}</td><td>{$row['Null']}</td><td>{$row['Key']}</td></tr>";
        }
        echo "</table></details>";
    } else {
        echo "❌ Table '$table' missing<br>";
    }
}

// Test existing orders
echo "<h3>2. Existing Orders Check</h3>";
$orders = getMultipleRows($conn, "
    SELECT o.*, u.name as customer_name 
    FROM orders o 
    LEFT JOIN users u ON o.user_id = u.id 
    ORDER BY o.created_at DESC 
    LIMIT 5
");

if (empty($orders)) {
    echo "⚠️ No orders found in database<br>";
} else {
    echo "✅ Found " . count($orders) . " orders<br>";
    echo "<table border='1' style='margin: 10px;'>";
    echo "<tr><th>ID</th><th>Customer</th><th>Total</th><th>Status</th><th>Date</th><th>Items</th></tr>";
    
    foreach ($orders as $order) {
        // Get order items
        $items = getMultipleRows($conn, "
            SELECT oi.*, p.name as product_name 
            FROM order_items oi 
            LEFT JOIN products p ON oi.product_id = p.id 
            WHERE oi.order_id = ?
        ", [$order['id']], 'i');
        
        $items_count = count($items);
        $items_summary = implode(', ', array_map(function($item) {
            return $item['product_name'] . ' (' . $item['quantity'] . ')';
        }, $items));
        
        echo "<tr>";
        echo "<td>#{$order['id']}</td>";
        echo "<td>{$order['customer_name']}</td>";
        echo "<td>{$order['total_price']} Birr</td>";
        echo "<td>{$order['status']}</td>";
        echo "<td>" . date('M d, Y', strtotime($order['created_at'])) . "</td>";
        echo "<td title='$items_summary'>$items_count items</td>";
        echo "</tr>";
    }
    echo "</table>";
}

// Test order creation process
echo "<h3>3. Test Order Creation</h3>";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['test_order'])) {
    echo "<h4>Creating Test Order...</h4>";
    
    // Check if user is logged in
    if (!isLoggedIn()) {
        echo "❌ User not logged in. Please login first.<br>";
    } else {
        $user = getCurrentUser();
        echo "✅ User logged in: " . $user['name'] . "<br>";
        
        // Check if cart has items
        $cart_items = getCartItems();
        if (empty($cart_items)) {
            echo "❌ Cart is empty. Adding test product to cart...<br>";
            
            // Add a test product to cart
            $test_product = getSingleRow($conn, "SELECT * FROM products WHERE status = 'active' LIMIT 1");
            if ($test_product) {
                addToCart($test_product['id'], 2);
                echo "✅ Added {$test_product['name']} (2 qty) to cart<br>";
                $cart_items = getCartItems();
            } else {
                echo "❌ No active products found<br>";
            }
        }
        
        if (!empty($cart_items)) {
            echo "✅ Cart has " . count($cart_items) . " different products<br>";
            
            // Calculate total
            $product_ids = array_keys($cart_items);
            $placeholders = str_repeat('?,', count($product_ids) - 1) . '?';
            $types = str_repeat('i', count($product_ids));
            
            $sql = "SELECT * FROM products WHERE id IN ($placeholders)";
            $products = getMultipleRows($conn, $sql, $product_ids, $types);
            
            $total = 0;
            foreach ($products as $product) {
                $quantity = $cart_items[$product['id']];
                $total += $product['price'] * $quantity;
            }
            
            echo "✅ Order total calculated: $total Birr<br>";
            
            // Create test order
            try {
                $conn->begin_transaction();
                
                // Insert order
                $sql = "INSERT INTO orders (user_id, total_price, status, shipping_address, phone, delivery_type, payment_method) VALUES (?, ?, 'pending', ?, ?, 'standard', 'cash')";
                $stmt = executeQuery($conn, $sql, [
                    $user['id'], 
                    $total, 
                    'Test Address, Addis Ababa', 
                    '+251911223344'
                ], 'idss');
                
                $order_id = $conn->insert_id;
                echo "✅ Order created with ID: $order_id<br>";
                
                // Insert order items
                foreach ($products as $product) {
                    $quantity = $cart_items[$product['id']];
                    $sql = "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
                    executeQuery($conn, $sql, [$order_id, $product['id'], $quantity, $product['price']], 'iiid');
                    echo "✅ Added order item: {$product['name']} (qty: $quantity)<br>";
                }
                
                $conn->commit();
                echo "<p style='color: green; font-weight: bold;'>✅ Test order created successfully!</p>";
                
                // Clear cart
                clearCart();
                echo "✅ Cart cleared<br>";
                
            } catch (Exception $e) {
                $conn->rollback();
                echo "❌ Error creating order: " . $e->getMessage() . "<br>";
            }
        }
    }
}

// Test admin order viewing
echo "<h3>4. Admin Order Viewing Test</h3>";
if (isLoggedIn() && isAdmin()) {
    echo "✅ Logged in as admin<br>";
    echo "<a href='admin/orders.php' target='_blank' style='padding: 10px; background: #28a745; color: white; text-decoration: none;'>View Admin Orders Page</a><br>";
} else {
    echo "⚠️ Not logged in as admin. <a href='public/login.php'>Login as admin</a> to test admin features<br>";
}

// Current session info
echo "<h3>5. Current Session Info</h3>";
if (isLoggedIn()) {
    $user = getCurrentUser();
    echo "✅ Logged in as: " . $user['name'] . " (" . $user['role'] . ")<br>";
    echo "User ID: " . $user['id'] . "<br>";
    
    $cart_items = getCartItems();
    echo "Cart items: " . count($cart_items) . "<br>";
    if (!empty($cart_items)) {
        foreach ($cart_items as $product_id => $quantity) {
            $product = getSingleRow($conn, "SELECT name FROM products WHERE id = ?", [$product_id], 'i');
            echo "- " . ($product['name'] ?? 'Unknown Product') . " (qty: $quantity)<br>";
        }
    }
} else {
    echo "❌ Not logged in<br>";
    echo "<a href='public/login.php'>Login</a> | <a href='public/register.php'>Register</a><br>";
}
?>

<div style="background: #f8f9fa; padding: 20px; margin: 20px 0; border-radius: 5px;">
    <h3>Test Actions</h3>
    
    <?php if (isLoggedIn()): ?>
    <form method="POST" style="margin: 10px 0;">
        <button type="submit" name="test_order" style="padding: 10px 20px; background: #007bff; color: white; border: none; border-radius: 3px;">
            Create Test Order
        </button>
    </form>
    <?php else: ?>
    <p>Please <a href="public/login.php">login</a> to test order creation.</p>
    <?php endif; ?>
    
    <div style="margin: 20px 0;">
        <h4>Quick Links:</h4>
        <a href="public/products.php" target="_blank">Products Page</a> | 
        <a href="public/cart.php" target="_blank">Cart Page</a> | 
        <a href="public/checkout.php" target="_blank">Checkout Page</a> | 
        <a href="admin/orders.php" target="_blank">Admin Orders</a>
    </div>
</div>

<div style="background: #fff3cd; padding: 15px; margin: 20px 0; border-radius: 5px;">
    <h4>Testing Instructions:</h4>
    <ol>
        <li>Check that all database tables exist (should be ✅)</li>
        <li>Login as customer: customer@example.com / customer123</li>
        <li>Add products to cart from products page</li>
        <li>Go through checkout process</li>
        <li>Login as admin: admin@agriecommerce.com / admin123</li>
        <li>Check admin orders page to see the order</li>
        <li>Use "Create Test Order" button above for quick testing</li>
    </ol>
    
    <p><strong>Delete this file after testing for security!</strong></p>
</div>