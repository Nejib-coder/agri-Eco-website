<?php
// Test Admin Redirect - Place this in web++/ directory
// Access via: http://localhost/web++/test_admin_redirect.php

echo "<h2>Admin Dashboard Access Test</h2>";

// Test if admin dashboard file exists
$admin_dashboard = __DIR__ . '/../admin/dashboard.php';
if (file_exists($admin_dashboard)) {
    echo "✅ Admin dashboard file exists at: " . $admin_dashboard . "<br>";
} else {
    echo "❌ Admin dashboard file NOT found<br>";
}

// Test different redirect paths
echo "<h3>Testing Redirect Paths:</h3>";

$paths_to_test = [
    '../admin/dashboard.php',
    './../admin/dashboard.php', 
    '/web++/admin/dashboard.php',
    '../../admin/dashboard.php'
];

foreach ($paths_to_test as $path) {
    echo "<a href='$path' target='_blank'>Test: $path</a> ";
    
    // Check if file exists for relative paths
    if (!str_starts_with($path, '/')) {
        $full_path = __DIR__ . '/' . ltrim($path, './');
        if (file_exists($full_path)) {
            echo "✅ File exists";
        } else {
            echo "❌ File not found";
        }
    }
    echo "<br>";
}

echo "<h3>Current Directory Info:</h3>";
echo "Current directory: " . __DIR__ . "<br>";
echo "Script name: " . $_SERVER['SCRIPT_NAME'] . "<br>";
echo "Document root: " . $_SERVER['DOCUMENT_ROOT'] . "<br>";

echo "<h3>Manual Test:</h3>";
echo "<p>Try accessing the admin dashboard directly:</p>";
echo "<a href='../admin/dashboard.php' target='_blank' style='padding: 10px; background: #28a745; color: white; text-decoration: none;'>Open Admin Dashboard</a>";

echo "<p><strong>Note:</strong> Delete this file after testing for security.</p>";
?>