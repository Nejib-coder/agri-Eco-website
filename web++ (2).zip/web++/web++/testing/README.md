# 🧪 Testing Tools & Instructions

This directory contains comprehensive testing tools for the AgriE-Commerce system.

## 📋 **Testing Files**

### 1. **test_orders.php** - Order System Testing
- **Purpose**: Complete order flow testing
- **Features**: Database checks, order creation, admin viewing
- **Usage**: `http://localhost/web++/testing/test_orders.php`

### 2. **simple_login_test.php** - Login System Testing  
- **Purpose**: Step-by-step login process testing
- **Features**: Admin/customer login, session management, redirects
- **Usage**: `http://localhost/web++/testing/simple_login_test.php`

### 3. **debug_login.php** - Authentication Debugging
- **Purpose**: Detailed login troubleshooting
- **Features**: Database connection, password verification, user accounts
- **Usage**: `http://localhost/web++/testing/debug_login.php`

### 4. **test_admin_redirect.php** - Admin Access Testing
- **Purpose**: Admin dashboard access verification
- **Features**: File existence, redirect paths, permissions
- **Usage**: `http://localhost/web++/testing/test_admin_redirect.php`

## 🎯 **Testing Scenarios**

### **Complete System Test**
1. **Database Setup**
   ```
   - Import database/database_setup.sql
   - Verify all tables created
   - Check sample data loaded
   ```

2. **Authentication Test**
   ```
   - Test admin login: admin@agriecommerce.com / admin123
   - Test customer login: customer@example.com / customer123
   - Verify proper redirects
   ```

3. **Order Flow Test**
   ```
   - Add products to cart
   - Complete checkout process
   - Verify order saved in database
   - Check admin can view order
   ```

4. **Validation Test**
   ```
   - Try invalid inputs on all forms
   - Verify JavaScript validation works
   - Test server-side validation backup
   ```

### **Quick Health Check**
```bash
# 1. Test database connection
http://localhost/web++/testing/debug_login.php

# 2. Test order system
http://localhost/web++/testing/test_orders.php

# 3. Test admin access
http://localhost/web++/testing/test_admin_redirect.php
```

## 🔧 **Troubleshooting Guide**

### **Common Issues**

#### **Database Connection Failed**
- Check XAMPP MySQL is running
- Verify database exists: `agri_ecommerce`
- Import database schema if missing

#### **Login Not Working**
- Run password fix: `database/fix_demo_passwords.sql`
- Clear browser cookies
- Check user accounts exist in database

#### **Orders Not Saving**
- Check database tables exist
- Verify user is logged in
- Test with `test_orders.php`

#### **Admin Dashboard Not Found**
- Check file exists: `admin/dashboard.php`
- Verify admin login credentials
- Test redirect with `test_admin_redirect.php`

### **Performance Testing**
```php
// Add multiple products to cart
// Complete multiple orders
// Test with different user accounts
// Verify database performance
```

## 📊 **Expected Results**

### **All Tests Should Show:**
- ✅ Database connection successful
- ✅ All tables exist with data
- ✅ User accounts working
- ✅ Password verification successful
- ✅ Order creation working
- ✅ Admin dashboard accessible
- ✅ Form validation active

### **If Tests Fail:**
1. Check XAMPP services running
2. Import database schema
3. Verify file permissions
4. Clear browser cache
5. Check PHP error logs

## 🚨 **Security Note**

**⚠️ IMPORTANT: Delete this testing directory before production deployment!**

These testing files contain debugging information and should not be accessible in a live environment.

```bash
# Before going live, remove:
rm -rf testing/
```

## 📝 **Test Results Log**

Document your test results:

```
Date: ___________
Tester: ___________

✅ Database Connection: PASS/FAIL
✅ User Authentication: PASS/FAIL  
✅ Order System: PASS/FAIL
✅ Admin Dashboard: PASS/FAIL
✅ Form Validation: PASS/FAIL
✅ Cart Operations: PASS/FAIL

Notes:
_________________________________
_________________________________
```

---

**Testing Status: Ready for University Evaluation** ✅