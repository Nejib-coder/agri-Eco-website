<?php
// Debug Login - Place this in web++/ directory (same level as public/)
// Access via: http://localhost/web++/debug_login.php

require_once '../includes/db.php';
require_once '../includes/session.php';

echo "<h2>Login Debug Tool</h2>";

// Test database connection
echo "<h3>1. Database Connection Test</h3>";
if ($conn) {
    echo "✅ Database connected successfully<br>";
    echo "Database: " . DB_NAME . "<br>";
} else {
    echo "❌ Database connection failed<br>";
    die();
}

// Test if users table exists and has data
echo "<h3>2. Users Table Test</h3>";
$result = $conn->query("SELECT COUNT(*) as count FROM users");
if ($result) {
    $count = $result->fetch_assoc()['count'];
    echo "✅ Users table exists with {$count} users<br>";
} else {
    echo "❌ Users table not found or error: " . $conn->error . "<br>";
}

// Test demo accounts
echo "<h3>3. Demo Accounts Test</h3>";
$admin = getSingleRow($conn, "SELECT id, name, email, role FROM users WHERE email = ?", ['admin@agriecommerce.com'], 's');
$customer = getSingleRow($conn, "SELECT id, name, email, role FROM users WHERE email = ?", ['customer@example.com'], 's');

if ($admin) {
    echo "✅ Admin account found: " . $admin['name'] . " (" . $admin['role'] . ")<br>";
} else {
    echo "❌ Admin account not found<br>";
}

if ($customer) {
    echo "✅ Customer account found: " . $customer['name'] . " (" . $customer['role'] . ")<br>";
} else {
    echo "❌ Customer account not found<br>";
}

// Test password verification
echo "<h3>4. Password Verification Test</h3>";
if ($admin) {
    $admin_full = getSingleRow($conn, "SELECT * FROM users WHERE email = ?", ['admin@agriecommerce.com'], 's');
    $password_test = password_verify('admin123', $admin_full['password']);
    echo $password_test ? "✅ Admin password verification works<br>" : "❌ Admin password verification failed<br>";
}

if ($customer) {
    $customer_full = getSingleRow($conn, "SELECT * FROM users WHERE email = ?", ['customer@example.com'], 's');
    $password_test = password_verify('customer123', $customer_full['password']);
    echo $password_test ? "✅ Customer password verification works<br>" : "❌ Customer password verification failed<br>";
}

// Test login form processing
echo "<h3>5. Login Form Test</h3>";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitizeInput($_POST['email']);
    $password = $_POST['password'];
    
    echo "Email entered: " . htmlspecialchars($email) . "<br>";
    echo "Password entered: " . (empty($password) ? "Empty" : "Provided") . "<br>";
    
    $user = getSingleRow($conn, "SELECT * FROM users WHERE email = ?", [$email], 's');
    
    if ($user) {
        echo "✅ User found in database<br>";
        echo "User role: " . $user['role'] . "<br>";
        
        if (password_verify($password, $user['password'])) {
            echo "✅ Password verification successful<br>";
            echo "Login should work! Redirecting...<br>";
            
            // Test actual login
            loginUser($user);
            echo "✅ User logged in successfully<br>";
            echo "Session user_id: " . $_SESSION['user_id'] . "<br>";
            echo "Session user_role: " . $_SESSION['user_role'] . "<br>";
            
        } else {
            echo "❌ Password verification failed<br>";
            echo "Stored hash: " . substr($user['password'], 0, 20) . "...<br>";
        }
    } else {
        echo "❌ User not found with email: " . htmlspecialchars($email) . "<br>";
    }
}
?>

<form method="POST" style="margin-top: 20px; padding: 20px; border: 1px solid #ccc;">
    <h3>Test Login Form</h3>
    <div style="margin-bottom: 10px;">
        <label>Email:</label><br>
        <input type="email" name="email" value="admin@agriecommerce.com" style="width: 300px; padding: 5px;">
    </div>
    <div style="margin-bottom: 10px;">
        <label>Password:</label><br>
        <input type="password" name="password" value="admin123" style="width: 300px; padding: 5px;">
    </div>
    <button type="submit" style="padding: 10px 20px; background: #28a745; color: white; border: none;">Test Login</button>
</form>

<p><strong>Instructions:</strong></p>
<ol>
    <li>Check all the tests above are ✅ green</li>
    <li>Use the test form to try logging in</li>
    <li>If everything works here, the issue is in the main login page</li>
    <li>Delete this file after testing for security</li>
</ol>